"""Record a reproducible RustMage baseline game from one player's perspective."""
import argparse
import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path

from ..backends.rustmage import RustMageMatch, _plain
from ..baselines.foundations import FoundationsAggro, foundations_deck
from ..rl.runner import DecisionRunner, EpisodeEnd


def visible_snapshot(raw):
    """Keep public information and the viewer's private hand; never library order."""
    keys = ('schema', 'viewer', 'revision', 'actor', 'active', 'turn', 'step',
            'decision', 'players', 'objects', 'outcome')
    return {key: _plain(raw.get(key)) for key in keys}


async def record(seed, max_decisions):
    decks = (foundations_deck('red'), foundations_deck('white'))
    match = RustMageMatch(*decks, seed=seed)
    runner = DecisionRunner(match.games, max_decisions=max_decisions)
    policies = {name: FoundationsAggro() for name in match.games}
    frames = []
    started = datetime.now(timezone.utc).isoformat()
    try:
        frames.append({'state': visible_snapshot(match._raw('P0')), 'action': None})
        while True:
            turn = await runner.next()
            if isinstance(turn, EpisodeEnd):
                frames.append({'state': visible_snapshot(match._raw('P0')), 'action': None})
                return {'version': 1, 'backend': 'rustmage', 'seed': seed,
                        'started_at': started, 'ended_at': datetime.now(timezone.utc).isoformat(),
                        'truncated': turn.truncated, 'reason': turn.reason, 'frames': frames}
            response = policies[turn.actor].choose(turn.observation)
            option = next(o for o in turn.observation.decision.options if o.id == response.option)
            # Do not record the opponent's private options or targets.
            action = {'actor': turn.actor, 'kind': option.label,
                      'decision': turn.observation.decision.kind}
            if turn.actor == 'player_0':
                action.update(option=response.option, value=_plain(response.value),
                              details=_plain(option.constraints))
            await runner.submit(response)
            frames.append({'state': visible_snapshot(match._raw('P0')), 'action': action})
    finally:
        await runner.close()
        match.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--seed', type=int, default=12)
    parser.add_argument('--max-decisions', type=int, default=10000)
    args = parser.parse_args()
    recording = asyncio.run(record(args.seed, args.max_decisions))
    args.output.write_text(json.dumps(recording, indent=2) + '\n')
    print(f"Recorded {len(recording['frames'])} frames to {args.output}; truncated={recording['truncated']}")


if __name__ == '__main__':
    main()
