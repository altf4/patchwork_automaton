"""Adapt historical XMage evaluation JSONL traces to the replay recording model.

Each trace row is a pre-decision observation of whichever seat acted. Never mix
private hands: carry forward only the selected seat's most recent hand while
using public objects from either observation.
"""
import gzip
import json
from importlib.resources import files
from pathlib import Path

PHASES = {'precombat_main': 'Main1', 'postcombat_main': 'Main2',
          'begin_combat': 'BeginCombat', 'declare_attackers': 'Attackers',
          'declare_blockers': 'Blockers', 'combat_damage': 'CombatDamage',
          'end_combat': 'EndCombat', 'untap': 'Untap', 'upkeep': 'Upkeep',
          'draw': 'Draw', 'end_turn': 'End', 'cleanup': 'Cleanup'}
ZONES = {'hand': 'Hand', 'battlefield': 'Battlefield', 'graveyard': 'Graveyard',
         'exile': 'Exile', 'stack': 'Stack', 'command': 'Command'}


def read_trace(path):
    path = Path(path)
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def normalize(rows, viewer='player_0', *, started_at='1970-01-01T00:00:00+00:00'):
    if viewer not in ('player_0', 'player_1'):
        raise ValueError('Viewer must be player_0 or player_1')
    decisions = [row for row in rows if isinstance(row.get('state'), dict)]
    if not decisions: raise ValueError('XMage trace contains no decision observations')
    player_ids = {}
    for row in decisions:
        actor, actor_id = row.get('actor'), row['state'].get('actor')
        if actor in ('player_0', 'player_1') and actor_id:
            if actor in player_ids and player_ids[actor] != actor_id:
                raise ValueError('XMage trace changes player identity')
            player_ids[actor] = actor_id
    if len(player_ids) != 2 or len(set(player_ids.values())) != 2:
        raise ValueError('XMage trace does not identify both players')
    opponent = 'player_1' if viewer == 'player_0' else 'player_0'
    mapped = {player_ids[viewer]: 'P0', player_ids[opponent]: 'P1'}
    traits_file = files('patchwork_automaton').joinpath('data/rustmage-card-traits.json')
    traits = json.loads(traits_file.read_text()) if traits_file.is_file() else {'cards': []}
    kinds_by_name = {c['name']: c['kinds'] for c in traits['cards'] if c.get('name') and c.get('kinds') is not None}
    # The checked-in baseline has a reviewed list of its land names.
    from ..baselines.modern_burn import LAND_ORDER
    for name in LAND_ORDER:
        kinds_by_name.setdefault(name, 2)
    hand = {}
    frames = []
    prior_action = None
    last_active = None
    stack_owners = {}
    last_row = None
    def project(state):
        nonlocal hand, last_active
        ids = {p['id']: p for p in state['players']}
        if set(ids) != set(mapped): raise ValueError('XMage player list changes')
        public = []
        visible_hand = {}
        for item in state.get('objects', []):
            zone = ZONES.get(item.get('zone'))
            if not zone: continue
            controller = mapped.get(item.get('controller'))
            if zone == 'Stack' and controller is None:
                controller = stack_owners.get(str(item['id']))
                if controller is None and last_row and item.get('name') not in (None, 'Ability'):
                    selected = (last_row.get('response') or {}).get('option', '').removeprefix('object:')
                    candidates = [o for o in last_row['state'].get('objects', [])
                                  if str(o.get('id')) == selected and o.get('name') == item['name']]
                    if len(candidates) == 1:
                        controller = mapped.get(candidates[0].get('controller'))
                    if controller is not None:
                        stack_owners[str(item['id'])] = controller
            if zone == 'Hand':
                if controller != 'P0' or state.get('actor') != player_ids[viewer]: continue
            elif controller is None:
                # Unowned stack abilities and other helper objects have insufficient
                # information for a safe owner/controller assignment.
                continue
            props = item.get('properties') or {}
            types = props.get('cardTypes') or []
            if isinstance(types, str): types = [types]
            kinds = (1 if any(str(t).upper() == 'CREATURE' for t in types) else 0) | (2 if any(str(t).upper() == 'LAND' for t in types) else 0)
            if not kinds:
                kinds = kinds_by_name.get(item.get('name'), 0)
            value = dict(id=item['id'], name=item.get('name'), zone=zone,
                owner=controller, controller=controller, kinds=kinds,
                tapped=bool(props.get('tapped', False)), counters={},
                power=props.get('power'), toughness=props.get('toughness'),
                attacking=bool(props.get('attacking', False)), token=props.get('isToken'))
            if zone == 'Hand': visible_hand[str(item['id'])] = value
            else: public.append(value)
        if state.get('actor') == player_ids[viewer]:
            hand = visible_hand
        public_ids = {str(o['id']) for o in public}
        hand = {key: value for key, value in hand.items() if key not in public_ids}
        active = mapped.get(state.get('active'))
        if active is not None: last_active = active
        phase = state.get('phase')
        # Pregame rows can precede any active player; use P0 only as a placeholder
        # and leave the turn at zero until an active player is actually reported.
        return dict(viewer='P0', revision=state.get('revision', 0),
            actor=mapped.get(state.get('actor')), active=active or last_active or 'P0',
            turn=(state.get('turn') or 0) if (active or last_active) else 0,
            step=PHASES.get(phase, 'Pregame'),
            players=[{'life': ids[pid].get('life'), 'hand_count': ids[pid].get('hand_count'),
                      'library_count': ids[pid].get('library_count')} for pid in (player_ids[viewer], player_ids[opponent])],
            objects=public + list(hand.values()), outcome=None)
    for row in decisions:
        frames.append(dict(state=project(row['state']), action=prior_action))
        response = row.get('response') or {}
        choice = next((o for o in row.get('choices', []) if o.get('id') == response.get('option')), None)
        last_row = row
        prior_action = {'actor': 'player_0' if row.get('actor') == viewer else 'player_1',
                        'kind': row.get('kind') or 'decision'}
        if row.get('actor') == viewer and choice:
            prior_action['label'] = choice.get('label')
    terminal = next((row for row in reversed(rows) if row.get('terminal') is True), None)
    summary = next((row['terminal_summary'] for row in reversed(rows) if 'terminal_summary' in row), None)
    final = None
    if terminal and isinstance(terminal.get('states'), dict):
        final = terminal['states'].get(viewer)
    if final is not None:
        state = project(final)
        reward = terminal.get('rewards', {}).get(viewer)
        state['outcome'] = 'Draw' if reward == 0 else {'Winner': 'P0' if reward > 0 else 'P1'} if reward in (-1, 1) else None
        frames.append(dict(state=state, action=prior_action))
    elif prior_action:
        # There is no post-action state in a cutoff/goldfish summary.
        frames.append(dict(state=frames[-1]['state'].copy(), action=prior_action))
    return dict(version=1, backend='rustmage', source='xmage-evaluation-jsonl',
                seed='xmage', started_at=started_at, ended_at=None,
                truncated=not bool(final and state['outcome'] is not None),
                reason=None if final and state['outcome'] is not None else (summary or {}).get('reason', 'terminal state unavailable'),
                frames=frames)
