"""Convert a Patchwork RustMage recording to Tapps replay stream version 1."""
import argparse
import json
from pathlib import Path

ZONES = {'Hand': 'hand', 'Battlefield': 'battlefield', 'Graveyard': 'graveyard',
         'Exile': 'exile', 'Stack': 'stack', 'Command': 'command', 'Library': 'library'}
PHASES = {'Pregame': (None, None), 'Main1': ('Phase_Main1', None),
          'Main2': ('Phase_Main2', None), 'BeginCombat': ('Phase_Combat', 'Step_BeginCombat'),
          'Attackers': ('Phase_Combat', 'Step_DeclareAttack'),
          'Blockers': ('Phase_Combat', 'Step_DeclareBlock'),
          'CombatDamage': ('Phase_Combat', 'Step_CombatDamage'),
          'EndCombat': ('Phase_Combat', 'Step_EndCombat'),
          'Untap': ('Phase_Beginning', 'Step_Untap'), 'Upkeep': ('Phase_Beginning', 'Step_Upkeep'),
          'Draw': ('Phase_Beginning', 'Step_Draw'), 'End': ('Phase_Ending', 'Step_End'),
          'Cleanup': ('Phase_Ending', 'Step_Cleanup')}


def seat(player):
    if player not in ('P0', 'P1'):
        raise ValueError(f'Unknown player {player!r}')
    return int(player[1]) + 1


def object_id(obj):
    return str(obj['id'])


def convert(recording):
    if recording.get('version') != 1 or recording.get('backend') != 'rustmage':
        raise ValueError('Expected Patchwork RustMage recording version 1')
    frames = recording.get('frames')
    if not frames or not isinstance(frames, list):
        raise ValueError('Recording has no frames')
    states = [f['state'] for f in frames]
    viewer = states[0].get('viewer')
    if viewer not in ('P0', 'P1') or any(s.get('viewer') != viewer or len(s.get('players', [])) != 2 for s in states):
        raise ValueError('Expected consistent two-player viewer observations')
    viewer_seat = seat(viewer)
    if any(b['revision'] < a['revision'] for a, b in zip(states, states[1:])):
        raise ValueError('Recording revisions are out of order')
    first, last = states[0], states[-1]
    events, cards, turns, frame_ends = [], {}, [], []
    limitations = ['Reconstructed from player-visible snapshots after decisions; intermediate events can be omitted.',
                   'Opponent hand and library identities are hidden; hidden-zone count corrections are inferred. Combat targets, blocks, abilities and move causes may be unavailable.',
                   'Action timing is synthetic and opening mulligans may be approximate.']
    if recording.get('source') == 'xmage-evaluation-jsonl':
        limitations.append('XMage observations alternate seats: the selected hand can be stale between its decisions; ownership and some stack controllers are inferred; unowned stack objects are omitted.')
    if recording.get('truncated'):
        limitations.append('Game recording was truncated: ' + str(recording.get('reason')))
    turn = 0
    phase = step = None
    def emit(kind, **fields):
        event = dict(seq=len(events), t=float(len(events)), turn=turn, phase=phase, step=step, log=None, kind=kind)
        event.update(fields)
        events.append(event)
        return event
    def card(obj):
        name = obj.get('name')
        if not name: return None
        key = 'n:' + name
        kinds = obj.get('kinds', 0)
        typ = 'Creature' if kinds & 1 else 'Land' if kinds & 2 else None
        cards.setdefault(key, dict(name=name, arena_id=None, type_line=typ, primary_type=typ,
                                   power=str(obj['power']) if typ == 'Creature' else None,
                                   toughness=str(obj['toughness']) if typ == 'Creature' else None,
                                   mana_cost=None, color_identity=None, is_token=bool(obj.get('token')),
                                   image_url=None, faces=[], keywords=[], back_face=False))
        return key
    hidden_hand = {}
    hidden_library = {}
    shadow_objects = {}
    def move(obj, source, target, reason='unknown'):
        oid, owner = object_id(obj), seat(obj['owner'])
        old = shadow_objects.get(oid)
        if old is None:
            if source == 'library':
                if target == 'hand' and turn == 0 and hidden_hand[owner] > 0:
                    hidden_hand[owner] -= 1
                else:
                    hidden_library[owner] = max(0, hidden_library[owner] - 1)
            elif source == 'hand':
                hidden_hand[owner] = max(0, hidden_hand[owner] - 1)
        shadow_objects[oid] = (owner, target)
        emit('move', obj=object_id(obj), card=card(obj), **{'from': source, 'to': target},
             owner=seat(obj['owner']), controller=seat(obj['controller']), reason=reason,
             inferred=True, index=None)
    def objects(state):
        return {object_id(o): o for o in state['objects'] if o.get('zone') in ZONES}
    def detail(obj, prior=None):
        oid = object_id(obj)
        if obj.get('zone') != 'Battlefield': return
        old = prior if prior and prior.get('zone') == 'Battlefield' else {}
        if obj.get('tapped', False) != old.get('tapped', False):
            emit('tap' if obj['tapped'] else 'untap', objs=[oid])
        if obj.get('kinds', 0) & 1 and (obj.get('power'), obj.get('toughness')) != (old.get('power'), old.get('toughness')):
            emit('pt', obj=oid, power=obj.get('power'), toughness=obj.get('toughness'))
        for key, total in obj.get('counters', {}).items():
            before = old.get('counters', {}).get(key, 0)
            if isinstance(total, int) and total != before:
                emit('counter', obj=oid, type={'plus_one': '+1/+1', 'minus_one': '-1/-1'}.get(key, key), delta=total-before, total=total)
        attached = obj.get('attached_to')
        old_attached = old.get('attached_to')
        if attached != old_attached:
            target = attached.get('card') if isinstance(attached, dict) else attached
            emit('attach', obj=oid, to=str(target) if target is not None else None)
    hidden_hand.update({i+1: p['hand_count'] for i,p in enumerate(first['players'])})
    hidden_library.update({i+1: p['library_count'] for i,p in enumerate(first['players'])})
    emit('game_start', seats_hand_sizes={str(i+1): p['hand_count'] for i,p in enumerate(first['players'])},
         library_sizes={str(i+1): p['library_count'] for i,p in enumerate(first['players'])})
    stack_ids = {}
    previous = objects(first)
    for obj in previous.values():
        zone = ZONES[obj['zone']]
        move(obj, 'library' if zone == 'hand' else 'limbo', zone, 'draw' if zone == 'hand' else 'put')
        detail(obj)
    # Track the same hidden counts and object zones as Tapps' reducer. Synthetic
    # face-down objects make snapshot counts exact without inventing identities.
    ghosts = {(n, z): [] for n in (1, 2) for z in ('hand', 'library')}
    ghost_serial = 0
    def ghost(n):
        nonlocal ghost_serial
        ghost_serial += 1
        owner = f'P{n-1}'
        return dict(id='patchwork-hidden-'+str(ghost_serial), name=None, owner=owner, controller=owner)
    def count(n, zone):
        hidden = hidden_hand[n] if zone == 'hand' else hidden_library[n]
        return hidden + sum(1 for owner, z in shadow_objects.values() if owner == n and z == zone)
    def reconcile(n, zone, desired):
        if not isinstance(desired, int) or isinstance(desired, bool) or desired < 0:
            return
        pool = ghosts[(n, zone)]
        while count(n, zone) < desired:
            obj = ghost(n); pool.append(obj)
            move(obj, 'limbo', zone)
        while count(n, zone) > desired:
            while pool and shadow_objects.get(object_id(pool[-1])) != (n, zone):
                pool.pop()
            if pool:
                obj = pool.pop()
            elif (hidden_hand[n] if zone == 'hand' else hidden_library[n]) > 0:
                obj = ghost(n)
            elif zone == 'library':
                oid = next(oid for oid, state in shadow_objects.items() if state == (n, zone))
                obj = dict(id=oid, name=None, owner=f'P{n-1}', controller=f'P{n-1}')
            else:
                # Don't silently discard a known visible card just to match a count.
                break
            move(obj, zone, 'limbo')
    previous_state = first
    previous_turn = None
    previous_step = None
    for frame, state in zip(frames, states):
        if state['turn'] and state['turn'] != previous_turn:
            if turns: turns[-1]['last_seq'] = len(events)-1
            turn = state['turn']
            phase, step = PHASES.get(state['step'], (None, None))
            start = len(events)
            emit('turn', active_seat=seat(state['active']))
            turns.append(dict(turn=turn, seat=seat(state['active']), first_seq=start, last_seq=start, started_at=None, duration_seconds=None))
            previous_turn = turn
            previous_step = None
        if state['step'] != previous_step:
            phase, step = PHASES.get(state['step'], (None, None))
            emit('phase')
            previous_step = state['step']
        if state is first:
            frame_ends.append(len(events)-1)
            continue
        current = objects(state)
        for idx, (a,b) in enumerate(zip(previous_state['players'],state['players'])):
            if a['life'] != b['life']:
                emit('life', seat=idx+1, life=b['life'], delta=b['life']-a['life'], source_obj=None)
        for oid, obj in current.items():
            old = previous.get(oid)
            zone = ZONES[obj['zone']]
            old_zone = ZONES[old['zone']] if old else None
            if old_zone != zone:
                if old_zone == 'stack':
                    stack_ids.pop(oid, None)
                source = old_zone or ('hand' if obj['owner'] != viewer and zone != 'hand' else 'library' if zone == 'hand' else 'limbo')
                reason = 'draw' if source == 'library' and zone == 'hand' else 'play_land' if source == 'hand' and zone == 'battlefield' and obj.get('kinds',0) & 2 else 'unknown'
                move(obj, source, zone, reason)
                if zone == 'stack':
                    stack_ids[oid] = 's:' + oid
                    emit('stack_push', stack_id=stack_ids[oid], obj=oid, card=card(obj), stack_kind='spell', controller=seat(obj['controller']), text=obj.get('name') or '', targets=[])
            elif old and old.get('name') != obj.get('name') and obj.get('name'):
                emit('identity', obj=oid, card=card(obj), face_down=False)
            detail(obj, old)
        for oid, old in previous.items():
            if oid not in current:
                if old['zone'] == 'Stack':
                    stack_ids.pop(oid, None)
                # Library identities and the opponent's hand are deliberately absent.
                target = 'library' if old['zone'] == 'Hand' else 'limbo'
                move(old, ZONES[old['zone']], target)
        # Reconcile counts after each observation, preserving unknown cards as
        # anonymous objects. This never supplies a hidden card name or identity.
        for n, player in enumerate(state['players'], start=1):
            reconcile(n, 'hand', player.get('hand_count'))
            reconcile(n, 'library', player.get('library_count'))
        attackers = [oid for oid, obj in current.items() if obj.get('zone') == 'Battlefield' and obj.get('attacking')]
        prior_attackers = [oid for oid, obj in previous.items() if obj.get('zone') == 'Battlefield' and obj.get('attacking')]
        if attackers and set(attackers) != set(prior_attackers):
            emit('attack', seat=seat(state['active']), objs=attackers, target_seat=None, target_obj=None)
        action = frame.get('action')
        if action and action['kind'] not in ('Pass',):
            actor = 'Agent' if action['actor'] == f'player_{viewer_seat-1}' else 'Opponent'
            label = action.get('label')
            description = f"{actor}: {label or action['kind']}"
            emit('note', log={'text': description, 'segments': [{'text': description}]})
        previous = current
        previous_state = state
        frame_ends.append(len(events)-1)
    if turns: turns[-1]['last_seq'] = len(events)-1
    outcome = last.get('outcome')
    winner = seat(outcome['Winner']) if isinstance(outcome, dict) and 'Winner' in outcome else None
    if outcome is not None:
        emit('game_end', winner_seat=winner, reason=None)
        if turns: turns[-1]['last_seq'] = len(events)-1
    result = 'draw' if outcome == 'Draw' else 'win' if winner == viewer_seat else 'loss' if winner is not None else 'unknown'
    return dict(version=1, fidelity='reconstructed', replay_version=None, limitations=limitations,
        game=dict(id='rustmage-'+str(recording['seed']), started_at=recording['started_at'], ended_at=recording.get('ended_at'),
                  format='XMage' if recording.get('source') == 'xmage-evaluation-jsonl' else 'RustMage', best_of=1, game_number=1, outcome=result, outcome_reason=recording.get('reason'),
                  winner_seat=winner, total_turns=last['turn'], duration_seconds=float(len(events))),
        player_seat=viewer_seat, seats={str(i+1): dict(role='player' if i+1 == viewer_seat else 'opponent', name=f'Player {i+1}',
            deck_name=None, starting_life=p['life'], went_first=(first['active']==f'P{i}'), commanders=[],
            deck_size=p['hand_count']+p['library_count'], colors=None) for i,p in enumerate(first['players'])},
        cards=cards, turns=turns, events=events, patchwork_frame_ends=frame_ends)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('recording', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--scryfall', action='store_true', help='Look up visible card metadata and images on Scryfall')
    parser.add_argument('--viewer', choices=('player_0', 'player_1'), default='player_0',
                        help='Perspective for existing XMage evaluation JSONL traces')
    args = parser.parse_args()
    if args.recording.name.endswith(('.jsonl', '.jsonl.gz')):
        from datetime import datetime, timezone
        from .xmage_trace import normalize, read_trace
        timestamp = datetime.fromtimestamp(args.recording.stat().st_mtime, timezone.utc).isoformat()
        recording = normalize(read_trace(args.recording), args.viewer, started_at=timestamp)
    else:
        recording = json.loads(args.recording.read_text())
    stream = convert(recording)
    if args.scryfall:
        from .card_metadata import enrich
        missing = enrich(stream)
        if missing: print('Scryfall did not resolve: ' + ', '.join(sorted(set(missing))))
    args.output.write_text(json.dumps(stream, indent=2)+'\n')
    print(f"Wrote {len(stream['events'])} events to {args.output}")


if __name__ == '__main__': main()
