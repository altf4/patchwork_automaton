"""Optional Scryfall metadata enrichment for replay card layout and artwork."""
import json
import time
from urllib.request import Request, urlopen


def enrich(stream, *, fetch=None):
    """Look up names in batches of at most 75. Returns names not found.

    The caller must opt in: visible card names are sent to Scryfall. Failures
    propagate and no partial replay is written by the command-line caller.
    """
    cards = list(stream['cards'].values())
    names = list(dict.fromkeys(card['name'] for card in cards if card.get('name')))
    lookup = {}
    if fetch is None:
        def fetch(batch):
            body = json.dumps({'identifiers': [{'name': name} for name in batch]}).encode()
            request = Request('https://api.scryfall.com/cards/collection', data=body, method='POST',
                              headers={'Content-Type':'application/json', 'Accept':'application/json',
                                       'User-Agent':'PatchworkAutomatonReplay/1.0'})
            with urlopen(request, timeout=30) as response:
                return json.load(response)
    for start in range(0, len(names), 75):
        if start: time.sleep(0.1)
        result = fetch(names[start:start+75])
        for data in result.get('data', []):
            name = data.get('name')
            if name: lookup[name.casefold()] = data
            # The trace can name a face instead of the combined card name.
            for face in data.get('card_faces', []):
                if face.get('name'): lookup.setdefault(face['name'].casefold(), data)
    missing = []
    for card in cards:
        data = lookup.get(card['name'].casefold())
        if not data:
            missing.append(card['name'])
            continue
        faces = data.get('card_faces') or []
        face = next((f for f in faces if f.get('name', '').casefold() == card['name'].casefold()), None)
        selected = face or data
        type_line = selected.get('type_line') or data.get('type_line')
        if type_line:
            card['type_line'] = type_line
            types = type_line.split('—', 1)[0].lower()
            card['primary_type'] = next((t for t in ('Creature', 'Land', 'Planeswalker', 'Battle',
                'Artifact', 'Enchantment', 'Instant', 'Sorcery') if t.lower() in types), None)
        for attr in ('power', 'toughness', 'mana_cost'):
            if selected.get(attr) is not None: card[attr] = str(selected[attr])
        images = selected.get('image_uris') or data.get('image_uris') or {}
        if images.get('normal'): card['image_url'] = images['normal']
        card['faces'] = [{'name': f.get('name', ''), 'type_line': f.get('type_line')} for f in faces]
        card['back_face'] = bool(face and len(faces) > 1 and face is faces[1])
    return missing
