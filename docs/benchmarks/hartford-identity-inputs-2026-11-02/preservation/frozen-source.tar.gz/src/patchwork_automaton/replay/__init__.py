"""Recording and conversion tools for visual review of bot games."""
