"""Whole-game sampling and seat-relative labels for a small value bootstrap."""
from collections import defaultdict
from copy import deepcopy
import random


def outcome_target(game, player):
    if player not in (0, 1) or game['status'] not in ('win', 'loss', 'draw'):
        raise ValueError('A verified game outcome and physical seat are required')
    if game.get('reason') == 'wall_clock_timeout':
        raise ValueError('Wall-clock adjudications are not value targets')
    if game['status'] == 'draw':
        if game.get('winner_seat') is not None:
            raise ValueError('Draw cannot have a winner')
        return 0.
    winner = game.get('winner_seat')
    if winner not in (0, 1):
        raise ValueError('Missing winner seat')
    if (game['status'] == 'win') != (winner == 0):
        raise ValueError('Result disagrees with the physical winner seat')
    return 1. if player == winner else -1.


def select_games(games, count=1200, seed=30261029):
    if count < 120 or count % 120:
        raise ValueError('Game count must be a positive multiple of 120')
    groups = defaultdict(list)
    seen = set()
    for game in games:
        if game['seed'] in seen:
            raise ValueError('Duplicate demonstration seed')
        seen.add(game['seed'])
        if (game['status'] not in ('win', 'loss', 'draw')
                or game.get('reason') == 'wall_clock_timeout'
                or len(game['trajectories']) != 2
                or any(t.get('partial') for t in game['trajectories'])):
            continue
        if {t['player'] for t in game['trajectories']} != {0, 1}:
            raise ValueError('Demonstrations must retain both physical seats')
        # Four physical schedule strata also distinguish duplicate mirror layouts.
        key = (tuple(game['pairing']), game['index'] % 4, game['partition'])
        groups[key].append(game)
    pairs = sorted({k[0] for k in groups})
    if len(pairs) != 6:
        raise ValueError('Require the six Standard pairings')
    rng = random.Random(seed)
    selected = []
    for pair in pairs:
        for stratum in range(4):
            for partition, wanted in (('training', count // 30), ('validation', count // 120)):
                candidates = groups[(pair, stratum, partition)].copy()
                rng.shuffle(candidates)
                if len(candidates) < wanted:
                    raise ValueError(f'Insufficient complete examples: {pair}, {stratum}, {partition}')
                for original in candidates[:wanted]:
                    game = deepcopy(original)
                    for trajectory in game['trajectories']:
                        trajectory['target'] = outcome_target(game, trajectory['player'])
                    selected.append(game)
    return sorted(selected, key=lambda g: g['index'])


def select_next_games(games, previous, count=1200, seed=30261030, excluded_training_seeds=()):
    """Fresh training games, with exactly the same independent validation cohort."""
    validation = {g['seed'] for g in previous if g['partition'] == 'validation'}
    used = {g['seed'] for g in previous} | set(excluded_training_seeds)
    eligible = [g for g in games if
                (g['partition'] == 'training' and g['seed'] not in used)
                or (g['partition'] == 'validation' and g['seed'] in validation)]
    selected = select_games(eligible, count=count, seed=seed)
    if {g['seed'] for g in selected if g['partition'] == 'validation'} != validation:
        raise ValueError('Continuation must preserve the complete validation cohort')
    return selected
