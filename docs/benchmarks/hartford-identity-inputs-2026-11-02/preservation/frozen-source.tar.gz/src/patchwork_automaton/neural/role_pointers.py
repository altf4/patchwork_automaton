"""Recover ordered source/target/other entity references from saved actions.

Version-5 demonstrations store each role's static traits and live entity facts,
but only the average of their entity pointers. This adapter uses those stored
facts and that average to recover the original pointers. It never guesses when
multiple assignments fit.
"""

from itertools import product

import numpy as np


ROLE_NAMES = ('source', 'target', 'other')


def role_layout(manifest):
    """Read action and role widths from the saved encoder, not current source."""
    if manifest.get('feature_version') != 5:
        raise ValueError('Role pointer experiment requires saved Standard feature version 5')
    spec = manifest['feature_spec']
    action_width = len(manifest['actions'])
    semantic_width, entity_width = spec['semantics'], spec['entities']
    role_width = 1 + semantic_width + entity_width
    if spec['candidates'] < action_width + 3 * role_width:
        raise ValueError('Saved candidate width cannot contain three role blocks')
    return action_width, semantic_width, entity_width, role_width


def reconstruct_role_refs(arrays, manifest, *, marginalize=False):
    """Return (A, 3, N) one-hot role pointers and one status per legal choice.

    `resolved` includes role-free actions. `ambiguous` means multiple role
    assignments match the saved average. With `marginalize=True`, its pointer
    is the mean of every valid assignment, preserving only identifiable
    information. `unmatched` means none match and must remain a hard failure.
    """
    action_width, semantic_width, entity_width, role_width = role_layout(manifest)
    candidates = arrays['candidates']
    refs = arrays['candidate_refs']
    entities = arrays['entities']
    semantics = arrays['semantics'][:, 0]
    mask = arrays['candidate_mask']
    if (candidates.ndim != 2 or refs.shape != (len(candidates), len(entities))
            or entities.shape[1] != entity_width
            or semantics.shape != (len(entities), semantic_width)
            or len(mask) != len(candidates)
            or candidates.shape[1] != manifest['feature_spec']['candidates']):
        raise ValueError('Saved demonstration arrays do not match encoder manifest')

    role_refs = np.zeros((len(candidates), 3, len(entities)), np.float32)
    statuses = []
    for action in np.flatnonzero(mask):
        row = candidates[action]
        pooled = refs[action]
        support = np.flatnonzero(pooled > 0)
        options = []
        invalid = False
        for role in range(3):
            start = action_width + role * role_width
            block = row[start:start + role_width]
            present = block[0]
            traits = block[1:1 + semantic_width]
            live = block[1 + semantic_width:]
            if present == 0 and not np.any(block[1:]):
                options.append((None,))
            elif present == 1 and role == 0 and not np.any(live):
                # Stack/pending source name: a static trait, no visible entity.
                options.append((None,))
            elif present == 1 and np.any(live):
                matches = tuple(int(i) for i in support
                    if np.array_equal(entities[i], live)
                    and np.array_equal(semantics[i], traits))
                if not matches:
                    invalid = True
                    break
                options.append(matches)
            else:
                invalid = True
                break
        if invalid:
            statuses.append('unmatched')
            continue
        solutions = []
        for assignment in product(*options):
            linked = [index for index in assignment if index is not None]
            composed = np.zeros(len(entities), np.float32)
            for index in linked:
                composed[index] += 1
            composed /= max(len(linked), 1)
            if np.allclose(composed, pooled, rtol=0, atol=1e-6):
                solutions.append(assignment)
                if len(solutions) > 1 and not marginalize:
                    break
        if len(solutions) != 1:
            status = 'ambiguous' if solutions else 'unmatched'
            statuses.append(status)
            if status == 'ambiguous' and marginalize:
                weight = 1. / len(solutions)
                for assignment in solutions:
                    for role, index in enumerate(assignment):
                        if index is not None:
                            role_refs[action, role, index] += weight
            continue
        for role, index in enumerate(solutions[0]):
            if index is not None:
                role_refs[action, role, index] = 1
        statuses.append('resolved')
    return role_refs, statuses


def exact_role_refs_from_indices(arrays, manifest, candidate, roles):
    """Validate replayed ordered entity indices against saved role blocks/pool."""
    action_width, semantic_width, entity_width, role_width = role_layout(manifest)
    entities = arrays['entities']
    semantics = arrays['semantics'][:, 0]
    row = arrays['candidates'][candidate]
    if (not arrays['candidate_mask'][candidate] or len(roles) != 3
            or entities.shape[1] != entity_width
            or semantics.shape != (len(entities), semantic_width)):
        raise ValueError('Invalid replayed role row or saved entity arrays')
    pointers = np.zeros((3, len(entities)), np.float32)
    for role, index in enumerate(roles):
        start = action_width + role * role_width
        block = row[start:start + role_width]
        if index is None:
            absent = block[0] == 0 and not np.any(block[1:])
            named_source = role == 0 and block[0] == 1 and not np.any(
                block[1 + semantic_width:])
            if not absent and not named_source:
                raise ValueError('Replayed null role contradicts saved role block')
        else:
            if (type(index) is not int or not 0 <= index < len(entities)
                    or block[0] != 1
                    or not np.array_equal(block[1:1 + semantic_width], semantics[index])
                    or not np.array_equal(block[1 + semantic_width:], entities[index])):
                raise ValueError('Replayed entity index contradicts saved role block')
            pointers[role, index] = 1
    linked = pointers.sum(axis=0)
    pooled = linked / max(float(linked.sum()), 1.)
    if not np.allclose(pooled, arrays['candidate_refs'][candidate], rtol=0, atol=1e-6):
        raise ValueError('Replayed ordered roles contradict saved pooled reference')
    return pointers
