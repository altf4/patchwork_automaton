"""Opt-in source/target/other residual on a frozen saved Standard actor.

The existing policy model and checkpoint are untouched. At initialization the
zero-initialized final layer makes every logit and memory state exactly equal
to the saved actor. A pooled-reference arm uses the same parameter count and
training code as the ordered-role arm.
"""

import keras
from keras import layers, ops

from .recurrent import masked_gru


class RoleResidualPolicy(keras.Model):
    def __init__(self, actor, *, action_width, hidden_width=64,
                 target_context_index=None, **kwargs):
        super().__init__(**kwargs)
        if action_width < 1 or hidden_width < 1:
            raise ValueError('Positive role scorer dimensions required')
        self.actor = actor
        self.actor.trainable = False
        self.action_width = action_width
        self.target_context_index = target_context_index
        self.memory_size = actor.memory_size
        self.feature_spec = actor.feature_spec
        self.role_hidden = layers.Dense(hidden_width, activation='gelu', name='role_hidden')
        self.role_score = layers.Dense(1, kernel_initializer='zeros',
                                       bias_initializer='zeros', name='role_score')

    def contextual_entities(self, inputs):
        """Reuse the frozen actor's exact entity layers for ordered readouts."""
        actor = self.actor
        entity_features = (actor.entity_standardization(inputs['entities'])
                           if actor.standardize_inputs else inputs['entities'])
        shape = ops.shape(inputs['semantics'])
        semantic = actor.semantic_projection(inputs['semantics'])
        semantic = ops.reshape(semantic, (-1, shape[2], 64))
        semantic_mask = ops.reshape(inputs['semantic_mask'], (-1, shape[2]))
        semantic = masked_gru(actor.semantic_gru, semantic, mask=semantic_mask, training=False)
        semantic = ops.reshape(semantic, (shape[0], shape[1], 64))
        entity = actor.entity_projection(ops.concatenate([
            actor.card_embedding(inputs['card_ids']), entity_features, semantic], axis=-1))
        valid = ops.cast(inputs['entity_mask'], entity.dtype)
        entity = entity * valid[:, :, None]
        messages = []
        for channel in range(4):
            links = inputs['relations'][:, :, :, channel] * valid[:, None, :]
            messages.append(ops.matmul(links, entity) /
                            ops.maximum(ops.sum(links, axis=-1, keepdims=True), 1.))
        entity = entity + actor.relation_projection(ops.concatenate(messages, axis=-1))
        mask = inputs['entity_mask'][:, :, None] & inputs['entity_mask'][:, None, :]
        for attention, norm, ff, ff_norm in zip(actor.attention, actor.attention_norm,
                                                actor.feedforward, actor.feedforward_norm):
            entity = norm(entity + attention(entity, entity, attention_mask=mask, training=False))
            entity = ff_norm(entity + ff(entity, training=False)) * valid[:, :, None]
        return ops.stop_gradient(entity)

    def role_features(self, inputs, *, base=None, entity=None):
        """Expose the exact residual input for saved-feature cache parity."""
        if base is None:
            base = self.actor(inputs, training=False)
        pointers = inputs.get('candidate_role_refs')
        if pointers is None:
            # Build-only/default parity path; experiment batches provide refs.
            pointers = ops.repeat(inputs['candidate_refs'][:, :, None, :], 3, axis=2)
        if entity is None:
            entity = self.contextual_entities(inputs)
        role = ops.einsum('bark,bkw->barw', pointers, entity)
        role = ops.reshape(role, (ops.shape(role)[0], ops.shape(role)[1], 3 * self.actor.width))
        state = ops.broadcast_to(base['memory_out'][:, None, :],
                                 (ops.shape(role)[0], ops.shape(role)[1], self.memory_size))
        action = inputs['candidates'][:, :, :self.action_width]
        return ops.concatenate([role, state, action], axis=-1), base

    def call(self, inputs, training=False):
        features, base = self.role_features(inputs)
        residual = ops.squeeze(self.role_score(self.role_hidden(features)), axis=-1)
        if self.target_context_index is not None:
            target = ops.cast(inputs['context'][:, self.target_context_index], residual.dtype)
            residual = residual * target[:, None]
        logits = base['logits'] + residual
        logits = ops.where(inputs['candidate_mask'], logits, ops.full_like(logits, -1.e9))
        return dict(logits=logits, value=base['value'], memory_out=base['memory_out'])
