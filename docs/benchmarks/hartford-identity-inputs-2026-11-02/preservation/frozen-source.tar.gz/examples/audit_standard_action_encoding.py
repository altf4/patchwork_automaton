"""Audit indistinguishable legal choices in saved Standard demonstrations.

This reads recorded numerical decisions only. A full-input tie means two legal
choices have exactly the same candidate row and candidate_refs row, so the
current candidate-scoring actor cannot distinguish them in that position.
These ties are an upper bound on harmful ambiguity: saved demonstrations do
not retain raw action identities, and identical-card copies may be equivalent.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import tempfile

import numpy as np

from patchwork_automaton.neural.demonstrations import read_demonstration


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def candidate_bucket(count):
    if count == 2:
        return '2'
    for limit, label in ((4, '3-4'), (8, '5-8'), (16, '9-16'), (32, '17-32')):
        if count <= limit:
            return label
    return '33+'


def _groups(rows, legal):
    groups = defaultdict(list)
    for index in legal:
        groups[rows[index].tobytes()].append(int(index))
    return [group for group in groups.values() if len(group) > 1]


def inspect_decision(arrays, action):
    """Return exact numerical ties without interpreting raw action semantics."""
    candidates = np.asarray(arrays['candidates'])
    refs = np.asarray(arrays['candidate_refs'])
    mask = np.asarray(arrays['candidate_mask'])
    if (candidates.ndim != 2 or refs.ndim != 2 or mask.ndim != 1
            or len(candidates) != len(refs) or len(candidates) != len(mask)
            or candidates.dtype != np.float32 or refs.dtype != np.float32
            or not np.isfinite(candidates).all() or not np.isfinite(refs).all()):
        raise ValueError('Invalid saved Standard candidate tensors')
    legal = np.flatnonzero(mask)
    if len(legal) < 2 or type(action) is not int or action not in legal:
        raise ValueError('Saved demonstration has no valid expert choice')
    full = defaultdict(list)
    for index in legal:
        full[(candidates[index].tobytes(), refs[index].tobytes())].append(int(index))
    full_ties = [group for group in full.values() if len(group) > 1]
    candidate_ties = _groups(candidates, legal)
    expert_class = next((group for group in full_ties if action in group), [action])
    return dict(candidate_count=len(legal), full_tie_groups=full_ties,
                candidate_feature_tie_groups=candidate_ties,
                expert_tie_size=len(expert_class),
                expert_multi_entity_refs=int(np.count_nonzero(refs[action])) >= 2)


def _tally(counter, result):
    counter['decisions'] += 1
    counter['candidates'] += result['candidate_count']
    counter['exact_full_input_tie_decisions'] += bool(result['full_tie_groups'])
    counter['exact_full_input_tied_options'] += sum(map(len, result['full_tie_groups']))
    counter['expert_exactly_tied_decisions'] += result['expert_tie_size'] > 1
    counter['candidate_feature_tie_decisions'] += bool(result['candidate_feature_tie_groups'])
    counter['expert_multi_entity_reference_decisions'] += result['expert_multi_entity_refs']


def _statistics(counter):
    result = dict(counter)
    decisions = result.get('decisions', 0)
    result['exact_full_input_tie_rate'] = (result.get('exact_full_input_tie_decisions', 0) / decisions
                                           if decisions else None)
    result['expert_exactly_tied_rate'] = (result.get('expert_exactly_tied_decisions', 0) / decisions
                                          if decisions else None)
    return result


def select_games(games, *, partition, max_games):
    """Round-robin deck pairings so a bounded audit does not sample one pair."""
    groups = defaultdict(list)
    for game in games:
        if game.get('status') not in ('win', 'loss', 'draw'):
            continue
        if partition != 'all' and game.get('partition') != partition:
            continue
        groups[tuple(game['pairing'])].append(game)
    for group in groups.values():
        group.sort(key=lambda row: row['index'])
    keys = sorted(groups)
    chosen = []
    position = 0
    while len(chosen) < max_games:
        next_round = [groups[key][position] for key in keys if position < len(groups[key])]
        if not next_round:
            break
        chosen.extend(next_round[:max_games - len(chosen)])
        position += 1
    return chosen


def _trajectory_path(dataset_path, trajectory):
    path = Path(trajectory['path'])
    if path.is_absolute() and path.is_file():
        return path
    candidates = (dataset_path.parent / path,
                  dataset_path.parent / 'trajectories' / path.name)
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(path)


def audit_dataset(dataset_path, *, partition='validation', max_games=200,
                  max_decisions=50000, max_examples=20):
    if partition not in ('validation', 'training', 'all'):
        raise ValueError('Unknown dataset partition')
    if min(max_games, max_decisions) < 1 or max_examples < 0:
        raise ValueError('Positive game/decision limits and nonnegative examples required')
    dataset_path = Path(dataset_path).resolve()
    dataset = json.loads(dataset_path.read_text())
    if not isinstance(dataset.get('games'), list) or not isinstance(dataset.get('encoder'), dict):
        raise ValueError('Expected Standard demonstration dataset manifest')
    games = select_games(dataset['games'], partition=partition, max_games=max_games)
    if not games:
        raise ValueError('No completed Standard games in selected partition')
    totals = Counter()
    groupings = {name: defaultdict(Counter) for name in (
        'decision_kind', 'chosen_action_kind', 'deck', 'candidate_count')}
    examples = []
    visited_games = 0
    visited_trajectories = 0
    for game in games:
        if totals['decisions'] >= max_decisions:
            break
        visited_games += 1
        for trajectory in game['trajectories']:
            if totals['decisions'] >= max_decisions:
                break
            path = _trajectory_path(dataset_path, trajectory)
            visited_trajectories += 1
            for ordinal, sample in enumerate(read_demonstration(dict(trajectory, path=str(path)))):
                if totals['decisions'] >= max_decisions:
                    break
                result = inspect_decision(sample.arrays, sample.action)
                _tally(totals, result)
                categories = dict(decision_kind=sample.decision_kind,
                                  chosen_action_kind=sample.action_kind,
                                  deck=trajectory['deck'],
                                  candidate_count=candidate_bucket(result['candidate_count']))
                for category, name in categories.items():
                    _tally(groupings[category][name], result)
                if result['full_tie_groups'] and len(examples) < max_examples:
                    examples.append(dict(game_index=game['index'], seed=game['seed'],
                        player=trajectory['player'], deck=trajectory['deck'],
                        decision_ordinal=ordinal, decision_kind=sample.decision_kind,
                        chosen_action_kind=sample.action_kind, expert_index=sample.action,
                        candidate_count=result['candidate_count'],
                        tie_groups=[group[:16] for group in result['full_tie_groups'][:8]],
                        tie_group_sizes=[len(group) for group in result['full_tie_groups'][:8]],
                        expert_tie_size=result['expert_tie_size']))
    return dict(schema=1, audit='standard_action_encoding',
                dataset=str(dataset_path), dataset_sha256=sha256(dataset_path),
                dataset_encoder_fingerprint=dataset['encoder'].get('fingerprint'),
                dataset_feature_spec=dataset['encoder'].get('feature_spec'),
                partition=partition, max_games=max_games, max_decisions=max_decisions,
                selected_games=visited_games, selected_trajectories=visited_trajectories,
                counts=_statistics(totals),
                by={name: {key: _statistics(counter) for key, counter in sorted(values.items())}
                    for name, values in groupings.items()},
                examples=examples,
                interpretation='Exact candidate+reference ties are indistinguishable to the current actor. '
                               'They are an upper bound on harmful ambiguity because raw legal actions and '
                               'interchangeable-card equivalence are absent from saved demonstrations.')


def write_new_json(path, report):
    path = Path(path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', dir=path.parent, prefix='.action-audit-',
                                         delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', required=True, type=Path, help='Saved Standard dataset.json')
    parser.add_argument('--partition', choices=('validation', 'training', 'all'), default='validation')
    parser.add_argument('--max-games', type=int, default=200)
    parser.add_argument('--max-decisions', type=int, default=50000)
    parser.add_argument('--max-examples', type=int, default=20)
    parser.add_argument('--output', required=True, type=Path, help='New JSON report file')
    args = parser.parse_args(argv)
    report = audit_dataset(args.dataset, partition=args.partition,
        max_games=args.max_games, max_decisions=args.max_decisions,
        max_examples=args.max_examples)
    write_new_json(args.output, report)
    print(json.dumps(dict(output=str(args.output.resolve()),
        selected_games=report['selected_games'], decisions=report['counts']['decisions'],
        exact_full_input_tie_decisions=report['counts'].get('exact_full_input_tie_decisions', 0),
        expert_exactly_tied_decisions=report['counts'].get('expert_exactly_tied_decisions', 0))), flush=True)


if __name__ == '__main__':
    main()
