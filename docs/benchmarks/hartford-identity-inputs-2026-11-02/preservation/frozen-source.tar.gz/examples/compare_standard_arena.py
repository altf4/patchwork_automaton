"""Compare two complete Standard arena runs on paired game schedules.

The first run is the baseline and the second is the candidate. A positive
score_delta means the candidate earned more win points on matched games.
Neither run is modified. Output must be a new JSON file.
"""

import argparse
import json
import os
from pathlib import Path
import tempfile

from patchwork_automaton.rl.standard_arena_compare import compare_runs


def parser():
    command = argparse.ArgumentParser(description=__doc__)
    command.add_argument('baseline', type=Path, help='Completed baseline arena directory')
    command.add_argument('candidate', type=Path, help='Completed candidate arena directory')
    command.add_argument('--output', type=Path, required=True, help='New JSON comparison file')
    command.add_argument('--bootstrap-samples', type=int, default=2000)
    command.add_argument('--bootstrap-seed', type=int, default=0)
    return command


def write_new_json(path, payload):
    """Durably publish a finished comparison without replacing a prior result."""
    path = Path(path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    data = json.dumps(payload, sort_keys=True, indent=2, allow_nan=False) + '\n'
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', dir=path.parent, prefix='.arena-compare-',
                                         delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)  # Fails if the destination already exists.
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv=None):
    args = parser().parse_args(argv)
    result = compare_runs(args.baseline, args.candidate,
                          bootstrap_samples=args.bootstrap_samples,
                          bootstrap_seed=args.bootstrap_seed)
    write_new_json(args.output, result)
    print(json.dumps(dict(output=str(args.output.resolve()), clean=result['clean'],
                          scheduled=result['aggregate']['scheduled'],
                          paired_completed=result['aggregate']['paired_completed'],
                          score_delta=result['aggregate']['score_delta'],
                          paired_bootstrap_95=result['aggregate']['paired_bootstrap_95'])),
          flush=True)
    return 0 if result['clean'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
