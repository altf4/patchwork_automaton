"""Cache frozen cp200 features at Standard v5 target decisions in one replay."""

import argparse
from dataclasses import dataclass
import inspect
import json
import os
from pathlib import Path
import time

os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS', '0')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')

import numpy as np

from examples.diagnose_standard_decisions import checkpoint_files, file_sha256
from examples.run_standard_role_ab import (pooled_control_refs, selected_stages,
    weights_sha256, write_atomic_json)
from patchwork_automaton.neural.demonstrations import read_demonstration
from patchwork_automaton.neural.role_pointers import (ROLE_NAMES,
    exact_role_refs_from_indices, reconstruct_role_refs)


ENTITY_KEYS = ('entities', 'card_ids', 'entity_mask', 'semantics',
               'semantic_mask', 'relations')


@dataclass
class TargetRecord:
    base_logits: np.ndarray
    ordered_features: np.ndarray
    pooled_features: np.ndarray
    memory_in: np.ndarray
    memory_out: np.ndarray
    label: int
    deck: str
    game: int
    player: int
    decision: int
    trajectory_path: str
    trajectory_samples: int
    ambiguous_candidate_count: int
    role_indices: np.ndarray


def load_exact_role_sidecar(sidecar_path, audit_path, manifest,
                            stages, checkpoint_sha, sample_seed):
    """Bind verified raw-replay roles to exactly the predeclared ambiguities."""
    audit_path = Path(audit_path).resolve()
    sidecar_path = Path(sidecar_path).resolve()
    audit = json.loads(audit_path.read_text())
    sidecar = json.loads(sidecar_path.read_text())
    audit_sha = file_sha256(audit_path)
    expected = {}
    for failure in audit['failures']:
        for candidate, status in failure['candidates']:
            if status != 'ambiguous':
                raise ValueError('Failure audit includes an unmatched target candidate')
            key = (failure['stage'], failure['game'], failure['player'],
                   failure['decision'], candidate)
            if key in expected:
                raise ValueError('Duplicate ambiguous target in failure audit')
            expected[key] = failure
    if (audit['encoder_fingerprint'] != manifest['fingerprint']
            or audit['checkpoint_sha256'] != checkpoint_sha
            or audit['sample_seed'] != sample_seed
            or len(expected) != audit['totals']['unresolved_candidates']
            or sidecar.get('schema') != 1
            or sidecar.get('status') != 'complete'
            or sidecar.get('role_order') != list(ROLE_NAMES)
            or sidecar.get('encoder_fingerprint') != manifest['fingerprint']
            or sidecar.get('failure_report_sha256') != audit_sha
            or sidecar.get('expected_rows') != len(expected)
            or sidecar.get('recovered_rows') != len(expected)
            or sidecar.get('expected_decisions') != len(audit['failures'])
            or sidecar.get('expected_games') != len({(key[0], key[1]) for key in expected})
            or Path(sidecar.get('failure_report', '')).resolve() != audit_path
            or sidecar.get('errors')):
        raise ValueError('Raw-replay sidecar does not match selected v5 ambiguity audit')
    for stage in stages:
        for partition in ('training', 'validation'):
            key = f"{stage['stage']}|{partition}"
            if audit['selected_games'][key] != len(stage[partition]):
                raise ValueError('Failure audit used different selected games')
        source = Path(stage['directory']) / 'dataset.json'
        digest = file_sha256(source)
        if (audit['datasets'][str(source)] != digest
                or sidecar['datasets'][str(stage['stage'])]['sha256'] != digest
                or Path(sidecar['datasets'][str(stage['stage'])]['path']).resolve() != source.resolve()):
            raise ValueError('Sidecar or audit dataset provenance differs')
    rows = {}
    for row in sidecar['rows']:
        key = (row['stage'], row['game'], row['player'],
               row['decision_ordinal'], row['candidate_index'])
        if key in rows or key not in expected:
            raise ValueError('Extra or duplicate raw-replay role override')
        if (row['partition'] != expected[key]['partition']
                or not isinstance(row['roles'], list) or len(row['roles']) != 3
                or 'raw_action' not in row or 'role_identity' not in row):
            raise ValueError('Malformed or wrong-partition raw-replay role override')
        rows[key] = row
    if set(rows) != set(expected):
        raise ValueError('Raw-replay sidecar is missing ambiguous target rows')
    expected_games = {(key[0], key[1]) for key in expected}
    verified_games = sidecar.get('verified_games', [])
    if ({(game['stage'], game['game']) for game in verified_games} != expected_games
            or len(verified_games) != len(expected_games)
            or any(game['decisions_verified'] < 1 for game in verified_games)):
        raise ValueError('Raw-replay verification does not cover every affected game')
    trajectories = sidecar.get('trajectory_sha256', {})
    if not isinstance(trajectories, dict):
        raise ValueError('Raw-replay trajectory hashes missing')
    if not {str(Path(failure['path']).resolve()) for failure in expected.values()} <= set(trajectories):
        raise ValueError('Affected saved trajectories lack raw-replay hashes')
    for path, digest in trajectories.items():
        if file_sha256(path) != digest:
            raise ValueError(f'Affected saved trajectory changed: {path}')
    return rows, dict(path=str(sidecar_path), sha256=file_sha256(sidecar_path),
                      failure_audit_path=str(audit_path),
                      failure_audit_sha256=audit_sha,
                      expected_rows=len(expected),
                      trajectory_sha256=trajectories)


class FrozenTargetExtractor:
    """Replay every recorded decision once; materialize only target choices."""

    def __init__(self, actor, role_policy, manifest, *, exact_roles,
                 consumed_keys, batch_size, unroll, device):
        import tensorflow as tf
        from patchwork_automaton.neural.batching import example_batch, input_signature
        from patchwork_automaton.neural.devices import canonical_device
        from patchwork_automaton.neural.imitation import ImitationTrainer

        self.actor, self.role_policy, self.manifest = actor, role_policy, manifest
        self.exact_roles, self.consumed_keys = exact_roles, consumed_keys
        self.batch_size, self.unroll, self.device = batch_size, unroll, canonical_device(device)
        self.action_width = len(manifest['actions'])
        self._chunks = ImitationTrainer._chunks.__get__(self)
        example = example_batch(actor.memory_size, actor.feature_spec)
        signature = input_signature(example)
        packed_signature = {key: tf.TensorSpec((None, *value.shape), value.dtype)
                            for key, value in signature.items()
                            if key not in ('memory_in', 'advance_memory')}
        self.replay_chunk = tf.function(self._replay_chunk, input_signature=[
            tf.TensorSpec((None, actor.memory_size), tf.float32), packed_signature,
            tf.TensorSpec((None, None), tf.float32)], autograph=False)
        entity_signature = {key: signature[key] for key in ENTITY_KEYS}
        self.contextual_entities = tf.function(role_policy.contextual_entities,
                                               input_signature=[entity_signature],
                                               autograph=False)

    def _replay_chunk(self, memory, packed, active):
        import tensorflow as tf
        logits = tf.TensorArray(tf.float32, size=tf.shape(active)[0])
        states = tf.TensorArray(tf.float32, size=tf.shape(active)[0])

        def body(t, state, logits, states):
            inputs = {key: value[t] for key, value in packed.items()}
            inputs.update(memory_in=state, advance_memory=active[t, :, None])
            output = self.actor(inputs, training=False)
            return (t + 1, output['memory_out'], logits.write(t, output['logits']),
                    states.write(t, output['memory_out']))

        _, memory, logits, states = tf.while_loop(
            lambda t, *_: t < tf.shape(active)[0],
            body, (0, memory, logits, states))
        return memory, logits.stack(), states.stack()

    def extract(self, games, *, stage, partition):
        from patchwork_automaton.neural.devices import device_scope
        streams = [(game, trajectory) for game in games
                   for trajectory in game['trajectories']]
        records, parity_cases, non_target_checks = [], [], []
        decisions = 0
        ambiguous_candidates = ambiguous_decisions = ambiguous_chosen = 0
        started = time.monotonic()
        for start in range(0, len(streams), self.batch_size):
            selected = streams[start:start + self.batch_size]
            samples_by_seat = [read_demonstration(trajectory)
                               for _, trajectory in selected]
            memory = np.zeros((len(selected), self.actor.memory_size), np.float32)
            offset = 0
            for packed, _, active, samples in self._chunks(samples_by_seat):
                before = memory.copy()
                with device_scope(self.device):
                    output = self.replay_chunk(memory, packed, active)
                memory, logits, states = (np.asarray(value) for value in output)
                if not all(np.isfinite(value).all() for value in (memory, logits, states)):
                    raise FloatingPointError('Nonfinite frozen cp200 replay')
                decisions += int(active.sum())
                positions = [(t, seat) for t, seat in zip(*np.nonzero(active))
                             if samples[t * len(selected) + seat].decision_kind == 'targets']
                if positions:
                    entity_inputs = {key: np.stack([packed[key][t, seat]
                                                    for t, seat in positions])
                                     for key in ENTITY_KEYS}
                    with device_scope(self.device):
                        entities = np.asarray(self.contextual_entities(entity_inputs))
                    if not np.isfinite(entities).all():
                        raise FloatingPointError('Nonfinite contextual entity cache features')
                    for i, (t, seat) in enumerate(positions):
                        sample = samples[t * len(selected) + seat]
                        raw = sample.arrays
                        if not np.all(raw['candidate_mask']):
                            raise ValueError('Target cache expects complete unpadded legal choices')
                        pointers, statuses = reconstruct_role_refs(raw, self.manifest)
                        if any(status == 'unmatched' for status in statuses):
                            raise ValueError(f'Unresolved saved target role: stage {stage}, game {selected[seat][0]["index"]}, decision {offset+t}')
                        ambiguity = statuses.count('ambiguous')
                        game, trajectory = selected[seat]
                        for candidate, status in enumerate(statuses):
                            if status != 'ambiguous':
                                continue
                            key = (stage, game['index'], trajectory['player'],
                                   int(offset+t), candidate)
                            row = self.exact_roles.get(key)
                            if row is None or key in self.consumed_keys:
                                raise ValueError(f'Missing or repeated exact replay role: {key}')
                            pointers[candidate] = exact_role_refs_from_indices(
                                raw, self.manifest, candidate, row['roles'])
                            self.consumed_keys.add(key)
                        ambiguous_candidates += ambiguity
                        ambiguous_decisions += int(bool(ambiguity))
                        ambiguous_chosen += int(statuses[sample.action] == 'ambiguous')
                        n, a = len(raw['entities']), len(raw['candidates'])
                        context = entities[i, :n]
                        ordered = np.einsum('arn,nw->arw', pointers, context).reshape(a, -1)
                        pooled = np.einsum('arn,nw->arw',
                                           pooled_control_refs(dict(raw, candidate_role_refs=pointers)),
                                           context).reshape(a, -1)
                        state = states[t, seat]
                        current_memory = before[seat] if t == 0 else states[t - 1, seat]
                        suffix = np.concatenate((np.broadcast_to(state, (a, len(state))),
                                                 raw['candidates'][:, :self.action_width]), axis=-1)
                        role_indices = np.full((a, 3), -1, np.int32)
                        for candidate in range(a):
                            for role in range(3):
                                linked = np.flatnonzero(pointers[candidate, role])
                                if len(linked) > 1:
                                    raise AssertionError('Exact sidecar yielded a soft role pointer')
                                if len(linked) == 1:
                                    role_indices[candidate, role] = int(linked[0])
                        record = TargetRecord(
                            base_logits=np.asarray(logits[t, seat, :a], np.float32),
                            ordered_features=np.concatenate((ordered, suffix), axis=-1).astype(np.float32),
                            pooled_features=np.concatenate((pooled, suffix), axis=-1).astype(np.float32),
                            memory_in=np.asarray(current_memory, np.float32).copy(),
                            memory_out=np.asarray(state, np.float32).copy(),
                            label=sample.action, deck=trajectory['deck'], game=game['index'],
                            player=trajectory['player'], decision=int(offset+t),
                            trajectory_path=str(trajectory['path']),
                            trajectory_samples=int(trajectory['samples']),
                            ambiguous_candidate_count=ambiguity,
                            role_indices=role_indices)
                        if (not np.isfinite(record.ordered_features).all()
                                or not np.isfinite(record.pooled_features).all()
                                or not np.isfinite(record.base_logits).all()
                                or not 0 <= record.label < a):
                            raise FloatingPointError('Invalid target feature cache record')
                        records.append(record)
                        if len(parity_cases) < 3 and record.decision > 0:
                            parity_cases.append((sample, pointers, record))
                if len(non_target_checks) < 3:
                    for t, seat in zip(*np.nonzero(active)):
                        sample = samples[t * len(selected) + seat]
                        if sample.decision_kind == 'targets' or offset + t == 0:
                            continue
                        current_memory = before[seat] if t == 0 else states[t - 1, seat]
                        non_target_checks.append(dict(path=str(selected[seat][1]['path']),
                            samples=int(selected[seat][1]['samples']), ordinal=int(offset+t),
                            memory_in=np.asarray(current_memory).tolist()))
                        if len(non_target_checks) == 3:
                            break
                offset += len(active)
            if (start // self.batch_size + 1) % 8 == 0 or start + self.batch_size >= len(streams):
                print(json.dumps(dict(event='cache_progress', stage=stage, partition=partition,
                    trajectories=min(start + self.batch_size, len(streams)),
                    total_trajectories=len(streams), decisions=decisions,
                    targets=len(records), ambiguous_decisions=ambiguous_decisions,
                    elapsed_seconds=time.monotonic() - started)), flush=True)
        if not records:
            raise ValueError('No target decisions in selected games')
        return records, parity_cases, non_target_checks, dict(
            games=len(games), trajectories=len(streams), decisions=decisions,
            targets=len(records), ambiguous_decisions=ambiguous_decisions,
            ambiguous_candidates=ambiguous_candidates,
            ambiguous_chosen=ambiguous_chosen,
            elapsed_seconds=time.monotonic() - started)


def verify_online_cache_parity(actor, role_policy, cases, *, target_context_index, device):
    from patchwork_automaton.neural.devices import device_scope
    from patchwork_automaton.neural.features import collate
    rows = []
    for sample, pointers, record in cases:
        arrays = sample.arrays
        batch = collate([arrays])
        batch['candidate_role_refs'] = pointers[None]
        batch['memory_in'] = record.memory_in[None]
        batch['advance_memory'] = np.ones((1, 1), np.float32)
        if batch['context'][0, target_context_index] != 1:
            raise AssertionError('Cached target does not have target decision context')
        with device_scope(device):
            base = actor(batch, training=False)
            ordered, online = role_policy.role_features(batch)
            pooled_batch = dict(batch, candidate_role_refs=pooled_control_refs(
                dict(arrays, candidate_role_refs=pointers))[None])
            pooled, _ = role_policy.role_features(pooled_batch)
        a = len(arrays['candidates'])
        deltas = dict(
            base_logits=float(np.max(np.abs(np.asarray(base['logits'])[0, :a] - record.base_logits))),
            memory=float(np.max(np.abs(np.asarray(online['memory_out'])[0] - record.memory_out))),
            ordered_features=float(np.max(np.abs(np.asarray(ordered)[0, :a] - record.ordered_features))),
            pooled_features=float(np.max(np.abs(np.asarray(pooled)[0, :a] - record.pooled_features))))
        if any(value > 1e-4 for value in deltas.values()):
            raise AssertionError(f'Online/cache target parity failed: {deltas}')
        rows.append(dict(game=int(record.game), player=int(record.player),
                         decision=int(record.decision), **deltas))
    if len(rows) < 3:
        raise ValueError('At least three real post-history target parity cases required')
    return rows


def save_shard(path, records):
    offsets = np.zeros(len(records) + 1, np.int64)
    offsets[1:] = np.cumsum([len(record.base_logits) for record in records])
    arrays = dict(offsets=offsets,
        base_logits=np.concatenate([record.base_logits for record in records]),
        ordered_features=np.concatenate([record.ordered_features for record in records]),
        pooled_features=np.concatenate([record.pooled_features for record in records]),
        memory_in=np.stack([record.memory_in for record in records]),
        memory_out=np.stack([record.memory_out for record in records]),
        labels=np.asarray([record.label for record in records], np.int32),
        decks=np.asarray([record.deck for record in records], dtype='<U48'),
        games=np.asarray([record.game for record in records], np.int64),
        players=np.asarray([record.player for record in records], np.int8),
        decisions=np.asarray([record.decision for record in records], np.int32),
        ambiguous_candidate_count=np.asarray([record.ambiguous_candidate_count
                                               for record in records], np.int16),
        role_indices=np.concatenate([record.role_indices for record in records]),
        paths=np.asarray([record.trajectory_path for record in records],
                         dtype=f'<U{max(len(record.trajectory_path) for record in records)}'),
        trajectory_samples=np.asarray([record.trajectory_samples for record in records], np.int32))
    if any(not np.isfinite(value).all() for value in arrays.values()
           if np.issubdtype(value.dtype, np.floating)):
        raise FloatingPointError('Nonfinite target feature shard')
    temporary = path.with_suffix('.tmp.npz')
    np.savez_compressed(temporary, **arrays)
    os.replace(temporary, path)
    return dict(path=str(path), sha256=file_sha256(path),
                records=len(records), candidate_rows=int(offsets[-1]),
                feature_width=int(arrays['ordered_features'].shape[-1]),
                bytes=path.stat().st_size)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--checkpoint-sha256', required=True)
    p.add_argument('--datasets', nargs=2, type=Path, required=True)
    p.add_argument('--failure-audit', type=Path, required=True,
                   help='Read-only audit of all selected v5 target role failures')
    p.add_argument('--role-sidecar', type=Path, required=True,
                   help='Verified raw-replay exact role mapping for every ambiguous candidate')
    p.add_argument('--train-games-per-stage', type=int, default=600)
    p.add_argument('--validation-games-per-stage', type=int, default=240)
    p.add_argument('--sample-seed', type=int, default=73)
    p.add_argument('--batch-size', type=int, default=16)
    p.add_argument('--unroll', type=int, default=8)
    p.add_argument('--device', choices=('cpu', 'gpu'), default='gpu')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(argv)
    if min(args.train_games_per_stage, args.validation_games_per_stage,
           args.batch_size, args.unroll) < 1 or args.sample_seed < 0:
        p.error('Positive budgets and nonnegative sample seed required')
    if args.output.exists():
        raise FileExistsError(args.output)

    import keras
    from examples import diagnose_standard_decisions, run_standard_role_ab
    from patchwork_automaton.neural import (batching, demonstrations, devices,
        features, imitation, model, recurrent, role_pointers)
    from patchwork_automaton.neural.devices import configure_runtime, device_scope
    from patchwork_automaton.neural.role_residual import RoleResidualPolicy

    policy_path, sidecar = checkpoint_files(args.checkpoint)
    checkpoint_sha = file_sha256(policy_path)
    if checkpoint_sha != args.checkpoint_sha256:
        raise ValueError('Frozen cp200 checkpoint hash mismatch')
    manifest = json.loads(sidecar.read_text())
    if manifest.get('feature_version') != 5:
        raise ValueError('Only saved Standard v5 demonstrations are supported')
    stages = selected_stages(args.datasets, manifest,
        train_games_per_stage=args.train_games_per_stage,
        validation_games_per_stage=args.validation_games_per_stage,
        sample_seed=args.sample_seed)
    exact_roles, sidecar_provenance = load_exact_role_sidecar(
        args.role_sidecar, args.failure_audit, manifest, stages,
        checkpoint_sha, args.sample_seed)
    consumed_keys = set()
    dataset_hashes = {str((Path(directory).resolve() / 'dataset.json')):
                      file_sha256(Path(directory) / 'dataset.json') for directory in args.datasets}
    configure_runtime(args.device, hide_gpu=args.device == 'cpu')
    with device_scope(args.device):
        saved = keras.saving.load_model(policy_path, compile=False)
        if dict(saved.feature_spec) != manifest['feature_spec']:
            raise ValueError('Checkpoint model and v5 dataset feature schemas differ')
        actor = saved.actor if getattr(saved, 'separate_value', False) else saved
        actor.trainable = False
        target_context_index = len(manifest['steps']) + manifest['decisions'].index('targets')
        wrapper = RoleResidualPolicy(actor, action_width=len(manifest['actions']),
                                     target_context_index=target_context_index)
        actor_sha = weights_sha256(actor)
        extractor = FrozenTargetExtractor(actor, wrapper, manifest,
            exact_roles=exact_roles, consumed_keys=consumed_keys,
            batch_size=args.batch_size, unroll=args.unroll, device=args.device)

    args.output.mkdir(parents=True, exist_ok=False)
    code_paths = tuple(Path(inspect.getsourcefile(source)).resolve() for source in (
        FrozenTargetExtractor, RoleResidualPolicy, role_pointers,
        run_standard_role_ab, diagnose_standard_decisions, model, imitation,
        features, batching, demonstrations, recurrent, devices))
    report = dict(schema=1, status='extracting',
        checkpoint=dict(path=str(policy_path), sha256=checkpoint_sha,
                        manifest_path=str(sidecar), manifest_sha256=file_sha256(sidecar),
                        actor_weights_sha256=actor_sha),
        encoder_fingerprint=manifest['fingerprint'], datasets=dataset_hashes,
        source_sha256={str(path): file_sha256(path) for path in code_paths},
        raw_role_sidecar=sidecar_provenance,
        config=dict(train_games_per_stage=args.train_games_per_stage,
                    validation_games_per_stage=args.validation_games_per_stage,
                    sample_seed=args.sample_seed, batch_size=args.batch_size,
                    unroll=args.unroll, device=args.device),
        stages=[], shards=[], parity=[], non_target_checks=[])
    write_atomic_json(args.output / 'cache.partial.json', report)
    for stage in stages:
        stage_row = dict(stage=stage['stage'], directory=stage['directory'],
            eligible_training=stage['eligible_training'],
            eligible_validation=stage['eligible_validation'],
            excluded_adjudicated_empty=stage['excluded_adjudicated_empty'],
            selected_training_games=[[g['index'], g['seed']] for g in stage['training']],
            selected_validation_games=[[g['index'], g['seed']] for g in stage['validation']])
        report['stages'].append(stage_row)
        for partition in ('training', 'validation'):
            records, cases, controls, stats = extractor.extract(
                stage[partition], stage=stage['stage'], partition=partition)
            parity = verify_online_cache_parity(actor, wrapper, cases,
                target_context_index=target_context_index, device=args.device)
            shard_path = args.output / f'stage-{stage["stage"]}-{partition}.npz'
            shard = save_shard(shard_path, records)
            shard.update(stage=stage['stage'], partition=partition, stats=stats)
            report['shards'].append(shard)
            report['parity'].extend(parity)
            report['non_target_checks'].extend(controls[:3])
            write_atomic_json(args.output / 'cache.partial.json', report)
            print(json.dumps(dict(event='cache_shard_complete', stage=stage['stage'],
                partition=partition, targets=len(records), seconds=stats['elapsed_seconds'],
                sha256=shard['sha256'])), flush=True)
    if weights_sha256(actor) != actor_sha or file_sha256(policy_path) != checkpoint_sha:
        raise AssertionError('Frozen cp200 changed during feature extraction')
    if consumed_keys != set(exact_roles):
        raise AssertionError('Cache did not consume every audited exact replay role')
    report['raw_role_sidecar']['consumed_rows'] = len(consumed_keys)
    if (file_sha256(sidecar_provenance['path']) != sidecar_provenance['sha256']
            or file_sha256(sidecar_provenance['failure_audit_path'])
            != sidecar_provenance['failure_audit_sha256']):
        raise AssertionError('Raw role sidecar or failure audit changed during extraction')
    if any(file_sha256(path) != digest for path, digest in dataset_hashes.items()):
        raise AssertionError('Saved demonstration manifest changed during extraction')
    report['status'] = 'complete'
    write_atomic_json(args.output / 'cache.json', report)
    (args.output / 'cache.partial.json').unlink()
    print(json.dumps(dict(output=str(args.output.resolve()),
        total_targets=sum(shard['records'] for shard in report['shards']),
        total_decisions=sum(shard['stats']['decisions'] for shard in report['shards']),
        parity_cases=len(report['parity']))), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
