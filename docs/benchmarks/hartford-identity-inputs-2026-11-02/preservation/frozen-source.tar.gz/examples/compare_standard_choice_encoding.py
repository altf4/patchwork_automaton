"""Replay audited v5 Standard choices and measure opt-in v6 tie resolution.

The saved v5 arrays and scripted actions are verified before each comparison.
This is a bounded representation audit, not training or a win-rate evaluation.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

import numpy as np

from examples.audit_standard_action_encoding import (
    _trajectory_path, inspect_decision, sha256, write_new_json)
from examples.classify_standard_action_ties import classify_group
from patchwork_automaton.backends.rustmage import RustMageMatch, domain_action
from patchwork_automaton.baselines.standard import StandardAggro
from patchwork_automaton.baselines.standard_decks import standard_deck
from patchwork_automaton.neural.demonstrations import expert_index, read_demonstration
from patchwork_automaton.neural.rustmage_observation import learning_observation
from patchwork_automaton.neural.standard_choice_features import StandardChoiceEncoder
from patchwork_automaton.neural.standard_features import StandardEncoder


def tied_subgroups(arrays, indices):
    grouped = defaultdict(list)
    for index in indices:
        key = (arrays['candidates'][index].tobytes(),
               arrays['candidate_refs'][index].tobytes())
        grouped[key].append(index)
    return [group for group in grouped.values() if len(group) > 1]


def compare_group(old_group, old_actions, new_arrays, raw):
    old_category = classify_group(old_actions, raw)['category']
    new_groups = tied_subgroups(new_arrays, old_group)
    new_categories = [classify_group(
        [old_actions[old_group.index(index)] for index in group], raw)['category']
        for group in new_groups]
    if not new_groups:
        status = 'fully_split'
    elif len(new_groups) == 1 and len(new_groups[0]) == len(old_group):
        status = 'unchanged'
    else:
        status = 'partly_split'
    return dict(old_indices=old_group, old_category=old_category,
                status=status, remaining_tie_groups=new_groups,
                remaining_categories=new_categories)


def compare_game(game, records, targets, *, max_steps=6000):
    old = StandardEncoder()
    new = StandardChoiceEncoder()
    policies = [StandardAggro(deck) for deck in game['decks']]
    ordinals = [0, 0]
    found = {}
    with RustMageMatch(*(standard_deck(deck) for deck in game['decks']),
            seed=game['seed'], starting_player=game['starting_player']) as match:
        for step in range(max_steps):
            views = [learning_observation(match, f'P{player}') for player in range(2)]
            if views[0].terminal:
                break
            actors = [player for player, view in enumerate(views)
                      if view.decision is not None]
            if len(actors) != 1:
                raise RuntimeError(f'Expected one prompted player at step {step}')
            player = actors[0]
            view = views[player]
            response = policies[player].choose(view)
            choices = old.expand_options(view.decision)
            if len(choices) > 1:
                ordinal = ordinals[player]
                ordinals[player] += 1
                if ordinal >= len(records[player]):
                    raise ValueError(f'Extra replay decision at P{player} ordinal {ordinal}')
                sample = records[player][ordinal]
                expert = expert_index(view.decision, response, choices)
                if (sample.decision_kind != view.decision.kind
                        or sample.action_kind != choices[expert][1]['kind']
                        or sample.action != expert):
                    raise ValueError(f'Scripted replay diverged at P{player} ordinal {ordinal}')
                key = (player, ordinal)
                if key in targets:
                    old_arrays = old.encode(view, choices=choices).arrays
                    for name in ('candidates', 'candidate_refs', 'context', 'entities'):
                        if not np.array_equal(sample.arrays[name], old_arrays[name]):
                            raise ValueError(f'Saved v5 {name} diverged at P{player} ordinal {ordinal}')
                    old_inspection = inspect_decision(old_arrays, expert)
                    target = targets[key]
                    if ([group[:16] for group in old_inspection['full_tie_groups'][:8]]
                            != target['tie_groups']
                            or [len(group) for group in old_inspection['full_tie_groups'][:8]]
                                != target['tie_group_sizes']):
                        raise ValueError(f'Saved v5 tie groups diverged at P{player} ordinal {ordinal}')
                    new_arrays = new.encode(view, choices=choices).arrays
                    new_inspection = inspect_decision(new_arrays, expert)
                    groups = [compare_group(group,
                        [choices[index][1] for index in group], new_arrays, view.native)
                        for group in old_inspection['full_tie_groups']]
                    found[key] = dict(game_index=game['index'], seed=game['seed'],
                        player=player, decision_ordinal=ordinal,
                        decision_kind=view.decision.kind,
                        chosen_action_kind=sample.action_kind,
                        candidate_count=len(choices),
                        old_tie_group_count=len(old_inspection['full_tie_groups']),
                        new_tie_group_count=len(new_inspection['full_tie_groups']),
                        old_expert_tie_size=old_inspection['expert_tie_size'],
                        new_expert_tie_size=new_inspection['expert_tie_size'],
                        groups=groups)
                    if len(found) == len(targets):
                        return found
            option = next(option for option in view.decision.options
                          if option.id == response.option)
            action = (option.constraints['action'] if option.kind == 'finite'
                      else domain_action(option, response.value))
            raw = match._raw(view.actor.value)
            updated = (match.native_game.step(raw, int(option.id.split(':')[1]))
                       if option.kind == 'finite' else match.native_game.act(raw, action))
            match._after_action(updated, view.actor.value, raw['revision'])
    return found


def compare_report(dataset_path, audit_path, *, max_games=20, max_steps=6000):
    dataset_path = Path(dataset_path).resolve()
    audit_path = Path(audit_path).resolve()
    dataset = json.loads(dataset_path.read_text())
    audit = json.loads(audit_path.read_text())
    if audit.get('dataset_sha256') != sha256(dataset_path):
        raise ValueError('Audit report belongs to a different dataset')
    old_manifest = StandardEncoder().manifest()
    new_manifest = StandardChoiceEncoder().manifest()
    if dataset['encoder']['fingerprint'] != old_manifest['fingerprint']:
        raise ValueError('Replay source does not match saved v5 encoder')
    if old_manifest['feature_spec'] != new_manifest['feature_spec']:
        raise ValueError('v6 unexpectedly changed model input widths')
    games = {game['index']: game for game in dataset['games']}
    by_game = defaultdict(dict)
    for example in audit['examples']:
        by_game[example['game_index']][example['player'], example['decision_ordinal']] = example
    details = []
    errors = {}
    for index in list(by_game)[:max_games]:
        game = games[index]
        records = {}
        for trajectory in game['trajectories']:
            path = _trajectory_path(dataset_path, trajectory)
            records[trajectory['player']] = read_demonstration(
                dict(trajectory, path=str(path)))
        try:
            found = compare_game(game, records, by_game[index], max_steps=max_steps)
            details.extend(found.values())
            if len(found) != len(by_game[index]):
                errors[str(index)] = f'Reached {len(found)} of {len(by_game[index])} audited decisions'
        except Exception as error:
            errors[str(index)] = f'{type(error).__name__}: {error}'
    counts = Counter()
    for decision in details:
        counts['decisions'] += 1
        counts['old_tie_groups'] += decision['old_tie_group_count']
        counts['new_tie_groups'] += decision['new_tie_group_count']
        counts['expert_tie_resolved'] += (decision['old_expert_tie_size'] > 1
                                          and decision['new_expert_tie_size'] == 1)
        for group in decision['groups']:
            counts['old_' + group['old_category']] += 1
            counts[group['status']] += 1
            if group['old_category'] == 'different_visible_actions':
                if 'different_visible_actions' in group['remaining_categories']:
                    counts['different_visible_groups_remaining'] += 1
                else:
                    counts['different_visible_groups_resolved'] += 1
    return dict(schema=1, comparison='standard_v5_to_choice_v6',
        dataset=str(dataset_path), dataset_sha256=sha256(dataset_path),
        audit_report=str(audit_path), audit_report_sha256=sha256(audit_path),
        v5_fingerprint=old_manifest['fingerprint'],
        v6_fingerprint=new_manifest['fingerprint'],
        selected_games=min(max_games, len(by_game)),
        counts=dict(sorted(counts.items())), errors=errors, details=details,
        interpretation='Different-visible-group resolution means no remaining exact v6 tie '
                       'between visibly different actions in the audited group. '
                       'This does not measure policy quality or guarantee unique card traits.')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--audit-report', type=Path, required=True)
    parser.add_argument('--max-games', type=int, default=20)
    parser.add_argument('--max-steps', type=int, default=6000)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    if args.max_games < 1 or args.max_steps < 1:
        parser.error('Positive replay game and step limits required')
    report = compare_report(args.dataset, args.audit_report,
        max_games=args.max_games, max_steps=args.max_steps)
    write_new_json(args.output, report)
    print(json.dumps(dict(output=str(args.output.resolve()),
        counts=report['counts'], errors=report['errors'])), flush=True)


if __name__ == '__main__':
    main()
