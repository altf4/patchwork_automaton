"""Frozen-cp200, equal-capacity ordered-role versus pooled-reference A/B.

Both residuals start at exactly the saved actor logits. They train on the same
whole-seat v5 streams, same game order, and target-only loss; every decision
still advances its own recurrent memory. Validation is selected by whole game
from each collection stage and never enters an optimizer.
"""

import argparse
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import time

os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS', '0')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')

import numpy as np

from examples.diagnose_standard_decisions import (checkpoint_files, evaluate_trajectories,
    file_sha256, select_games)
from patchwork_automaton.neural.demonstrations import read_demonstration
from patchwork_automaton.neural.role_pointers import reconstruct_role_refs


class RoleImitationTrainer:
    """ImitationTrainer's recurrent forward pass with an extra pointer tensor."""

    def __init__(self, policy, *, pointer_mode, batch_size, unroll, learning_rate,
                 seed, device):
        import keras
        import tensorflow as tf
        from patchwork_automaton.neural.batching import example_batch, input_signature
        from patchwork_automaton.neural.devices import canonical_device, device_scope
        from patchwork_automaton.neural.imitation import ImitationTrainer

        if pointer_mode not in ('ordered', 'pooled') or min(batch_size, unroll) < 1:
            raise ValueError('Invalid role experiment batching or arm')
        self.policy = policy
        self.pointer_mode = pointer_mode
        self.batch_size = batch_size
        self.unroll = unroll
        self.device = canonical_device(device)
        self.clip_norm = 1.
        self.rng = np.random.default_rng(seed)
        self.optimizer = keras.optimizers.Adam(learning_rate)
        # Reuse the repo's sequence recurrence, including advance_memory on
        # every recorded decision and truncation only at unroll boundaries.
        self._forward = ImitationTrainer._forward.__get__(self)
        self._evaluate_chunk = ImitationTrainer._evaluate_chunk.__get__(self)
        self._base_chunks = ImitationTrainer._chunks.__get__(self)
        example = example_batch(policy.memory_size, policy.feature_spec)
        example['candidate_role_refs'] = np.repeat(
            example['candidate_refs'][:, :, None, :], 3, axis=2)
        with device_scope(self.device):
            self.policy(example, training=False)
            self.optimizer.build(self.policy.trainable_variables)
        sig = {key: tf.TensorSpec((None, *value.shape), value.dtype)
               for key, value in input_signature(example).items()
               if key not in ('memory_in', 'advance_memory')}
        signature = [tf.TensorSpec((None, policy.memory_size), tf.float32), sig,
                     tf.TensorSpec((None, None), tf.int32),
                     tf.TensorSpec((None, None), tf.float32)]
        self.train_chunk = tf.function(self._train_target_chunk,
                                      input_signature=[*signature, tf.TensorSpec((None, None), tf.float32)],
                                      autograph=False)
        self.evaluate_chunk = tf.function(self._evaluate_chunk,
                                          input_signature=signature, autograph=False)

    def _chunks(self, streams):
        for packed, labels, active, samples in self._base_chunks(streams):
            length, seats = active.shape
            actions, entities = packed['candidate_refs'].shape[2:]
            roles = np.zeros((length * seats, actions, 3, entities), np.float32)
            for position, sample in enumerate(samples):
                if self.pointer_mode == 'ordered':
                    pointer = sample.arrays['candidate_role_refs']
                else:
                    pointer = pooled_control_refs(sample.arrays)
                roles[position, :pointer.shape[0], :, :pointer.shape[2]] = pointer
            packed['candidate_role_refs'] = roles.reshape(length, seats, actions, 3, entities)
            yield packed, labels, active, samples

    def _train_target_chunk(self, memory, packed, labels, active, targets):
        import tensorflow as tf
        with tf.GradientTape() as tape:
            state, losses, predicted = self._forward(memory, packed, labels, active, True)
            loss = tf.reduce_sum(losses * targets) / tf.reduce_sum(targets)
        variables = self.policy.trainable_variables
        gradients = tape.gradient(loss, variables)
        pairs = [(g, v) for g, v in zip(gradients, variables) if g is not None]
        if not pairs:
            raise RuntimeError('Role scorer has no trainable gradients')
        for gradient, _ in pairs:
            tf.debugging.assert_all_finite(tf.convert_to_tensor(gradient), 'Nonfinite role gradient')
        clipped, _ = tf.clip_by_global_norm([gradient for gradient, _ in pairs], self.clip_norm)
        self.optimizer.apply_gradients(zip(clipped, [variable for _, variable in pairs]))
        return tf.stop_gradient(state), losses, predicted

    def train_epoch(self, trajectories, reader, *, max_steps=0):
        from patchwork_automaton.neural.devices import device_scope
        if max_steps < 0:
            raise ValueError('Negative step limit')
        order = self.rng.permutation(len(trajectories))
        ordered = [trajectories[int(index)] for index in order]
        stats = dict(trajectories_seen=0, decisions_seen=0,
                     target_decisions=0, optimizer_steps=0, target_nll_sum=0.)
        for start in range(0, len(ordered), self.batch_size):
            selected = ordered[start:start + self.batch_size]
            streams = [reader(trajectory) for trajectory in selected]
            stats['trajectories_seen'] += len(streams)
            memory = np.zeros((len(streams), self.policy.memory_size), np.float32)
            for packed, labels, active, samples in self._chunks(streams):
                targets = np.asarray([
                    [float(bool(active[t, seat]) and
                           samples[t * len(streams) + seat].decision_kind == 'targets')
                     for seat in range(len(streams))]
                    for t in range(len(active))], np.float32)
                with device_scope(self.device):
                    if targets.any():
                        output = self.train_chunk(memory, packed, labels, active, targets)
                        stats['optimizer_steps'] += 1
                    else:
                        output = self.evaluate_chunk(memory, packed, labels, active)
                memory, losses, _ = (np.asarray(value) for value in output)
                if not np.isfinite(memory).all() or not np.isfinite(losses).all():
                    raise FloatingPointError('Nonfinite role experiment output')
                stats['decisions_seen'] += int(active.sum())
                stats['target_decisions'] += int(targets.sum())
                stats['target_nll_sum'] += float(np.sum(losses * targets))
                if max_steps and stats['optimizer_steps'] >= max_steps:
                    break
            if max_steps and stats['optimizer_steps'] >= max_steps:
                break
        stats['mean_target_nll_during_fit'] = (stats['target_nll_sum'] / stats['target_decisions']
                                               if stats['target_decisions'] else None)
        return stats


def augmented_reader(manifest):
    def read(trajectory):
        records = []
        for sample in read_demonstration(trajectory):
            pointers, statuses = reconstruct_role_refs(sample.arrays, manifest)
            if any(status != 'resolved' for status in statuses):
                raise ValueError(f"Unresolved role pointer in {trajectory['path']}")
            records.append(replace(sample, arrays=dict(sample.arrays,
                                                        candidate_role_refs=pointers)))
        return records
    return read


def load_stage_games(directory, manifest):
    """Exclude only complete adjudicated games with no imitation decisions."""
    path = Path(directory).resolve() / 'dataset.json'
    data = json.loads(path.read_text())
    if (data.get('status') != 'complete' or data.get('encoder') != manifest
            or len(data['games']) != data['completed_games']):
        raise ValueError(f'Incomplete or incompatible demonstration dataset: {path}')
    partitions = dict(training=[], validation=[])
    excluded = dict(training=0, validation=0)
    indices, seeds, sources = set(), set(), set()
    for game in data['games']:
        if game['index'] in indices or game['seed'] in seeds:
            raise ValueError('Duplicate game or seed in demonstration stage')
        indices.add(game['index'])
        seeds.add(game['seed'])
        partition = game['partition']
        if partition not in partitions or game['status'] not in ('win', 'loss', 'draw'):
            raise ValueError('Incomplete or invalid demonstration game')
        if not game['trajectories']:
            if not game.get('adjudicated'):
                raise ValueError('Non-adjudicated game has no expert seat stream')
            excluded[partition] += 1
            continue
        if not game.get('adjudicated') and (len(game['trajectories']) != 2
                or {t['player'] for t in game['trajectories']} != {0, 1}):
            raise ValueError('Non-adjudicated game must have both expert seats')
        if len({t['player'] for t in game['trajectories']}) != len(game['trajectories']):
            raise ValueError('Duplicate expert seat in one game')
        for trajectory in game['trajectories']:
            player = trajectory['player']
            source = Path(trajectory['path']).resolve()
            if (player not in (0, 1) or trajectory['deck'] != game['decks'][player]
                    or 'reward' in trajectory or source in sources or not source.is_file()):
                raise ValueError('Invalid, reward-labeled, duplicate, or missing expert stream')
            sources.add(source)
        partitions[partition].append(game)
    return partitions, excluded


def selected_stages(datasets, manifest, *, train_games_per_stage,
                    validation_games_per_stage, sample_seed):
    stages = []
    for stage, directory in enumerate(datasets, 1):
        partitions, excluded = load_stage_games(directory, manifest)
        training, validation = partitions['training'], partitions['validation']
        if not training or not validation:
            raise ValueError('Each stage needs labeled training and validation games')
        chosen_train = select_games(training, maximum=train_games_per_stage,
                                    seed=sample_seed + 2 * stage)
        chosen_validation = select_games(validation, maximum=validation_games_per_stage,
                                         seed=sample_seed + 2 * stage + 1)
        stages.append(dict(stage=stage, directory=str(Path(directory).resolve()),
                           training=chosen_train, validation=chosen_validation,
                           eligible_training=len(training), eligible_validation=len(validation),
                           excluded_adjudicated_empty=excluded))
    all_games = [game for stage in stages for partition in ('training', 'validation')
                 for game in stage[partition]]
    if (len({g['index'] for g in all_games}) != len(all_games)
            or len({g['seed'] for g in all_games}) != len(all_games)):
        raise ValueError('Training/validation game or seed leakage')
    all_sources = [Path(t['path']).resolve() for game in all_games for t in game['trajectories']]
    if len(set(all_sources)) != len(all_sources):
        raise ValueError('Training/validation expert stream leakage')
    return stages


def trajectories(games):
    return [trajectory for game in games for trajectory in game['trajectories']]


def weights_sha256(model):
    digest = hashlib.sha256()
    for weight in model.get_weights():
        digest.update(str(weight.shape).encode())
        digest.update(np.ascontiguousarray(weight).tobytes())
    return digest.hexdigest()


def write_atomic_json(path, payload):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True,
                                    allow_nan=False) + '\n')
    os.replace(temporary, path)


def pooled_control_refs(arrays):
    """Erase role identity while retaining which roles actually have pointers."""
    average = arrays['candidate_refs'][:, None, :]
    occupied = np.any(arrays['candidate_role_refs'], axis=-1, keepdims=True)
    return np.repeat(average, 3, axis=1) * occupied


def save_arm_weights(directory, arm, policy):
    weights = policy.role_hidden.get_weights() + policy.role_score.get_weights()
    destination = directory / f'{arm}-residual.npz'
    temporary = directory / f'{arm}-residual.tmp.npz'
    np.savez_compressed(temporary, **{f'weight_{i}': value
                                     for i, value in enumerate(weights)})
    os.replace(temporary, destination)
    return dict(path=str(destination), sha256=file_sha256(destination))


def parity(actor, policies, sample, *, device):
    from patchwork_automaton.neural.features import collate
    from patchwork_automaton.neural.devices import device_scope
    arrays = sample.arrays
    batch = collate([arrays])
    batch['candidate_role_refs'] = arrays['candidate_role_refs'][None]
    batch['memory_in'] = np.zeros((1, actor.memory_size), np.float32)
    batch['advance_memory'] = np.ones((1, 1), np.float32)
    with device_scope(device):
        reference = actor(batch, training=False)
        results = [policy(batch, training=False) for policy in policies]
    deltas = []
    for result in results:
        row = {key: float(np.max(np.abs(np.asarray(reference[key]) - np.asarray(result[key]))))
               for key in ('logits', 'memory_out')}
        if row['logits'] > 1e-7 or row['memory_out'] > 1e-7:
            raise AssertionError(f'Zero-initialized role residual changed cp200: {row}')
        deltas.append(row)
    return deltas


def run(args):
    import keras
    from patchwork_automaton.neural import model as registered_models  # noqa: F401
    from patchwork_automaton.neural.batching import example_batch
    from patchwork_automaton.neural.devices import configure_runtime, device_scope
    from patchwork_automaton.neural.role_residual import RoleResidualPolicy

    policy_path, sidecar = checkpoint_files(args.checkpoint)
    checkpoint_sha = file_sha256(policy_path)
    if args.checkpoint_sha256 and checkpoint_sha != args.checkpoint_sha256:
        raise ValueError('Checkpoint SHA256 differs from predeclared cp200')
    manifest = json.loads(sidecar.read_text())
    if manifest.get('feature_version') != 5:
        raise ValueError('A/B is pinned to saved Standard version 5')
    stages = selected_stages(args.datasets, manifest,
                             train_games_per_stage=args.train_games_per_stage,
                             validation_games_per_stage=args.validation_games_per_stage,
                             sample_seed=args.sample_seed)
    configure_runtime(args.device, hide_gpu=args.device == 'cpu')
    keras.utils.set_random_seed(args.seed)
    with device_scope(args.device):
        saved = keras.saving.load_model(policy_path, compile=False)
        if dict(saved.feature_spec) != manifest['feature_spec']:
            raise ValueError('Checkpoint and dataset feature schemas differ')
        actor = saved.actor if getattr(saved, 'separate_value', False) else saved
        actor.trainable = False
        target_context_index = (len(manifest['steps'])
                                + manifest['decisions'].index('targets'))
        ordered = RoleResidualPolicy(actor, action_width=len(manifest['actions']),
                                     target_context_index=target_context_index)
        pooled = RoleResidualPolicy(actor, action_width=len(manifest['actions']),
                                    target_context_index=target_context_index)
        example = example_batch(actor.memory_size, actor.feature_spec)
        example['candidate_role_refs'] = np.repeat(example['candidate_refs'][:, :, None, :],
                                                   3, axis=2)
        ordered(example, training=False)
        pooled(example, training=False)
        for name in ('role_hidden', 'role_score'):
            getattr(pooled, name).set_weights(getattr(ordered, name).get_weights())
        if len(ordered.trainable_variables) != len(pooled.trainable_variables):
            raise AssertionError('A/B capacity differs')
        trainable_parameters = sum(int(np.prod(v.shape)) for v in ordered.trainable_variables)
        actor_sha = weights_sha256(actor)

    reader = augmented_reader(manifest)
    first_trajectory = trajectories(stages[0]['validation'])[0]
    sample = reader(first_trajectory)[0]
    deltas = parity(actor, (ordered, pooled), sample, device=args.device)
    result = dict(schema=1, protocol='frozen_cp200_target_only_equal_capacity',
                  checkpoint=dict(path=str(policy_path), sha256=checkpoint_sha,
                                  manifest_path=str(sidecar), manifest_sha256=file_sha256(sidecar)),
                  frozen_actor_weights_sha256=actor_sha,
                  encoder_fingerprint=manifest['fingerprint'],
                  datasets=[dict(path=str((Path(d).resolve() / 'dataset.json')),
                                 sha256=file_sha256(Path(d) / 'dataset.json')) for d in args.datasets],
                  config=dict(train_games_per_stage=args.train_games_per_stage,
                              validation_games_per_stage=args.validation_games_per_stage,
                              sample_seed=args.sample_seed, seed=args.seed,
                              batch_size=args.batch_size, unroll=args.unroll,
                              learning_rate=args.learning_rate, epochs=args.epochs,
                              max_steps=args.max_steps, device=args.device),
                  trainable_parameters_per_arm=trainable_parameters,
                  initial_cp200_parity=deltas,
                  stages=[dict(stage=stage['stage'], directory=stage['directory'],
                               eligible_training=stage['eligible_training'],
                               eligible_validation=stage['eligible_validation'],
                               excluded_adjudicated_empty=stage['excluded_adjudicated_empty'],
                               selected_training_games=[[g['index'], g['seed']] for g in stage['training']],
                               selected_validation_games=[[g['index'], g['seed']] for g in stage['validation']])
                          for stage in stages])
    if args.parity_only:
        return result, None

    trainers = {
        'ordered': RoleImitationTrainer(ordered, pointer_mode='ordered',
            batch_size=args.batch_size, unroll=args.unroll,
            learning_rate=args.learning_rate, seed=args.seed, device=args.device),
        'pooled': RoleImitationTrainer(pooled, pointer_mode='pooled',
            batch_size=args.batch_size, unroll=args.unroll,
            learning_rate=args.learning_rate, seed=args.seed, device=args.device),
    }
    baseline = {}
    for stage in stages:
        baseline[str(stage['stage'])] = evaluate_trajectories(
            trainers['ordered'], trajectories(stage['validation']),
            batch_size=args.batch_size, reader=reader)
    result['baseline_cp200'] = baseline
    args.output.mkdir(parents=True, exist_ok=False)
    result['status'] = 'running'
    result['arms'] = {}
    write_atomic_json(args.output / 'experiment.partial.json', result)

    all_training = trajectories([game for stage in stages for game in stage['training']])
    arm_results = result['arms']
    for arm, trainer in trainers.items():
        started = time.monotonic()
        fit = [trainer.train_epoch(all_training, reader, max_steps=args.max_steps)
               for _ in range(args.epochs)]
        fit_seconds = time.monotonic() - started
        validation = {}
        for stage in stages:
            validation[str(stage['stage'])] = evaluate_trajectories(
                trainer, trajectories(stage['validation']),
                batch_size=args.batch_size, reader=reader)
        arm_results[arm] = dict(fit=fit, fit_seconds=fit_seconds,
                                optimizer_steps=int(trainer.optimizer.iterations),
                                validation=validation)
        if weights_sha256(actor) != actor_sha:
            raise AssertionError('Frozen cp200 actor weights changed during A/B')
        arm_results[arm]['weights'] = save_arm_weights(args.output, arm, trainer.policy)
        write_atomic_json(args.output / 'experiment.partial.json', result)
        print(json.dumps(dict(event='arm_complete', arm=arm, fit_seconds=fit_seconds,
                              optimizer_steps=int(trainer.optimizer.iterations),
                              target_by_stage={key: value['decisions'].get('targets')
                                               for key, value in validation.items()})), flush=True)
    if ([epoch['optimizer_steps'] for epoch in arm_results['ordered']['fit']]
            != [epoch['optimizer_steps'] for epoch in arm_results['pooled']['fit']]
            or [epoch['target_decisions'] for epoch in arm_results['ordered']['fit']]
            != [epoch['target_decisions'] for epoch in arm_results['pooled']['fit']]):
        raise AssertionError('A/B training budgets diverged')
    if file_sha256(policy_path) != checkpoint_sha:
        raise AssertionError('Source cp200 checkpoint file changed during A/B')
    for source in result['datasets']:
        if file_sha256(source['path']) != source['sha256']:
            raise AssertionError('Source demonstration manifest changed during A/B')
    result['status'] = 'complete'
    return result, trainers


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--checkpoint-sha256', default='')
    p.add_argument('--datasets', nargs=2, type=Path, required=True)
    p.add_argument('--train-games-per-stage', type=int, default=600)
    p.add_argument('--validation-games-per-stage', type=int, default=240)
    p.add_argument('--sample-seed', type=int, default=73)
    p.add_argument('--seed', type=int, default=5721)
    p.add_argument('--batch-size', type=int, default=8)
    p.add_argument('--unroll', type=int, default=8)
    p.add_argument('--learning-rate', type=float, default=.0003)
    p.add_argument('--epochs', type=int, default=1)
    p.add_argument('--max-steps', type=int, default=0,
                   help='Only for short smoke runs; 0 consumes every selected stream')
    p.add_argument('--device', choices=('cpu', 'gpu'), default='gpu')
    p.add_argument('--parity-only', action='store_true')
    p.add_argument('--output', type=Path, required=True,
                   help='New result directory, never an existing directory')
    args = p.parse_args(argv)
    if (min(args.train_games_per_stage, args.validation_games_per_stage,
            args.batch_size, args.unroll, args.epochs) < 1
            or args.max_steps < 0 or args.seed < 0 or args.sample_seed < 0
            or not 0 < args.learning_rate < float('inf')):
        p.error('Positive budgets/rate and nonnegative seeds/step limit required')
    if args.output.exists():
        raise FileExistsError(args.output)
    result, trainers = run(args)
    if trainers is None:
        args.output.mkdir(parents=True, exist_ok=False)
    write_atomic_json(args.output / 'experiment.json', result)
    if trainers is not None:
        (args.output / 'experiment.partial.json').unlink()
    print(json.dumps(dict(output=str(args.output.resolve()),
                          parity=result['initial_cp200_parity'],
                          arms=list(result.get('arms', {})))), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
