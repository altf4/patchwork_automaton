"""Bounded, read-only reconstruction audit for saved Standard v5 decisions."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

import numpy as np

from patchwork_automaton.neural.demonstrations import read_demonstration
from patchwork_automaton.neural.role_pointers import ROLE_NAMES, reconstruct_role_refs


def select_games(games, maximum, seed):
    if maximum < 1 or seed < 0:
        raise ValueError('Positive game count and nonnegative seed required')
    def key(game):
        return hashlib.sha256(f"{seed}:{game['seed']}:{game['index']}".encode()).digest()
    return sorted(games, key=key)[:maximum]


def load_games(directories, partition):
    manifest, games, sources = None, [], []
    indices, seeds = set(), set()
    for directory in directories:
        path = Path(directory).resolve() / 'dataset.json'
        data = json.loads(path.read_text())
        if data.get('status') != 'complete' or len(data['games']) != data['completed_games']:
            raise ValueError(f'Incomplete dataset: {path}')
        if manifest is None:
            manifest = data['encoder']
        elif manifest != data['encoder']:
            raise ValueError('Datasets use different feature manifests')
        for game in data['games']:
            if game['index'] in indices or game['seed'] in seeds:
                raise ValueError('Overlapping game or seed')
            indices.add(game['index'])
            seeds.add(game['seed'])
            if game['partition'] == partition:
                games.append(game)
        sources.append(dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    if manifest is None or manifest.get('feature_version') != 5 or not games:
        raise ValueError('Complete Standard v5 games required')
    return manifest, games, sources


def probe(manifest, games, *, max_examples=20):
    totals = Counter()
    by_kind = defaultdict(Counter)
    by_deck_kind = defaultdict(Counter)
    examples = []
    for game in games:
        for trajectory in game['trajectories']:
            deck = trajectory['deck']
            for ordinal, sample in enumerate(read_demonstration(trajectory)):
                arrays = sample.arrays
                role_refs, statuses = reconstruct_role_refs(arrays, manifest)
                legal = np.flatnonzero(arrays['candidate_mask'])
                chosen_position = int(np.searchsorted(legal, sample.action))
                if chosen_position >= len(legal) or legal[chosen_position] != sample.action:
                    raise ValueError('Chosen action is not legal')
                kind = sample.decision_kind
                for row in (totals, by_kind[kind], by_deck_kind[(deck, kind)]):
                    row['decisions'] += 1
                    row['candidates'] += len(legal)
                    row['chosen_' + statuses[chosen_position]] += 1
                    row['multi_linked_chosen'] += int(np.count_nonzero(role_refs[sample.action].sum(axis=0)) > 1)
                    for role_index, role in enumerate(ROLE_NAMES):
                        row[role + '_chosen'] += int(bool(role_refs[sample.action, role_index].any()))
                    for status in statuses:
                        row[status] += 1
                if len(examples) < max_examples and any(s != 'resolved' for s in statuses):
                    examples.append(dict(game=game['index'], deck=deck, trajectory=str(trajectory['path']),
                                         decision=ordinal, decision_kind=kind,
                                         problem_candidates=[int(i) for i, status in zip(legal, statuses)
                                                             if status != 'resolved'],
                                         statuses=[status for status in statuses if status != 'resolved']))
    return dict(totals=dict(totals), by_decision_kind={kind: dict(row) for kind, row in sorted(by_kind.items())},
                by_deck_decision={f'{deck}|{kind}': dict(row)
                                  for (deck, kind), row in sorted(by_deck_kind.items())},
                examples=examples)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--datasets', nargs='+', type=Path, required=True)
    p.add_argument('--partition', choices=('training', 'validation'), default='validation')
    p.add_argument('--max-games', type=int, default=40)
    p.add_argument('--sample-seed', type=int, default=0)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(argv)
    manifest, games, sources = load_games(args.datasets, args.partition)
    selected = select_games(games, args.max_games, args.sample_seed)
    result = dict(schema=1, encoder_fingerprint=manifest['fingerprint'],
                  partition=args.partition, selected_games=len(selected), eligible_games=len(games),
                  sample_seed=args.sample_seed, datasets=sources, **probe(manifest, selected))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(output=str(args.output.resolve()), selected_games=len(selected),
                          totals=result['totals'], examples=len(result['examples'])), sort_keys=True), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
