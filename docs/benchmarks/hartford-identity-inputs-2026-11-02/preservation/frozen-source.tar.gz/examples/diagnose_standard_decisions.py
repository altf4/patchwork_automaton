"""Read-only imitation accuracy by Standard deck and decision kind.

Use a checkpoint and demonstrations made with the same feature manifest. Each
seat's recorded recurrent stream is replayed from zero memory, in order. This
diagnostic measures agreement with its recorded expert; it does not estimate
win rate or label alternative legal choices as bad.
"""

import argparse
from collections import defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile

os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS', '0')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')

import numpy as np

from patchwork_automaton.baselines.standard_decks import STANDARD_DECKS
from patchwork_automaton.neural.demonstrations import read_demonstration


FOCUS_DECISIONS = ('targets', 'blockers', 'library_search', 'library_choice',
                   'library_selection')


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def checkpoint_files(path):
    policy = Path(path)
    if policy.is_dir():
        policy /= 'policy.keras'
    sidecar = policy.with_suffix('.manifest.json')
    for item in (policy, sidecar):
        if not item.is_file():
            raise FileNotFoundError(item)
    return policy.resolve(), sidecar.resolve()


def load_games(directories, encoder_manifest, *, partition):
    """Keep complete, distinct games and bind their expert data to the policy schema."""
    games, manifests, indices, seeds, trajectories = [], [], set(), set(), set()
    for directory in directories:
        path = Path(directory).resolve() / 'dataset.json'
        data = json.loads(path.read_text())
        if data.get('status') != 'complete' or data.get('encoder') != encoder_manifest:
            raise ValueError(f'Incomplete or incompatible demonstration dataset: {path}')
        if len(data['games']) != data['completed_games']:
            raise ValueError(f'Demonstration game count mismatch: {path}')
        manifests.append(dict(path=str(path), sha256=file_sha256(path)))
        for game in data['games']:
            if game['index'] in indices or game['seed'] in seeds:
                raise ValueError('Duplicate demonstration game identity')
            indices.add(game['index'])
            seeds.add(game['seed'])
            if game['partition'] not in ('training', 'validation') or game['status'] not in ('win', 'loss', 'draw'):
                raise ValueError('Invalid partition or incomplete demonstration game')
            if game['partition'] != partition:
                continue
            if not game['trajectories']:
                raise ValueError('Selected game has no expert seat stream')
            if not game.get('adjudicated') and (len(game['trajectories']) != 2
                    or {t['player'] for t in game['trajectories']} != {0, 1}):
                raise ValueError('Both expert seat streams required')
            for trajectory in game['trajectories']:
                if (trajectory['player'] not in (0, 1)
                        or trajectory['deck'] != game['decks'][trajectory['player']]
                        or trajectory['deck'] not in STANDARD_DECKS
                        or 'reward' in trajectory):
                    raise ValueError('Expert seat/deck identity mismatch')
                source = Path(trajectory['path']).resolve()
                if source in trajectories or not source.is_file():
                    raise ValueError('Duplicate or missing expert trajectory')
                trajectories.add(source)
            games.append(game)
    if not games:
        raise ValueError(f'No {partition} demonstration games')
    return games, manifests


def select_games(games, *, maximum, seed):
    if type(maximum) is not int or maximum < 0 or type(seed) is not int or seed < 0:
        raise ValueError('Nonnegative sampling controls required')
    if maximum == 0 or maximum >= len(games):
        return sorted(games, key=lambda game: (game['seed'], game['index']))
    def key(game):
        value = f"{seed}:{game['seed']}:{game['index']}".encode()
        return hashlib.sha256(value).digest()
    return sorted(sorted(games, key=key)[:maximum],
                  key=lambda game: (game['seed'], game['index']))


def _new_counts():
    return dict(samples=0, top1=0, encoded_tie_top1=0,
                expert_probability_sum=0., negative_log_likelihood_sum=0.)


def _add(groups, deck, sample, predicted, negative_log_likelihood):
    if not math.isfinite(negative_log_likelihood) or negative_log_likelihood < 0:
        raise FloatingPointError('Invalid expert negative log likelihood')
    if not 0 <= predicted < len(sample.arrays['candidates']):
        raise ValueError('Predicted candidate outside the legal action list')
    selected = sample.action
    arrays = sample.arrays
    encoded_tie = (np.array_equal(arrays['candidates'][predicted], arrays['candidates'][selected])
                   and np.array_equal(arrays['candidate_refs'][predicted],
                                      arrays['candidate_refs'][selected]))
    for key in (('all', 'all'), (deck, 'all'), ('all', sample.decision_kind),
                (deck, sample.decision_kind)):
        row = groups[key]
        row['samples'] += 1
        row['top1'] += int(predicted == selected)
        row['encoded_tie_top1'] += int(encoded_tie)
        row['expert_probability_sum'] += math.exp(-negative_log_likelihood)
        row['negative_log_likelihood_sum'] += negative_log_likelihood


def _rates(row):
    count = row['samples']
    return dict(samples=count, top1_accuracy=row['top1'] / count,
                encoded_tie_top1_accuracy=row['encoded_tie_top1'] / count,
                mean_expert_probability=row['expert_probability_sum'] / count,
                mean_negative_log_likelihood=row['negative_log_likelihood_sum'] / count)


def evaluate_trajectories(trainer, trajectories, *, batch_size, reader=read_demonstration):
    """Replay complete seat streams; memory persists across unrolls, never seats."""
    groups = defaultdict(_new_counts)
    for start in range(0, len(trajectories), batch_size):
        selected = trajectories[start:start + batch_size]
        streams = [reader(trajectory) for trajectory in selected]
        memory = np.zeros((len(streams), trainer.policy.memory_size), np.float32)
        for packed, labels, active, samples in trainer._chunks(streams):
            output = trainer.evaluate_chunk(memory, packed, labels, active)
            memory, losses, predictions = (np.asarray(value) for value in output)
            if not np.isfinite(memory).all() or not np.isfinite(losses).all():
                raise FloatingPointError('Nonfinite decision diagnostic')
            for time_index, stream_index in zip(*np.nonzero(active)):
                sample = samples[time_index * len(streams) + stream_index]
                _add(groups, selected[stream_index]['deck'], sample,
                     int(predictions[time_index, stream_index]),
                     float(losses[time_index, stream_index]))
    if ('all', 'all') not in groups:
        raise ValueError('No recorded decisions')
    return dict(aggregate=_rates(groups['all', 'all']),
                decks={deck: _rates(groups[(deck, 'all')]) for deck in STANDARD_DECKS
                       if (deck, 'all') in groups},
                decisions={kind: _rates(row) for (deck, kind), row in sorted(groups.items())
                           if deck == 'all' and kind != 'all'},
                deck_decisions={deck: {kind: _rates(row)
                                       for (name, kind), row in sorted(groups.items())
                                       if name == deck and kind != 'all'}
                                for deck in STANDARD_DECKS if (deck, 'all') in groups},
                focus={kind: _rates(groups[('all', kind)]) for kind in FOCUS_DECISIONS
                       if ('all', kind) in groups})


def write_new_json(path, payload):
    path = Path(path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', dir=path.parent, prefix='.decision-diagnostic-',
                                         delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(payload, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def run(args):
    import keras
    from patchwork_automaton.neural import model as registered_models  # noqa: F401
    from patchwork_automaton.neural.imitation import ImitationTrainer
    from patchwork_automaton.neural.devices import configure_runtime, device_scope

    policy_path, sidecar = checkpoint_files(args.checkpoint)
    encoder_manifest = json.loads(sidecar.read_text())
    games, datasets = load_games(args.datasets, encoder_manifest,
                                 partition=args.partition)
    selected_games = select_games(games, maximum=args.max_games, seed=args.sample_seed)
    trajectories = [trajectory for game in selected_games
                    for trajectory in game['trajectories']]
    configure_runtime('cpu', hide_gpu=True)
    with device_scope('cpu'):
        network = keras.saving.load_model(policy_path, compile=False)
        if dict(network.feature_spec) != encoder_manifest['feature_spec']:
            raise ValueError('Checkpoint model and encoder feature schemas differ')
        trainer = ImitationTrainer(network, batch_size=args.batch_size,
                                   epochs=1, unroll=args.unroll,
                                   action_kinds=tuple(encoder_manifest['actions']), device='cpu')
        metrics = evaluate_trajectories(trainer, trajectories,
                                        batch_size=args.batch_size)
    return dict(schema=1, source='recorded_expert_decisions', partition=args.partition,
                checkpoint=dict(path=str(policy_path), sha256=file_sha256(policy_path),
                                manifest_path=str(sidecar), manifest_sha256=file_sha256(sidecar),
                                feature_fingerprint=encoder_manifest['fingerprint']),
                datasets=datasets, sample_seed=args.sample_seed, max_games=args.max_games,
                eligible_games=len(games), selected_games=len(selected_games),
                selected_trajectories=len(trajectories),
                **metrics)


def parser():
    command = argparse.ArgumentParser(description=__doc__)
    command.add_argument('--checkpoint', type=Path, required=True,
                         help='policy.keras or its checkpoint directory')
    command.add_argument('--datasets', type=Path, nargs='+', required=True,
                         help='Complete demonstration dataset directories')
    command.add_argument('--partition', choices=('training', 'validation'), default='validation')
    command.add_argument('--max-games', type=int, default=0,
                         help='Deterministically sample at most this many games; zero uses all')
    command.add_argument('--sample-seed', type=int, default=0)
    command.add_argument('--batch-size', type=int, default=8)
    command.add_argument('--unroll', type=int, default=8)
    command.add_argument('--output', type=Path, required=True,
                         help='New JSON file; existing output is never overwritten')
    return command


def main(argv=None):
    command = parser()
    args = command.parse_args(argv)
    if args.max_games < 0 or args.sample_seed < 0 or args.batch_size < 1 or args.unroll < 1:
        command.error('Nonnegative sample controls and positive batching controls required')
    report = run(args)
    write_new_json(args.output, report)
    print(json.dumps(dict(output=str(args.output.resolve()),
                          selected_games=report['selected_games'],
                          decisions=report['aggregate']['samples'],
                          focus=report['focus']), sort_keys=True), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
