"""Replay a few audited Standard games to inspect raw actions behind numerical ties.

Requires the dataset's engine, deck definitions and encoder schema to match the
checkout. Every non-forced scripted choice is checked against its saved action
and numerical candidates before a tie is classified. Same-name library copies
are marked likely interchangeable; this is not a proof of equivalent outcomes.
"""
import argparse
from collections import Counter, defaultdict
import json
import os
from pathlib import Path

os.environ['PATCHWORK_OBSERVATION_PIPELINE'] = 'python'

import numpy as np

from examples.audit_standard_action_encoding import (inspect_decision, sha256,
    _trajectory_path, write_new_json)
from patchwork_automaton.backends.rustmage import RustMageMatch, domain_action
from patchwork_automaton.baselines.standard import StandardAggro
from patchwork_automaton.baselines.standard_decks import standard_deck
from patchwork_automaton.neural.demonstrations import expert_index, read_demonstration
from patchwork_automaton.neural.rustmage_observation import learning_observation
from patchwork_automaton.neural.rustmage_features import visible_identity
from patchwork_automaton.neural.standard_features import StandardEncoder


def _plain(value):
    if hasattr(value, 'items'):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(item) for item in value]
    return value


def visible_cards(raw):
    """Resolve IDs using only the acting player's private observation."""
    cards = {}
    def walk(value):
        if hasattr(value, 'items'):
            card = visible_identity(value)
            identifier = value.get('id')
            zone = value.get('zone')
            if type(identifier) is int and isinstance(card, str) and isinstance(zone, str):
                cards[identifier] = dict(name=card, zone=zone,
                    controller=value.get('controller'), tapped=value.get('tapped'),
                    power=value.get('power'), toughness=value.get('toughness'),
                    damage=value.get('damage'))
            for item in value.values():
                walk(item)
        elif isinstance(value, (tuple, list)):
            for item in value:
                walk(item)
    walk(raw)
    return cards


def choice_card_visibility(raw, actions):
    """Record reveal flags for cards referenced by tied actions."""
    ids = {action.get('card') for action in actions if type(action.get('card')) is int}
    result = []
    def walk(value, path):
        if hasattr(value, 'items'):
            if value.get('id') in ids and isinstance(value.get('zone'), str):
                result.append(dict(path=path, id=value['id'],
                    visible_name=visible_identity(value), zone=value['zone'],
                    hideInfo=value.get('hideInfo'), faceDown=value.get('faceDown'),
                    face_down=value.get('face_down')))
            for field, item in value.items():
                walk(item, f'{path}.{field}')
        elif isinstance(value, (tuple, list)):
            for index, item in enumerate(value):
                walk(item, f'{path}[{index}]')
    for key in ('objects', 'search_choice', 'library_choice', 'library_selection'):
        walk(raw.get(key), key)
    return result


def normalize_action(action, raw):
    """Replace visible object IDs by names and state, retaining unresolved IDs."""
    cards = visible_cards(raw)
    unresolved = []
    def normalize(value, key=None):
        if type(value) is int and key in ('card', 'blocker', 'attacker', 'Card', 'Spell'):
            known = cards.get(value)
            if known is None:
                unresolved.append(value)
                return dict(unresolved_card_id=value)
            return dict(visible_card=known)
        if hasattr(value, 'items'):
            return {field: normalize(item, field) for field, item in value.items()}
        if isinstance(value, (tuple, list)):
            return [normalize(item) for item in value]
        return value
    if action['kind'] == 'PutTrigger':
        trigger = next((item for item in raw.get('waiting_triggers', ())
                        if item.get('id') == action.get('id')), None)
        # Trigger ordering may depend on details beyond its visible source.
        # Show those details, but do not infer equivalence from their shape.
        unresolved.append(action.get('id'))
        action = dict(kind='PutTrigger', trigger=None if trigger is None else
                      {k: v for k, v in trigger.items() if k != 'id'})
    normalized = normalize(action)
    return normalized, unresolved


def classify_group(actions, raw):
    normalized = []
    unresolved = []
    for action in actions:
        item, missing = normalize_action(action, raw)
        normalized.append(_plain(item))
        unresolved.extend(missing)
    if unresolved:
        category = 'unresolved_visible_identity'
    elif len({json.dumps(item, sort_keys=True) for item in normalized}) > 1:
        category = 'different_visible_actions'
    else:
        zones = []
        def collect_zones(value):
            if isinstance(value, dict):
                if 'visible_card' in value:
                    zones.append(value['visible_card']['zone'])
                for item in value.values():
                    collect_zones(item)
            elif isinstance(value, list):
                for item in value:
                    collect_zones(item)
        for item in normalized:
            collect_zones(item)
        category = ('likely_same_name_library_copies' if zones and all(z == 'Library' for z in zones)
                    else 'same_visible_description')
    return dict(category=category, normalized_actions=normalized,
                raw_actions=[_plain(action) for action in actions])


def replay_game(game, records, targets, *, max_steps=6000):
    """Replay scripted decisions, rejecting any divergence before target ties."""
    encoder = StandardEncoder()
    policies = [StandardAggro(deck) for deck in game['decks']]
    ordinals = [0, 0]
    found = {}
    with RustMageMatch(*(standard_deck(deck) for deck in game['decks']),
            seed=game['seed'], starting_player=game['starting_player']) as match:
        for step in range(max_steps):
            views = [learning_observation(match, f'P{player}') for player in range(2)]
            if views[0].terminal:
                break
            actors = [player for player, view in enumerate(views) if view.decision is not None]
            if len(actors) != 1:
                raise RuntimeError('Replay did not have one prompted player')
            player = actors[0]
            view = views[player]
            response = policies[player].choose(view)
            choices = encoder.expand_options(view.decision)
            if len(choices) > 1:
                ordinal = ordinals[player]
                ordinals[player] += 1
                if ordinal >= len(records[player]):
                    raise ValueError(f'Replay has extra decisions for P{player} at step {step}')
                sample = records[player][ordinal]
                expert = expert_index(view.decision, response, choices)
                if (sample.decision_kind != view.decision.kind
                        or sample.action_kind != choices[expert][1]['kind']
                        or sample.action != expert):
                    raise ValueError(f'Replay diverged at P{player} record {ordinal}')
                key = (player, ordinal)
                if key in targets:
                    encoded = encoder.encode(view, choices=choices).arrays
                    for name in ('candidates', 'candidate_refs', 'context', 'entities'):
                        if not np.array_equal(sample.arrays[name], encoded[name]):
                            raise ValueError(f'Replay numerical {name} differs at P{player} record {ordinal}')
                    inspected = inspect_decision(encoded, expert)
                    expected = targets[key]
                    if ([group[:16] for group in inspected['full_tie_groups'][:8]] != expected['tie_groups']
                            or [len(group) for group in inspected['full_tie_groups'][:8]]
                                != expected['tie_group_sizes']):
                        raise ValueError(f'Replay tie groups differ at P{player} record {ordinal}')
                    classifications = []
                    for group in inspected['full_tie_groups']:
                        actions = [choices[index][1] for index in group]
                        classifications.append(dict(indices=group,
                            **classify_group(actions, view.native),
                            choice_card_visibility=choice_card_visibility(view.native, actions)))
                    found[key] = dict(game_index=game['index'], seed=game['seed'],
                        player=player, decision_ordinal=ordinal,
                        decision_kind=view.decision.kind,
                        chosen_action_kind=sample.action_kind,
                        expert_index=expert, groups=classifications)
                    if len(found) == len(targets):
                        return found
            option = next(option for option in view.decision.options if option.id == response.option)
            action = option.constraints['action'] if option.kind == 'finite' else domain_action(option, response.value)
            raw = match._raw(view.actor.value)
            updated = (match.native_game.step(raw, int(option.id.split(':')[1]))
                       if option.kind == 'finite' else match.native_game.act(raw, action))
            match._after_action(updated, view.actor.value, raw['revision'])
    return found


def classify_report(dataset_path, audit_path, *, max_games=5, max_steps=6000):
    dataset_path = Path(dataset_path).resolve()
    audit_path = Path(audit_path).resolve()
    dataset = json.loads(dataset_path.read_text())
    audit = json.loads(audit_path.read_text())
    if audit.get('dataset_sha256') != sha256(dataset_path):
        raise ValueError('Audit report belongs to a different dataset')
    if dataset['encoder']['fingerprint'] != StandardEncoder().manifest()['fingerprint']:
        raise ValueError('Current Standard encoder differs from dataset; replay requires matching source')
    games = {game['index']: game for game in dataset['games']}
    by_game = defaultdict(dict)
    for example in audit['examples']:
        by_game[example['game_index']][example['player'], example['decision_ordinal']] = example
    details = []
    errors = {}
    for index in list(by_game)[:max_games]:
        game = games[index]
        records = {}
        for trajectory in game['trajectories']:
            path = _trajectory_path(dataset_path, trajectory)
            records[trajectory['player']] = read_demonstration(dict(trajectory, path=str(path)))
        try:
            found = replay_game(game, records, by_game[index], max_steps=max_steps)
            details.extend(found.values())
            if len(found) != len(by_game[index]):
                errors[str(index)] = f'Reached {len(found)} of {len(by_game[index])} audited decisions'
        except Exception as error:
            errors[str(index)] = f'{type(error).__name__}: {error}'
    categories = Counter(group['category'] for detail in details for group in detail['groups'])
    return dict(schema=1, classifier='standard_action_tie_replay',
                dataset=str(dataset_path), dataset_sha256=sha256(dataset_path),
                audit_report=str(audit_path), audit_report_sha256=sha256(audit_path),
                selected_games=min(max_games, len(by_game)),
                classified_decisions=len(details), categories=dict(sorted(categories.items())),
                errors=errors, details=details,
                interpretation='Different visible actions are confirmed representation collisions. '
                               'Same-name library copies are likely interchangeable but not proven equivalent.')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--audit-report', type=Path, required=True)
    parser.add_argument('--max-games', type=int, default=5)
    parser.add_argument('--max-steps', type=int, default=6000)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    if args.max_games < 1 or args.max_steps < 1:
        parser.error('Positive replay game and step limits required')
    report = classify_report(args.dataset, args.audit_report,
                             max_games=args.max_games, max_steps=args.max_steps)
    write_new_json(args.output, report)
    print(json.dumps(dict(output=str(args.output.resolve()),
                          classified_decisions=report['classified_decisions'],
                          categories=report['categories'], errors=report['errors'])), flush=True)


if __name__ == '__main__':
    main()
