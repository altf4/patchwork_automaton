"""Summarize recorded Standard baseline games without loading an engine or policy.

Win rates and Wilson 95% intervals use completed decisive games only. Draws,
cutoffs, and errors are retained separately. Input results are never modified.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
from itertools import combinations
import json
import math
from pathlib import Path
import statistics


def wilson(wins, decisive):
    if decisive == 0:
        return None
    z = 1.959963984540054
    rate = wins / decisive
    denominator = 1 + z * z / decisive
    center = (rate + z * z / (2 * decisive)) / denominator
    half = z * math.sqrt(rate * (1 - rate) / decisive + z * z / (4 * decisive * decisive)) / denominator
    return [max(0.0, center - half), min(1.0, center + half)]


def distribution(values):
    values = sorted(values)
    if not values:
        return dict(count=0, mean=None, median=None, p90=None, minimum=None, maximum=None)
    position = (len(values) - 1) * .9
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    return dict(count=len(values), mean=statistics.mean(values), median=statistics.median(values),
                p90=values[lower] + (values[upper] - values[lower]) * (position - lower),
                minimum=values[0], maximum=values[-1])


def outcomes(rows, deck):
    counts = Counter(row['status'] for row in rows)
    completed = [row for row in rows if row['status'] == 'completed']
    wins = sum(row['winner_deck'] == deck for row in completed)
    draws = sum(row['draw'] for row in completed)
    decisive = len(completed) - draws
    return dict(attempted=len(rows), completed=len(completed), decisive=decisive,
                wins=wins, losses=decisive - wins, draws=draws,
                cutoffs=counts['cutoff'], errors=counts['error'],
                win_rate=wins / decisive if decisive else None,
                wilson_95=wilson(wins, decisive))


def action_counts(rows):
    by_deck = defaultdict(Counter)
    for row in rows:
        for key, count in row.get('actions', {}).items():
            player, label = key.split(':', 1)
            seat = int(player.removeprefix('player_'))
            by_deck[row['decks'][seat]][label] += count
    return {deck: dict(sorted(counts.items())) for deck, counts in sorted(by_deck.items())}


def analyze(report):
    config = report['config']
    deck_ids = config['decks']
    games_per_pair = config['games']
    if len(deck_ids) < 2 or len(set(deck_ids)) != len(deck_ids):
        raise ValueError('Expected at least two distinct decks; this report summarizes nonmirror pairings')
    if type(games_per_pair) is not int or games_per_pair <= 0:
        raise ValueError('Expected a positive games-per-pair configuration')
    pairs = list(combinations(deck_ids, 2))
    expected = {}
    for pair_index, pair in enumerate(pairs):
        for attempt in range(games_per_pair):
            index = pair_index * games_per_pair + attempt
            expected[index] = dict(pairing=list(pair), decks=list(pair if attempt % 2 == 0 else pair[::-1]),
                                   starting_player=f'P{(attempt // 2) % 2}', seed=config['seed'] + index)
    rows = report['games']
    issues = []
    indices = Counter(row['index'] for row in rows)
    duplicates = [index for index, count in indices.items() if count != 1]
    if duplicates:
        issues.append('Duplicate game indices: ' + repr(sorted(duplicates)))
    missing = sorted(set(expected) - set(indices))
    extra = sorted(set(indices) - set(expected))
    if missing:
        issues.append(f'{len(missing)} expected games are absent')
    if extra:
        issues.append('Unexpected game indices: ' + repr(extra))
    grouped = defaultdict(list)
    mismatches = []
    for row in rows:
        index = row['index']
        if index in expected and any(row.get(key) != value for key, value in expected[index].items()):
            mismatches.append(index)
        pair = tuple(row['pairing'])
        if pair not in pairs or sorted(row['decks']) != sorted(pair):
            raise ValueError(f'Game {index} has an invalid or mirrored pairing')
        if row['starting_player'] not in ('P0', 'P1'):
            raise ValueError(f'Game {index} has an invalid starting player')
        if row['status'] not in ('completed', 'cutoff', 'error'):
            raise ValueError(f'Game {index} has an unknown status')
        if row['status'] == 'completed':
            winner = row.get('winner_seat')
            if row.get('draw') is True:
                valid = winner is None and row.get('winner_deck') is None
            else:
                valid = row.get('draw') is False and type(winner) is int and winner in (0, 1)
                valid = valid and row.get('winner_deck') == row['decks'][winner]
            if not valid:
                raise ValueError(f'Game {index} has an inconsistent terminal result')
        elif row.get('winner_deck') is not None or row.get('draw'):
            raise ValueError(f'Game {index} assigns a result to an incomplete game')
        if sum(row.get('actions', {}).values()) != row['decisions']:
            issues.append(f'Game {index} action counts differ from submitted decisions')
        grouped[pair].append(row)
    if mismatches:
        issues.append('Schedule/seed/seat mismatches at indices: ' + repr(mismatches))
    matchups = []
    for pair in pairs:
        games = grouped[pair]
        completed = [row for row in games if row['status'] == 'completed']
        counts = Counter(row['status'] for row in games)
        perspectives = {}
        for deck in pair:
            play = [row for row in games if row['decks'][int(row['starting_player'][1])] == deck]
            draw = [row for row in games if row['decks'][int(row['starting_player'][1])] != deck]
            perspectives[deck] = dict(overall=outcomes(games, deck), on_play=outcomes(play, deck),
                                      on_draw=outcomes(draw, deck))
        balance = Counter((tuple(row['decks']), row['starting_player']) for row in games)
        matchups.append(dict(pairing=list(pair), attempted=len(games), expected=games_per_pair,
            completed=len(completed), draws=sum(row['draw'] for row in completed),
            cutoffs=counts['cutoff'], errors=counts['error'],
            incomplete_reasons=dict(Counter(row.get('reason', 'unspecified') for row in games if row['status'] != 'completed')),
            perspectives=perspectives,
            seat_start_counts=[dict(decks=list(decks), starting_player=start, attempts=count)
                               for (decks, start), count in sorted(balance.items())],
            completed_global_turns=distribution([row['turn'] for row in completed if row.get('turn') is not None]),
            completed_decisions=distribution([row['decisions'] for row in completed]),
            completed_seconds=distribution([row['seconds'] for row in completed]),
            completed_actions_by_deck=action_counts(completed), all_attempt_actions_by_deck=action_counts(games)))
    counts = Counter(row['status'] for row in rows)
    completed = [row for row in rows if row['status'] == 'completed']
    return dict(schema=1,
        methodology=['Win rates and Wilson 95% confidence intervals divide wins by completed decisive games.',
                     'Draws, cutoffs and errors are reported separately; no replacement games or imputed results.',
                     'On play/on draw follows the actual starting player, independently of deck seat.',
                     'Turn and decision distributions use completed games only; turns count both players globally.',
                     'Intervals describe variation over these seeded games under fixed scripted policies, not tournament strength.'],
        metadata={key: report.get(key) for key in ('rustmage_revision', 'observation_schema', 'deck_data_sha256', 'config')},
        validation=dict(valid=not issues, issues=issues, expected_attempts=len(expected), actual_attempts=len(rows),
                        expected_nonmirror_pairings=len(pairs), missing_indices=missing, extra_indices=extra),
        overall=dict(attempted=len(rows), completed=len(completed), draws=sum(row['draw'] for row in completed),
                     decisive=sum(not row['draw'] for row in completed), cutoffs=counts['cutoff'], errors=counts['error'],
                     summed_game_seconds=sum(row['seconds'] for row in rows)), matchups=matchups)


def rate_text(result):
    if result['win_rate'] is None:
        return '—'
    low, high = result['wilson_95']
    return f"{100 * result['win_rate']:.1f}% ({100 * low:.1f}–{100 * high:.1f}%)"


def markdown(report):
    overall = report['overall']
    lines = ['# Standard baseline results', '',
             f"{overall['attempted']:,} attempts: {overall['completed']:,} completed, {overall['draws']:,} draws, "
             f"{overall['cutoffs']:,} cutoffs, {overall['errors']:,} errors.", '',
             'Win rates use completed decisive games; parentheses show Wilson 95% confidence intervals. '
             'These are results for fixed scripted policies.', '',
             '| First deck | Second deck | Wins, first–second | Draws | Completed / attempted | Cutoffs / errors | First-deck win rate | Median global turns |',
             '| --- | --- | ---: | ---: | ---: | ---: | --- | ---: |']
    for matchup in report['matchups']:
        first, second = matchup['pairing']
        a = matchup['perspectives'][first]['overall']
        b = matchup['perspectives'][second]['overall']
        median = matchup['completed_global_turns']['median']
        lines.append(f"| {first} | {second} | {a['wins']}–{b['wins']} | {matchup['draws']} | "
                     f"{matchup['completed']} / {matchup['attempted']} | {matchup['cutoffs']} / {matchup['errors']} | "
                     f"{rate_text(a)} | {median if median is not None else '—'} |")
    lines += ['', '| Deck | Opponent | On play W–L–D | On play win rate | On draw W–L–D | On draw win rate |',
              '| --- | --- | ---: | --- | ---: | --- |']
    for matchup in report['matchups']:
        for deck, values in matchup['perspectives'].items():
            opponent = next(other for other in matchup['pairing'] if other != deck)
            p, d = values['on_play'], values['on_draw']
            lines.append(f"| {deck} | {opponent} | {p['wins']}–{p['losses']}–{p['draws']} | {rate_text(p)} | "
                         f"{d['wins']}–{d['losses']}–{d['draws']} | {rate_text(d)} |")
    lines += ['', 'Play/draw W–L–D excludes incomplete games. The JSON report includes incomplete-game '
              'counts for each split, seat/start balance, action totals, and turn/decision distributions.', '']
    if report['validation']['issues']:
        lines += ['Validation issues:', '', *('- ' + issue for issue in report['validation']['issues']), '']
    return '\n'.join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', type=Path)
    parser.add_argument('--json-output', type=Path)
    parser.add_argument('--markdown-output', type=Path)
    args = parser.parse_args(argv)
    outputs = [path for path in (args.json_output, args.markdown_output) if path is not None]
    if len({path.resolve() for path in outputs}) != len(outputs):
        parser.error('Output files must be distinct')
    for path in outputs:
        if path.exists():
            parser.error('Refusing to overwrite an existing file: ' + str(path))
    raw = args.report.read_bytes()
    result = analyze(json.loads(raw))
    result.update(source_report=str(args.report.resolve()), source_report_sha256=hashlib.sha256(raw).hexdigest())
    encoded = json.dumps(result, indent=2) + '\n'
    for path, content in ((args.json_output, encoded), (args.markdown_output, markdown(result))):
        if path is not None:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('x') as stream:
                stream.write(content)
    print(encoded, end='')
    return 0 if result['validation']['valid'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
