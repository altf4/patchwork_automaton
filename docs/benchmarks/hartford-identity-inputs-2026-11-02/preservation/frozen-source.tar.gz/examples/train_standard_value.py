"""Minimal supervised value bootstrap from existing Standard expert games."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile

from patchwork_automaton.neural.value_demonstrations import select_games, select_next_games


def main(args):
    import numpy as np
    from patchwork_automaton.neural.devices import configure_runtime, device_scope, assert_model_device
    from patchwork_automaton.neural.experiment import atomic_json, save_checkpoint, make_trainer, load_checkpoint
    from patchwork_automaton.neural.standard_policy import StandardPolicy
    from patchwork_automaton.neural.standard_features import StandardEncoder
    from patchwork_automaton.neural.inference_processes import weights_digest
    from patchwork_automaton.neural.recurrent import configure_gru_backend

    if args.epochs not in (1, 2):
        raise ValueError('This bootstrap is bounded to one or two epochs')
    args.output.mkdir(parents=True, exist_ok=False)
    source_files = [args.source, args.source.with_suffix('.manifest.json'), args.source.with_name('state.json')]
    source_state = json.loads(args.source.with_name('state.json').read_text())
    continuing = source_state['config']['algorithm'] == 'value-imitation'
    if continuing:
        source_files.append(args.source.with_name('optimizer.npz'))
        if args.previous_selection is None:
            raise ValueError('Value continuation requires the previous whole-game selection')
    if args.previous_selection is not None:
        source_files.append(args.previous_selection)
    source_hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files if p.exists()}
    dataset_hashes = {str(p / 'dataset.json'): hashlib.sha256((p / 'dataset.json').read_bytes()).hexdigest()
                      for p in args.datasets}
    games = []
    for directory in args.datasets:
        dataset = json.loads((directory / 'dataset.json').read_text())
        if dataset['encoder']['fingerprint'] != StandardEncoder().manifest()['fingerprint']:
            raise ValueError('Demonstration feature schema mismatch')
        games.extend(dataset['games'])
    previous = json.loads(args.previous_selection.read_text()) if args.previous_selection else []
    used = source_state.get('round_result', {}).get('training_seeds_used', [])
    selected = (select_next_games(games, previous, args.games, args.seed, used)
                if previous else select_games(games, args.games, args.seed))
    training = [g for g in selected if g['partition'] == 'training']
    validation = [g for g in selected if g['partition'] == 'validation']
    atomic_json(args.output / 'selection.json', selected)
    configure_runtime(args.device, hide_gpu=args.device == 'cpu')
    config = dict(algorithm='value-imitation', learner_device=args.device,
        learning_rate=.0003, train_batch=args.train_batch, unroll=8, seed=args.seed)
    backend = 'cudnn-memory' if args.device == 'gpu' else 'unfused'
    if continuing:
        config = deepcopy(source_state['config'])
        if config['learner_device'] != args.device or config['train_batch'] != args.train_batch:
            raise ValueError('Continuation must preserve value learning configuration')
        with tempfile.TemporaryDirectory(dir=args.output) as temporary:
            pointer = Path(temporary)
            (pointer/'latest.json').write_text(json.dumps(dict(checkpoint=args.source.parent.name)))
            (pointer/args.source.parent.name).symlink_to(args.source.parent.resolve(), target_is_directory=True)
            with device_scope(args.device):
                model, trainer, loaded = load_checkpoint(pointer, policy_type=StandardPolicy, gru_backend=backend)
            if int(trainer.optimizer.iterations) != source_state['optimizer_steps']:
                raise AssertionError('Critic Adam was not restored')
            if trainer.rng.bit_generator.state != source_state['trainer_rng_state']:
                raise AssertionError('Critic RNG was not restored')
    else:
        with device_scope(args.device):
            model = StandardPolicy.load(args.source).model
            configure_gru_backend(model, backend)
            trainer = make_trainer(model, config)
    placements = assert_model_device(model, args.device)
    actor_digest = weights_digest(model.actor.get_weights())
    initial_critic = weights_digest(model.critic.get_weights())
    report = dict(status='running', config=config, source=str(args.source),
        source_actor_demonstration_games=source_state.get('round_result', {}).get('source_actor_demonstration_games',
            source_state.get('round_result', {}).get('cumulative_games')),
        source_stage_training_games=source_state.get('games_consumed'),
        source_sha256=source_hashes, datasets_sha256=dataset_hashes,
        games=len(selected), training_games=len(training), validation_games=len(validation),
        actor_weights_sha256=actor_digest, initial_critic_weights_sha256=initial_critic,
        continued_optimizer=continuing, initial_optimizer_steps=int(trainer.optimizer.iterations),
        selection_seed=args.seed, validation_cohort_preserved=bool(previous),
        training_seeds_used=sorted(set(used) | {g['seed'] for g in previous if g['partition']=='training'}
                                   | {g['seed'] for g in training}),
        device=args.device, variable_devices=sorted(set(placements.values())), epochs=[],
        methodology='Existing baseline demonstrations; per-seat terminal +1/-1/0 targets; '
            'whole-game heldout split; no wall-clock timeouts or incomplete games; actor frozen; '
            'critic memory starts at zero for each seat; eight-step truncated backpropagation.')
    path = args.output / 'report.json'
    atomic_json(path, report)
    def validate():
        before = (weights_digest(model.get_weights()),
                  weights_digest([np.asarray(v) for v in trainer.optimizer.variables]),
                  deepcopy(trainer.rng.bit_generator.state))
        result = trainer.run(validation)
        after = (weights_digest(model.get_weights()),
                 weights_digest([np.asarray(v) for v in trainer.optimizer.variables]),
                 deepcopy(trainer.rng.bit_generator.state))
        if before != after:
            raise AssertionError('Validation changed model, Adam or RNG')
        return result
    report['validation_before'] = validate()
    atomic_json(path, report)
    print(json.dumps(dict(event='value_before', mse=report['validation_before']['mse'],
                         optimizer_steps=int(trainer.optimizer.iterations))), flush=True)
    weighted = [(t['target'], t['samples']) for g in training for t in g['trajectories']]
    mean = sum(y*n for y,n in weighted) / sum(n for _,n in weighted)
    val_weighted = [(t['target'], t['samples']) for g in validation for t in g['trajectories']]
    report['training_mean_baseline'] = dict(value=mean,
        validation_mse=sum(n*(y-mean)**2 for y,n in val_weighted)/sum(n for _,n in val_weighted))
    best = (report['validation_before']['mse'], 0, model.critic.get_weights(),
            [np.asarray(v).copy() for v in trainer.optimizer.variables],
            deepcopy(trainer.rng.bit_generator.state))
    for epoch in range(1, args.epochs + 1):
        def progress(row):
            print(json.dumps(dict(event='value_fit', epoch=epoch, **row)), flush=True)
        fit = trainer.run(training, training=True, progress=progress)
        heldout = validate()
        row = dict(epoch=epoch, training=fit, validation=heldout)
        report['epochs'].append(row)
        if best is None or heldout['mse'] < best[0]:
            best = (heldout['mse'], epoch, model.critic.get_weights(),
                    [np.asarray(v).copy() for v in trainer.optimizer.variables],
                    deepcopy(trainer.rng.bit_generator.state))
        if weights_digest(model.actor.get_weights()) != actor_digest:
            raise AssertionError('Value training changed the actor')
        atomic_json(path, report)
        print(json.dumps(dict(event='value_epoch', **row)), flush=True)
    model.critic.set_weights(best[2])
    for variable, value in zip(trainer.optimizer.variables, best[3]):
        variable.assign(value)
    trainer.rng.bit_generator.state = best[4]
    final = validate()
    report.update(selected_epoch=best[1], validation_after=final, actor_unchanged=True,
        critic_updated=weights_digest(model.critic.get_weights()) != initial_critic,
        critic_weights_sha256=weights_digest(model.critic.get_weights()),
        validation_read_only=True, status='complete',
        beats_constant_baselines=final['mse'] < min(final['zero_mse'], report['training_mean_baseline']['validation_mse']))
    report['improved_over_source'] = final['mse'] < report['validation_before']['mse']
    for name, digest in {**source_hashes, **dataset_hashes}.items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != digest:
            raise AssertionError('Source inputs changed')
    report['source_inputs_unchanged'] = True
    checkpoint = save_checkpoint(args.output / 'checkpoints', model, trainer,
        dict(round=(source_state['round'] if continuing else 0) + best[1],
             config=config, round_result=report), policy_type=StandardPolicy)
    with device_scope(args.device):
        restored = StandardPolicy.load(checkpoint / 'policy.keras').model
    if weights_digest(restored.get_weights()) != weights_digest(model.get_weights()):
        raise AssertionError('Saved model differs')
    report.update(checkpoint=str(checkpoint), checkpoint_reload_verified=True)
    atomic_json(path, report)
    print(json.dumps(dict(event='complete', checkpoint=str(checkpoint),
        before_mse=report['validation_before']['mse'], after_mse=final['mse'],
        zero_mse=final['zero_mse'], actor_unchanged=True)), flush=True)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--datasets', type=Path, nargs='+', required=True)
    p.add_argument('--previous-selection', type=Path, help='Continue on fresh games, preserving this validation cohort')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--games', type=int, default=1200)
    p.add_argument('--epochs', type=int, default=2)
    p.add_argument('--train-batch', type=int, default=64, help='Concurrent seat sequences; unroll is eight')
    p.add_argument('--seed', type=int, default=30261029)
    p.add_argument('--device', choices=('cpu','gpu'), default='gpu')
    return p


if __name__ == '__main__':
    main(parser().parse_args())
