"""Read-only paired game bootstrap for the cached Standard role-pointer A/B.

The sign is ordered minus pooled expert negative log likelihood: negative
values favor ordered source/target pointers. The bootstrap resamples games
within each demonstration stage, retaining all target decisions in each game.
"""

import argparse
from collections import defaultdict
import json
import math
import os
from pathlib import Path
import tempfile

os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS', '0')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')

import numpy as np

from examples.diagnose_standard_decisions import file_sha256
from examples.train_cached_standard_role_ab import collate_targets, load_cache


DECK = 'mono-green-landfall'
ARMS = ('ordered', 'pooled')


def expert_nll(logits, mask, label):
    legal = np.asarray(logits[mask], np.float64)
    if not len(legal) or not np.isfinite(legal).all() or not 0 <= label < len(legal):
        raise ValueError('Invalid cached target logits, mask, or expert label')
    maximum = float(np.max(legal))
    return max(0., maximum + math.log(float(np.exp(legal - maximum).sum()))
               - float(legal[label]))


def head_from_weights(path, feature_width):
    import keras
    from keras import layers, ops

    class CachedResidualHead(keras.Model):
        def __init__(self):
            super().__init__()
            self.role_hidden = layers.Dense(64, activation='gelu')
            self.role_score = layers.Dense(1, kernel_initializer='zeros',
                                           bias_initializer='zeros')

        def call(self, features, training=False):
            return ops.squeeze(self.role_score(self.role_hidden(features)), axis=-1)

    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != {f'weight_{index}' for index in range(4)}:
            raise ValueError(f'Unexpected residual head weights: {path}')
        weights = [archive[f'weight_{index}'] for index in range(4)]
    head = CachedResidualHead()
    head(np.zeros((1, 1, feature_width), np.float32), training=False)
    head.set_weights(weights)
    return head


def verify_experiment(cache_path, experiment_path):
    cache_path = Path(cache_path).resolve()
    experiment_path = Path(experiment_path).resolve()
    cache, _, validation = load_cache(cache_path)
    experiment = json.loads(experiment_path.read_text())
    if (experiment.get('schema') != 1 or experiment.get('status') != 'complete'
            or Path(experiment.get('cache_path', '')).resolve() != cache_path
            or experiment.get('cache_manifest_sha256') != file_sha256(cache_path / 'cache.json')
            or experiment.get('checkpoint') != cache['checkpoint']
            or experiment.get('encoder_fingerprint') != cache['encoder_fingerprint']):
        raise ValueError('Complete role experiment does not match target cache')
    arms = experiment.get('arms', {})
    if set(arms) != set(ARMS):
        raise ValueError('Both complete role A/B arms required')
    if (arms['ordered']['optimizer_steps'] != arms['pooled']['optimizer_steps']
            or arms['ordered']['train_target_labels'] != arms['pooled']['train_target_labels']
            or not experiment.get('initial_head_weights_equal')):
        raise ValueError('Ordered and pooled training budgets or starts differ')
    weights = {}
    for arm in ARMS:
        item = arms[arm]['weights']
        path = Path(item['path']).resolve()
        if not path.is_file() or file_sha256(path) != item['sha256']:
            raise ValueError(f'Saved {arm} head hash mismatch')
        weights[arm] = dict(path=str(path), sha256=item['sha256'])
    return cache, experiment, validation, weights


def paired_target_losses(validation, heads, *, batch_size=32, deck=DECK):
    """Return one paired loss row per validation target of the requested deck."""
    selected = [(shard, index) for shard, index in validation
                if str(shard.arrays['decks'][index]) == deck]
    rows = []
    for start in range(0, len(selected), batch_size):
        batch = selected[start:start + batch_size]
        predictions = {}
        common_labels = common_mask = None
        for arm in ARMS:
            features, base, mask, labels = collate_targets(batch, arm)
            prediction = base + np.asarray(heads[arm](features, training=False))
            predictions[arm] = prediction
            if common_labels is None:
                common_labels, common_mask = labels, mask
            elif not (np.array_equal(common_labels, labels)
                      and np.array_equal(common_mask, mask)):
                raise AssertionError('A/B validation labels or legal masks differ')
        for position, (shard, index) in enumerate(batch):
            nll = {arm: expert_nll(predictions[arm][position], common_mask[position],
                                   int(common_labels[position])) for arm in ARMS}
            rows.append(dict(stage=shard.stage, game=int(shard.arrays['games'][index]),
                             player=int(shard.arrays['players'][index]),
                             decision=int(shard.arrays['decisions'][index]),
                             ordered_nll=nll['ordered'], pooled_nll=nll['pooled']))
    if not rows:
        raise ValueError(f'No {deck} validation target decisions')
    if len({(row['stage'], row['game'], row['player'], row['decision']) for row in rows}) != len(rows):
        raise ValueError('Duplicate cached validation target decision')
    return rows


def paired_game_summary(cache, losses, *, bootstrap_samples=10000, seed=5721):
    if bootstrap_samples < 1 or seed < 0:
        raise ValueError('Positive bootstrap count and nonnegative seed required')
    games = {}
    for stage in cache['stages']:
        number = int(stage['stage'])
        if number not in (1, 2):
            raise ValueError('Expected two Standard imitation stages')
        for index, game_seed in stage['selected_validation_games']:
            key = (number, int(index))
            if key in games:
                raise ValueError('Duplicate selected validation game')
            games[key] = dict(stage=number, game=int(index), seed=int(game_seed),
                              targets=0, ordered_nll_sum=0., pooled_nll_sum=0.)
    for row in losses:
        key = row['stage'], row['game']
        if key not in games:
            raise ValueError('Cached target belongs to an unselected validation game')
        game = games[key]
        game['targets'] += 1
        game['ordered_nll_sum'] += row['ordered_nll']
        game['pooled_nll_sum'] += row['pooled_nll']
    by_stage = {}
    for stage in (1, 2):
        selected = [row for row in games.values() if row['stage'] == stage]
        count = sum(row['targets'] for row in selected)
        if not selected or not count:
            raise ValueError(f'Stage {stage} has no selected games or target decisions')
        ordered = sum(row['ordered_nll_sum'] for row in selected)
        pooled = sum(row['pooled_nll_sum'] for row in selected)
        by_stage[str(stage)] = dict(games=len(selected),
            games_with_targets=sum(row['targets'] > 0 for row in selected),
            targets=count, ordered_mean_nll=ordered / count,
            pooled_mean_nll=pooled / count,
            ordered_minus_pooled_mean_nll=(ordered - pooled) / count)
    total = sum(row['targets'] for row in games.values())
    ordered = sum(row['ordered_nll_sum'] for row in games.values())
    pooled = sum(row['pooled_nll_sum'] for row in games.values())
    rng = np.random.default_rng(seed)
    stage_arrays = {stage: np.asarray([[row['targets'],
                                       row['ordered_nll_sum'] - row['pooled_nll_sum']]
                                      for row in games.values() if row['stage'] == stage],
                                     np.float64)
                    for stage in (1, 2)}
    draws = []
    skipped = 0
    while len(draws) < bootstrap_samples:
        parts = []
        for stage in (1, 2):
            values = stage_arrays[stage]
            indices = rng.integers(0, len(values), size=len(values))
            parts.append(values[indices].sum(axis=0))
        count = sum(part[0] for part in parts)
        if count <= 0:
            skipped += 1
            if skipped > bootstrap_samples * 10:
                raise ValueError('Bootstrap rarely contains target decisions')
            continue
        draws.append(sum(part[1] for part in parts) / count)
    interval = np.quantile(draws, (0.025, 0.975))
    per_game = [dict(row,
        ordered_minus_pooled_nll_sum=row['ordered_nll_sum'] - row['pooled_nll_sum'],
        ordered_minus_pooled_mean_nll=(
            (row['ordered_nll_sum'] - row['pooled_nll_sum']) / row['targets']
            if row['targets'] else None))
        for _, row in sorted(games.items())]
    return dict(deck=DECK, sign='ordered_minus_pooled; negative_favors_ordered',
        pooled=dict(targets=total, ordered_mean_nll=ordered / total,
                    pooled_mean_nll=pooled / total,
                    ordered_minus_pooled_mean_nll=(ordered - pooled) / total),
        stages=by_stage,
        bootstrap=dict(method='stage_stratified_game_resample_with_replacement',
            seed=seed, requested_samples=bootstrap_samples,
            valid_samples=len(draws), skipped_samples=skipped,
            confidence_level=0.95, ordered_minus_pooled_interval=[float(x) for x in interval]),
        games=per_game)


def write_new_json(path, payload):
    path = Path(path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', dir=path.parent, prefix='.role-ab-analysis-',
                                         delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(payload, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--experiment', type=Path, required=True,
                   help='Complete cached A/B experiment.json')
    p.add_argument('--bootstrap-samples', type=int, default=10000)
    p.add_argument('--seed', type=int, default=5721)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(argv)
    cache, experiment, validation, weights = verify_experiment(args.cache, args.experiment)
    width = validation[0][0].arrays['ordered_features'].shape[-1]
    heads = {arm: head_from_weights(weights[arm]['path'], width) for arm in ARMS}
    losses = paired_target_losses(validation, heads, deck=DECK)
    summary = paired_game_summary(cache, losses,
        bootstrap_samples=args.bootstrap_samples, seed=args.seed)
    report = dict(schema=1, analysis='cached_standard_role_ab_paired_games',
        cache_manifest=str((Path(args.cache).resolve() / 'cache.json')),
        cache_manifest_sha256=file_sha256(Path(args.cache) / 'cache.json'),
        experiment=str(Path(args.experiment).resolve()),
        experiment_sha256=file_sha256(args.experiment),
        heads=weights, analysis_script_sha256=file_sha256(__file__), **summary)
    write_new_json(args.output, report)
    print(json.dumps(dict(output=str(Path(args.output).resolve()),
        target_decisions=summary['pooled']['targets'],
        ordered_minus_pooled_mean_nll=summary['pooled']['ordered_minus_pooled_mean_nll'],
        interval=summary['bootstrap']['ordered_minus_pooled_interval'])), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
