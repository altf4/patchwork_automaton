"""Recover exact v5 target role pointers for audited ambiguous candidates.

Replays only the ten selected scripted games. It verifies each target decision
against its saved demonstration and refuses to write a partial or guessed map.
"""
import argparse
from collections import defaultdict
import json
from pathlib import Path

import numpy as np

from examples.audit_standard_action_encoding import _trajectory_path, sha256, write_new_json
from examples.classify_standard_action_ties import _plain
from patchwork_automaton.backends.rustmage import RustMageMatch, domain_action
from patchwork_automaton.baselines.standard import StandardAggro
from patchwork_automaton.baselines.standard_decks import standard_deck
from patchwork_automaton.neural import card_traits
from patchwork_automaton.neural.demonstrations import expert_index, read_demonstration
from patchwork_automaton.neural.role_pointers import role_layout
from patchwork_automaton.neural.rustmage_observation import learning_observation
from patchwork_automaton.neural.standard_features import StandardEncoder


ROLE_NAMES = ('source', 'target', 'other')
CORE_ARRAYS = ('entities', 'card_ids', 'entity_mask', 'semantics',
               'semantic_mask', 'relations', 'context', 'candidates',
               'candidate_refs', 'candidate_mask')


def raw_role_indices(obs, action, encoder):
    """Mirror the v5 encoder's actual source/target/other lookup exactly."""
    raw = obs.native
    players = sorted(obs.players, key=lambda player: player.id != obs.actor)
    objects = list(obs.objects.values())
    lookup = {player.id.value: index for index, player in enumerate(players)}
    lookup.update({int(obj.id.value): index + 2 for index, obj in enumerate(objects)})
    stack = list(raw['stack']) + list(raw['waiting_triggers'])
    stack_by_id = {item['id']: item for item in stack}
    pending = raw.get('announcing') or raw.get('resolving') or {}
    roles = encoder.action_roles(action)
    source_item = (stack_by_id.get(action.get('id'), {})
                   if action['kind'] == 'PutTrigger' else pending)
    source_key = roles.get('card', roles.get('blocker', source_item.get('card')))
    source = lookup.get(source_key)
    target_key = roles.get('target')
    target = None
    if target_key:
        if 'Player' in target_key:
            target = lookup[target_key['Player']]
        elif 'Card' in target_key:
            target = lookup.get(target_key['Card'])
        elif 'Spell' in target_key:
            target = lookup.get(target_key['Spell'])
        elif 'Stack' in target_key:
            target = lookup.get(stack_by_id.get(target_key['Stack'], {}).get('card'))
        else:
            raise ValueError('Unknown v5 target representation')
    other_key = roles.get('attacker')
    other = lookup.get(other_key)
    return (source, target, other), dict(
        source_lookup_key=_plain(source_key), target_key=_plain(target_key),
        other_lookup_key=_plain(other_key),
        source_name=source_item.get('source_card'))


def verify_role_blocks(arrays, manifest, candidate_index, indices, source_name):
    """Check exact role facts and average pointers stored in the v5 record."""
    action_width, semantic_width, entity_width, role_width = role_layout(manifest)
    candidates = arrays['candidates']
    entities = arrays['entities']
    semantics = arrays['semantics'][:, 0]
    refs = arrays['candidate_refs']
    if not 0 <= candidate_index < len(candidates):
        raise ValueError('Candidate index outside saved decision')
    for role, index in enumerate(indices):
        start = action_width + role * role_width
        block = candidates[candidate_index, start:start + role_width]
        if index is None:
            name = source_name if role == 0 else None
            traits = (card_traits.traits_for(name) if name is not None
                      else [0.] * semantic_width)
            expected = np.asarray([float(name is not None), *traits,
                                   *([0.] * entity_width)], np.float32)
        else:
            if not 0 <= index < len(entities):
                raise ValueError('Role entity index outside saved decision')
            expected = np.concatenate((np.ones(1, np.float32),
                semantics[index], entities[index])).astype(np.float32)
        if not np.array_equal(block, expected):
            raise ValueError(f'Saved {ROLE_NAMES[role]} role block differs from replayed identity')
    composed = np.zeros(len(entities), np.float32)
    linked = [index for index in indices if index is not None]
    for index in linked:
        composed[index] += 1
    composed /= max(len(linked), 1)
    if not np.allclose(composed, refs[candidate_index], rtol=0, atol=1e-6):
        raise ValueError('Saved pooled candidate reference differs from replayed identities')


def replay_game(game, records, targets, manifest, *, max_steps=6000):
    encoder = StandardEncoder()
    policies = [StandardAggro(deck) for deck in game['decks']]
    ordinals = [0, 0]
    found = {}
    verified_decisions = 0
    with RustMageMatch(*(standard_deck(deck) for deck in game['decks']),
            seed=game['seed'], starting_player=game['starting_player']) as match:
        for step in range(max_steps):
            views = [learning_observation(match, f'P{player}') for player in range(2)]
            if views[0].terminal:
                break
            actors = [player for player, view in enumerate(views)
                      if view.decision is not None]
            if len(actors) != 1:
                raise RuntimeError(f'Expected one prompted player at step {step}')
            player = actors[0]
            view = views[player]
            response = policies[player].choose(view)
            choices = encoder.expand_options(view.decision)
            if len(choices) > 1:
                ordinal = ordinals[player]
                ordinals[player] += 1
                if ordinal >= len(records[player]):
                    raise ValueError(f'Extra replay decision at P{player} ordinal {ordinal}')
                sample = records[player][ordinal]
                expert = expert_index(view.decision, response, choices)
                if (sample.decision_kind != view.decision.kind
                        or sample.action_kind != choices[expert][1]['kind']
                        or sample.action != expert):
                    raise ValueError(f'Scripted replay diverged at P{player} ordinal {ordinal}')
                key = (player, ordinal)
                if key in targets:
                    if view.decision.kind != 'targets':
                        raise ValueError('Failure audit selected a non-target decision')
                    encoded = encoder.encode(view, choices=choices).arrays
                    for name in CORE_ARRAYS:
                        if not np.array_equal(sample.arrays[name], encoded[name]):
                            raise ValueError(f'Saved v5 {name} diverged at P{player} ordinal {ordinal}')
                    if any(choices[index][1]['kind'] != 'ChooseTarget'
                           for index in targets[key]):
                        raise ValueError('Failure audit selected a non-ChooseTarget candidate')
                    rows = []
                    for candidate_index in targets[key]:
                        action = choices[candidate_index][1]
                        indices, identity = raw_role_indices(view, action, encoder)
                        verify_role_blocks(sample.arrays, manifest, candidate_index,
                                           indices, identity['source_name'])
                        rows.append(dict(player=player, decision=ordinal,
                            decision_ordinal=ordinal, candidate_index=candidate_index,
                            roles=list(indices), action_kind=action['kind'],
                            raw_action=_plain(action), role_identity=identity))
                    found[key] = rows
                    verified_decisions += 1
                    if len(found) == len(targets):
                        return found, verified_decisions
            option = next(option for option in view.decision.options
                          if option.id == response.option)
            action = (option.constraints['action'] if option.kind == 'finite'
                      else domain_action(option, response.value))
            raw = match._raw(view.actor.value)
            updated = (match.native_game.step(raw, int(option.id.split(':')[1]))
                       if option.kind == 'finite' else match.native_game.act(raw, action))
            match._after_action(updated, view.actor.value, raw['revision'])
    raise ValueError(f'Replay reached {len(found)} of {len(targets)} target decisions')


def build_sidecar(failure_path, stage1_path, stage2_path, *, max_steps=6000):
    failure_path = Path(failure_path).resolve()
    paths = {1: Path(stage1_path).resolve(), 2: Path(stage2_path).resolve()}
    audit = json.loads(failure_path.read_text())
    encoder = StandardEncoder()
    manifest = encoder.manifest()
    if audit.get('encoder_fingerprint') != manifest['fingerprint']:
        raise ValueError('Failure audit and replay v5 encoder differ')
    datasets = {stage: json.loads(path.read_text()) for stage, path in paths.items()}
    expected_hashes = set(audit['datasets'].values())
    dataset_hashes = {stage: sha256(path) for stage, path in paths.items()}
    if set(dataset_hashes.values()) != expected_hashes:
        raise ValueError('Failure audit and dataset manifests differ')
    for stage, dataset in datasets.items():
        if dataset['encoder']['fingerprint'] != manifest['fingerprint']:
            raise ValueError(f'Stage {stage} dataset and replay v5 encoder differ')
    by_game = defaultdict(lambda: defaultdict(list))
    failure_meta = {}
    for failure in audit['failures']:
        stage, game = failure['stage'], failure['game']
        key = (stage, game, failure['player'], failure['decision'])
        if key in failure_meta:
            raise ValueError('Duplicate failure decision key')
        failure_meta[key] = failure
        for index, status in failure['candidates']:
            if status != 'ambiguous' or type(index) is not int:
                raise ValueError('Failure audit contains a non-ambiguous candidate')
            by_game[stage, game][failure['player'], failure['decision']].append(index)
    expected_rows = sum(len(failure['candidates']) for failure in audit['failures'])
    if (expected_rows != audit['totals']['ambiguous']
            or expected_rows != 62 or len(by_game) != 10):
        raise ValueError('Failure audit is not the selected ten-game, 62-slot sample')
    rows = []
    verified_games = []
    trajectory_hashes = {}
    for (stage, game_index), targets in sorted(by_game.items()):
        game = next((item for item in datasets[stage]['games']
                     if item['index'] == game_index), None)
        if game is None:
            raise ValueError(f'Stage {stage} game {game_index} missing from dataset')
        records = {}
        for trajectory in game['trajectories']:
            path = _trajectory_path(paths[stage], trajectory)
            records[trajectory['player']] = read_demonstration(
                dict(trajectory, path=str(path)))
            trajectory_hashes[str(path.resolve())] = sha256(path)
        for (player, ordinal), indices in targets.items():
            failure = failure_meta[stage, game_index, player, ordinal]
            trajectory = next(item for item in game['trajectories']
                              if item['player'] == player)
            if (game['seed'] != failure['seed'] or game['partition'] != failure['partition']
                    or trajectory['deck'] != failure['deck']
                    or trajectory['samples'] != failure['samples']
                    or Path(trajectory['path']).name != Path(failure['path']).name):
                raise ValueError(f'Failure metadata differs for stage {stage} game {game_index}')
            if len(indices) != len(set(indices)):
                raise ValueError('Duplicate candidate index in failure audit')
        found, verified_decisions = replay_game(game, records, targets, manifest,
                                                max_steps=max_steps)
        for (player, ordinal), decision_rows in found.items():
            for row in decision_rows:
                rows.append(dict(stage=stage, game=game_index,
                                 partition=game['partition'], **row))
        verified_games.append(dict(stage=stage, game=game_index,
            partition=game['partition'], seed=game['seed'],
            decisions_verified=verified_decisions,
            candidate_rows_recovered=sum(len(items) for items in found.values())))
    rows.sort(key=lambda row: (row['stage'], row['game'], row['player'],
                               row['decision_ordinal'], row['candidate_index']))
    keys = [(row['stage'], row['game'], row['player'], row['decision_ordinal'],
             row['candidate_index']) for row in rows]
    if len(rows) != expected_rows or len(keys) != len(set(keys)):
        raise ValueError('Role sidecar did not recover exactly the selected candidate slots')
    expected_keys = {(failure['stage'], failure['game'], failure['player'],
                      failure['decision'], index)
                     for failure in audit['failures'] for index, _ in failure['candidates']}
    if set(keys) != expected_keys or len(verified_games) != 10:
        raise ValueError('Role sidecar key set differs from failure audit')
    return dict(schema=1, status='complete', role_order=list(ROLE_NAMES),
        encoder_fingerprint=manifest['fingerprint'],
        failure_report=str(failure_path), failure_report_sha256=sha256(failure_path),
        datasets={str(stage): dict(path=str(path), sha256=dataset_hashes[stage])
                  for stage, path in paths.items()},
        trajectory_sha256=dict(sorted(trajectory_hashes.items())),
        expected_games=10, expected_decisions=len(audit['failures']),
        expected_rows=expected_rows, recovered_rows=len(rows),
        verified_games=verified_games, rows=rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--failure-report', type=Path, required=True)
    parser.add_argument('--stage1-dataset', type=Path, required=True)
    parser.add_argument('--stage2-dataset', type=Path, required=True)
    parser.add_argument('--max-steps', type=int, default=6000)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    if args.max_steps < 1:
        parser.error('Positive step limit required')
    result = build_sidecar(args.failure_report, args.stage1_dataset,
                           args.stage2_dataset, max_steps=args.max_steps)
    write_new_json(args.output, result)
    print(json.dumps(dict(output=str(args.output.resolve()),
        games=len(result['verified_games']), decisions=result['expected_decisions'],
        rows=result['recovered_rows'], trajectories=len(result['trajectory_sha256']))),
        flush=True)


if __name__ == '__main__':
    main()
