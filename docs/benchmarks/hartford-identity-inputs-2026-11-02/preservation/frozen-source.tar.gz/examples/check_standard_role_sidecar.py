"""Read-only provenance/key gate before the exact-role cache extraction."""

import argparse
import json
from pathlib import Path

from examples.cache_standard_target_roles import load_exact_role_sidecar
from examples.diagnose_standard_decisions import checkpoint_files, file_sha256
from examples.run_standard_role_ab import selected_stages


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--checkpoint-sha256', required=True)
    p.add_argument('--datasets', nargs=2, type=Path, required=True)
    p.add_argument('--failure-audit', type=Path, required=True)
    p.add_argument('--role-sidecar', type=Path, required=True)
    p.add_argument('--train-games-per-stage', type=int, default=600)
    p.add_argument('--validation-games-per-stage', type=int, default=240)
    p.add_argument('--sample-seed', type=int, default=73)
    args = p.parse_args(argv)
    checkpoint, sidecar = checkpoint_files(args.checkpoint)
    if file_sha256(checkpoint) != args.checkpoint_sha256:
        raise ValueError('cp200 checkpoint SHA256 mismatch')
    manifest = json.loads(sidecar.read_text())
    stages = selected_stages(args.datasets, manifest,
        train_games_per_stage=args.train_games_per_stage,
        validation_games_per_stage=args.validation_games_per_stage,
        sample_seed=args.sample_seed)
    rows, provenance = load_exact_role_sidecar(args.role_sidecar,
        args.failure_audit, manifest, stages, args.checkpoint_sha256,
        args.sample_seed)
    print(json.dumps(dict(status='verified', role_rows=len(rows),
        sidecar_sha256=provenance['sha256'],
        failure_audit_sha256=provenance['failure_audit_sha256'],
        hashed_trajectories=len(provenance['trajectory_sha256']),
        selected_games={f"{stage['stage']}|{partition}": len(stage[partition])
                        for stage in stages for partition in ('training', 'validation')}),
        sort_keys=True), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
