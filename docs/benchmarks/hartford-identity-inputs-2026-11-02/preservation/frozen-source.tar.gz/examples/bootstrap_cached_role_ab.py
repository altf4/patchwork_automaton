"""Paired, game-level uncertainty for the predeclared mono-green target endpoint."""

import argparse
from collections import defaultdict
import json
import math
import os
from pathlib import Path

os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS', '0')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')

import numpy as np

from examples.diagnose_standard_decisions import file_sha256
from examples.train_cached_standard_role_ab import collate_targets, load_cache
from examples.run_standard_role_ab import write_atomic_json


def load_head(path, expected_sha, width):
    import keras
    from keras import layers, ops
    if file_sha256(path) != expected_sha:
        raise ValueError(f'Trained head hash mismatch: {path}')

    class Head(keras.Model):
        def __init__(self):
            super().__init__()
            self.role_hidden = layers.Dense(64, activation='gelu')
            self.role_score = layers.Dense(1)

        def call(self, features, training=False):
            return ops.squeeze(self.role_score(self.role_hidden(features)), axis=-1)

    head = Head()
    head(np.zeros((1, 1, width), np.float32), training=False)
    with np.load(path, allow_pickle=False) as archive:
        weights = [archive[f'weight_{index}'] for index in range(4)]
    head.role_hidden.set_weights(weights[:2])
    head.role_score.set_weights(weights[2:])
    return head


def per_record_nll(head, records, arm, batch_size):
    nlls = np.zeros(len(records), np.float64)
    correct = np.zeros(len(records), np.int8)
    for start in range(0, len(records), batch_size):
        selected = records[start:start + batch_size]
        features, base, mask, labels = collate_targets(selected, arm)
        logits = base + np.asarray(head(features, training=False))
        for row in range(len(selected)):
            legal = np.asarray(logits[row, mask[row]], np.float64)
            maximum = float(np.max(legal))
            logsumexp = maximum + math.log(float(np.exp(legal - maximum).sum()))
            nlls[start + row] = max(0., logsumexp - float(legal[labels[row]]))
            correct[start + row] = int(np.argmax(legal) == labels[row])
    return nlls, correct


def paired_bootstrap(records, ordered_nll, pooled_nll, ordered_correct,
                     pooled_correct, *, seed, replicates):
    games = defaultdict(lambda: np.zeros(3, np.float64))
    for i, (shard, index) in enumerate(records):
        if str(shard.arrays['decks'][index]) != 'mono-green-landfall':
            continue
        key = (shard.stage, int(shard.arrays['games'][index]))
        row = games[key]
        row[0] += ordered_nll[i] - pooled_nll[i]
        row[1] += ordered_correct[i] - pooled_correct[i]
        row[2] += 1
    if not games:
        raise ValueError('No mono-green target decisions in held-out cache')
    rng = np.random.default_rng(seed)
    total_nll = np.zeros(replicates, np.float64)
    total_accuracy = np.zeros(replicates, np.float64)
    total_labels = np.zeros(replicates, np.float64)
    stages = {}
    for stage in (1, 2):
        rows = np.stack([value for (number, _), value in sorted(games.items())
                         if number == stage])
        if not len(rows):
            raise ValueError(f'No mono-green target games in stage {stage}')
        picks = rng.integers(0, len(rows), size=(replicates, len(rows)))
        sampled = rows[picks].sum(axis=1)
        delta_nll = sampled[:, 0] / sampled[:, 2]
        delta_accuracy = sampled[:, 1] / sampled[:, 2]
        point = rows.sum(axis=0)
        stages[str(stage)] = dict(games=len(rows), targets=int(point[2]),
            ordered_minus_pooled_nll=float(point[0] / point[2]),
            nll_bootstrap_95=np.quantile(delta_nll, [.025, .975]).tolist(),
            ordered_minus_pooled_top1=float(point[1] / point[2]),
            top1_bootstrap_95=np.quantile(delta_accuracy, [.025, .975]).tolist())
        total_nll += sampled[:, 0]
        total_accuracy += sampled[:, 1]
        total_labels += sampled[:, 2]
    point = np.sum(list(games.values()), axis=0)
    nll_delta = total_nll / total_labels
    accuracy_delta = total_accuracy / total_labels
    return dict(seed=seed, replicates=replicates, unit='whole validation game; stratified by stage',
        sign='ordered minus pooled; negative NLL favors ordered',
        games=len(games), targets=int(point[2]),
        ordered_minus_pooled_nll=float(point[0] / point[2]),
        nll_bootstrap_95=np.quantile(nll_delta, [.025, .975]).tolist(),
        bootstrap_fraction_ordered_lower_nll=float(np.mean(nll_delta < 0)),
        ordered_minus_pooled_top1=float(point[1] / point[2]),
        top1_bootstrap_95=np.quantile(accuracy_delta, [.025, .975]).tolist(),
        stages=stages)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--experiment', type=Path, required=True,
                   help='Completed cached-head experiment.json')
    p.add_argument('--output', type=Path, required=True,
                   help='New read-only postanalysis JSON')
    p.add_argument('--seed', type=int, default=20261030)
    p.add_argument('--replicates', type=int, default=10000)
    args = p.parse_args(argv)
    if args.output.exists() or args.seed < 0 or args.replicates < 100:
        p.error('New output, nonnegative seed, at least 100 bootstrap replicates required')
    cache, _, validation = load_cache(args.cache)
    experiment = json.loads(args.experiment.read_text())
    if (experiment.get('status') != 'complete'
            or experiment['cache_manifest_sha256'] != file_sha256(Path(args.cache) / 'cache.json')):
        raise ValueError('Completed experiment must match this frozen target cache')
    width = validation[0][0].arrays['ordered_features'].shape[-1]
    batch_size = experiment['config']['target_batch_size']
    scores = {}
    for arm in ('ordered', 'pooled'):
        weights = experiment['arms'][arm]['weights']
        head = load_head(weights['path'], weights['sha256'], width)
        scores[arm] = per_record_nll(head, validation, arm, batch_size)
        # Recomputed aggregate must agree with the frozen evaluation report.
        reported = experiment['arms'][arm]['validation']['all']['mean_negative_log_likelihood']
        if abs(float(scores[arm][0].mean()) - reported) > 1e-5:
            raise AssertionError(f'Recomputed {arm} target NLL differs from experiment')
    bootstrap = paired_bootstrap(validation, scores['ordered'][0], scores['pooled'][0],
        scores['ordered'][1], scores['pooled'][1], seed=args.seed,
        replicates=args.replicates)
    result = dict(schema=1, source='read_only_paired_game_bootstrap',
        cache_manifest_sha256=file_sha256(Path(args.cache) / 'cache.json'),
        experiment_sha256=file_sha256(args.experiment),
        fitter_source_sha256=experiment['fitter_source_sha256'],
        bootstrap=bootstrap)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(output=str(args.output.resolve()),
                          bootstrap=bootstrap), sort_keys=True), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
