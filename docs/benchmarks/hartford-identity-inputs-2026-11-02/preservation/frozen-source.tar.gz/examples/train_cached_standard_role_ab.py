"""Train equal-capacity role residual heads on one-pass frozen target cache."""

import argparse
from collections import defaultdict
import json
import math
import os
from pathlib import Path
import time

os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS', '0')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')

import numpy as np

from examples.diagnose_standard_decisions import file_sha256
from examples.run_standard_role_ab import pooled_control_refs, write_atomic_json
from patchwork_automaton.neural.demonstrations import read_demonstration
from patchwork_automaton.neural.role_pointers import exact_role_refs_from_indices


class CachedShard:
    def __init__(self, metadata):
        path = Path(metadata['path'])
        if file_sha256(path) != metadata['sha256']:
            raise ValueError(f'Cached target shard hash mismatch: {path}')
        with np.load(path, allow_pickle=False) as archive:
            self.arrays = {key: archive[key] for key in archive.files}
        self.stage = int(metadata['stage'])
        self.partition = metadata['partition']
        offsets = self.arrays['offsets']
        if (len(offsets) != metadata['records'] + 1 or offsets[0] != 0
                or np.any(np.diff(offsets) < 2)
                or offsets[-1] != metadata['candidate_rows']
                or len(self.arrays['labels']) != metadata['records']):
            raise ValueError('Malformed cached target shard offsets or labels')
        for key in ('ordered_features', 'pooled_features'):
            if (self.arrays[key].shape != (offsets[-1], metadata['feature_width'])
                    or not np.isfinite(self.arrays[key]).all()):
                raise ValueError(f'Malformed cached target {key}')
        if (self.arrays['base_logits'].shape != (offsets[-1],)
                or not np.isfinite(self.arrays['base_logits']).all()):
            raise ValueError('Malformed cached base logits')
        ambiguity = self.arrays['ambiguous_candidate_count']
        if len(ambiguity) != metadata['records'] or np.any(ambiguity < 0):
            raise ValueError('Malformed cached ambiguity counts')
        roles = self.arrays['role_indices']
        if roles.shape != (offsets[-1], 3) or np.any(roles < -1):
            raise ValueError('Malformed cached exact role indices')

    def __len__(self):
        return len(self.arrays['labels'])

    def record(self, index, arm):
        arrays = self.arrays
        start, end = map(int, arrays['offsets'][index:index + 2])
        return (arrays[f'{arm}_features'][start:end], arrays['base_logits'][start:end],
                int(arrays['labels'][index]))


def load_cache(path):
    directory = Path(path).resolve()
    manifest_path = directory / 'cache.json'
    report = json.loads(manifest_path.read_text())
    if report.get('status') != 'complete' or report.get('schema') != 1:
        raise ValueError('Complete target cache required')
    for source, digest in report['source_sha256'].items():
        if file_sha256(source) != digest:
            raise ValueError(f'Cached source code changed: {source}')
    checkpoint = report['checkpoint']
    if (file_sha256(checkpoint['path']) != checkpoint['sha256']
            or file_sha256(checkpoint['manifest_path']) != checkpoint['manifest_sha256']):
        raise ValueError('Frozen cp200 checkpoint changed since extraction')
    for source, digest in report['datasets'].items():
        if file_sha256(source) != digest:
            raise ValueError('Saved v5 dataset manifest changed since extraction')
    sidecar = report['raw_role_sidecar']
    if (file_sha256(sidecar['path']) != sidecar['sha256']
            or file_sha256(sidecar['failure_audit_path']) != sidecar['failure_audit_sha256']
            or sidecar['consumed_rows'] != sidecar['expected_rows']):
        raise ValueError('Exact raw role replay sidecar changed or is incomplete')
    for trajectory, digest in sidecar['trajectory_sha256'].items():
        if file_sha256(trajectory) != digest:
            raise ValueError('Raw replayed trajectory changed since extraction')
    shards = [CachedShard(metadata) for metadata in report['shards']]
    if {(shard.stage, shard.partition) for shard in shards} != {
            (1, 'training'), (1, 'validation'), (2, 'training'), (2, 'validation')}:
        raise ValueError('Cache needs both partitions from both stages')
    train = [(shard, index) for shard in shards if shard.partition == 'training'
             for index in range(len(shard))]
    validation = [(shard, index) for shard in shards if shard.partition == 'validation'
                  for index in range(len(shard))]
    if not train or not validation:
        raise ValueError('Target cache has no training or validation labels')
    train_games = {int(shard.arrays['games'][index]) for shard, index in train}
    validation_games = {int(shard.arrays['games'][index]) for shard, index in validation}
    if train_games & validation_games:
        raise ValueError('Cached training/validation game leakage')
    return report, train, validation


def collate_targets(records, arm):
    if not records:
        raise ValueError('No cached target records')
    width = records[0][0].arrays[f'{arm}_features'].shape[-1]
    actions = max(int(shard.arrays['offsets'][index + 1] - shard.arrays['offsets'][index])
                  for shard, index in records)
    features = np.zeros((len(records), actions, width), np.float32)
    base_logits = np.full((len(records), actions), -1.e9, np.float32)
    mask = np.zeros((len(records), actions), bool)
    labels = np.zeros(len(records), np.int32)
    for row, (shard, index) in enumerate(records):
        current, logits, label = shard.record(index, arm)
        count = len(logits)
        if not 0 <= label < count:
            raise ValueError('Cached expert choice outside legal targets')
        features[row, :count] = current
        base_logits[row, :count] = logits
        mask[row, :count] = True
        labels[row] = label
    return features, base_logits, mask, labels


def _fresh_counts():
    return dict(samples=0, correct=0, probability_sum=0., nll_sum=0.)


def summarize(groups):
    return {key: dict(samples=row['samples'], top1_accuracy=row['correct']/row['samples'],
                      mean_expert_probability=row['probability_sum']/row['samples'],
                      mean_negative_log_likelihood=row['nll_sum']/row['samples'])
            for key, row in sorted(groups.items()) if row['samples']}


def evaluate(head, records, arm, *, batch_size, device):
    from patchwork_automaton.neural.devices import device_scope
    groups = defaultdict(_fresh_counts)
    for start in range(0, len(records), batch_size):
        selected = records[start:start + batch_size]
        features, base, mask, labels = collate_targets(selected, arm)
        if head is None:
            logits = base
        else:
            with device_scope(device):
                logits = base + np.asarray(head(features, training=False))
        for row, (shard, index) in enumerate(selected):
            legal = np.asarray(logits[row, mask[row]], np.float64)
            if not np.isfinite(legal).all():
                raise FloatingPointError('Nonfinite cached target evaluation')
            maximum = float(np.max(legal))
            logsumexp = maximum + math.log(float(np.exp(legal - maximum).sum()))
            nll = max(0., logsumexp - float(legal[labels[row]]))
            if not math.isfinite(nll):
                raise FloatingPointError('Invalid cached expert negative log likelihood')
            expert = math.exp(-nll) if nll < 745 else 0.
            deck = str(shard.arrays['decks'][index])
            keys = ['all', f'stage-{shard.stage}', f'deck:{deck}',
                    f'stage-{shard.stage}|deck:{deck}']
            if shard.arrays['ambiguous_candidate_count'][index] == 0:
                keys += ['unique-only|all', f'unique-only|stage-{shard.stage}',
                         f'unique-only|deck:{deck}',
                         f'unique-only|stage-{shard.stage}|deck:{deck}']
            for key in keys:
                counts = groups[key]
                counts['samples'] += 1
                counts['correct'] += int(np.argmax(legal) == labels[row])
                counts['probability_sum'] += expert
                counts['nll_sum'] += nll
    return summarize(groups)


def save_head(path, head):
    weights = head.role_hidden.get_weights() + head.role_score.get_weights()
    temporary = path.with_suffix('.tmp.npz')
    np.savez_compressed(temporary, **{f'weight_{index}': value
                                     for index, value in enumerate(weights)})
    os.replace(temporary, path)
    return dict(path=str(path), sha256=file_sha256(path))


def verify_trained_online(head, arm, validation, cache, *, device):
    import keras
    from patchwork_automaton.neural import model as registered_models  # noqa: F401
    from patchwork_automaton.neural.batching import example_batch
    from patchwork_automaton.neural.devices import device_scope
    from patchwork_automaton.neural.features import collate
    from patchwork_automaton.neural.role_residual import RoleResidualPolicy

    manifest = json.loads(Path(cache['checkpoint']['manifest_path']).read_text())
    target_index = len(manifest['steps']) + manifest['decisions'].index('targets')
    with device_scope(device):
        saved = keras.saving.load_model(cache['checkpoint']['path'], compile=False)
        actor = saved.actor if getattr(saved, 'separate_value', False) else saved
        actor.trainable = False
        wrapper = RoleResidualPolicy(actor, action_width=len(manifest['actions']),
                                     target_context_index=target_index)
        dummy = example_batch(actor.memory_size, actor.feature_spec)
        wrapper(dummy, training=False)
        wrapper.role_hidden.set_weights(head.role_hidden.get_weights())
        wrapper.role_score.set_weights(head.role_score.get_weights())
    checks = []
    for shard, index in validation[:3]:
        arrays = shard.arrays
        trajectory = dict(path=str(arrays['paths'][index]),
                          samples=int(arrays['trajectory_samples'][index]))
        sample = read_demonstration(trajectory)[int(arrays['decisions'][index])]
        start, end = map(int, arrays['offsets'][index:index + 2])
        role_indices = arrays['role_indices'][start:end]
        pointers = np.zeros((len(role_indices), 3, len(sample.arrays['entities'])), np.float32)
        for candidate, indices in enumerate(role_indices):
            roles = [None if entity < 0 else int(entity) for entity in indices]
            pointers[candidate] = exact_role_refs_from_indices(
                sample.arrays, manifest, candidate, roles)
        if arm == 'pooled':
            pointers = pooled_control_refs(dict(sample.arrays, candidate_role_refs=pointers))
        batch = collate([sample.arrays])
        batch['candidate_role_refs'] = pointers[None]
        batch['memory_in'] = arrays['memory_in'][index:index + 1]
        batch['advance_memory'] = np.ones((1, 1), np.float32)
        with device_scope(device):
            output = wrapper(batch, training=False)
        features, base, _, _ = collate_targets([(shard, index)], arm)
        expected = base[0] + np.asarray(head(features, training=False))[0]
        count = len(sample.arrays['candidates'])
        delta = float(np.max(np.abs(np.asarray(output['logits'])[0, :count] - expected[:count])))
        memory_delta = float(np.max(np.abs(np.asarray(output['memory_out'])[0] - arrays['memory_out'][index])))
        if delta > 1e-4 or memory_delta > 1e-4:
            raise AssertionError('Trained online/cached target parity failed')
        checks.append(dict(game=int(arrays['games'][index]),
                           decision=int(arrays['decisions'][index]),
                           logits=delta, memory=memory_delta))
    non_target = []
    for item in cache['non_target_checks'][:3]:
        sample = read_demonstration(dict(path=item['path'], samples=item['samples']))[item['ordinal']]
        batch = collate([sample.arrays])
        batch['memory_in'] = np.asarray([item['memory_in']], np.float32)
        batch['advance_memory'] = np.ones((1, 1), np.float32)
        if batch['context'][0, target_index] != 0:
            raise AssertionError('Non-target gate example is actually a target')
        with device_scope(device):
            base = actor(batch, training=False)
            output = wrapper(batch, training=False)
        delta = float(np.max(np.abs(np.asarray(base['logits']) - np.asarray(output['logits']))))
        if delta > 1e-7:
            raise AssertionError('Trained residual changed non-target cp200 logits')
        non_target.append(dict(decision=item['ordinal'], logits=delta))
    return dict(target=checks, non_target=non_target)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seed', type=int, default=5721)
    p.add_argument('--target-batch-size', type=int, default=16)
    p.add_argument('--epochs', type=int, default=4)
    p.add_argument('--learning-rate', type=float, default=.0003)
    p.add_argument('--device', choices=('cpu', 'gpu'), default='gpu')
    args = p.parse_args(argv)
    if (args.output.exists() or args.seed < 0 or min(args.target_batch_size, args.epochs) < 1
            or not 0 < args.learning_rate < float('inf')):
        p.error('New output, positive training budget/rate and nonnegative seed required')

    import keras
    import tensorflow as tf
    from keras import layers, ops
    from patchwork_automaton.neural.devices import configure_runtime, device_scope

    cache, train, validation = load_cache(args.cache)
    configure_runtime(args.device, hide_gpu=args.device == 'cpu')
    keras.utils.set_random_seed(args.seed)
    width = train[0][0].arrays['ordered_features'].shape[-1]
    if any(shard.arrays['ordered_features'].shape[-1] != width
           for shard, _ in train + validation):
        raise ValueError('Mixed cached target feature widths')

    class CachedResidualHead(keras.Model):
        def __init__(self):
            super().__init__()
            self.role_hidden = layers.Dense(64, activation='gelu')
            self.role_score = layers.Dense(1, kernel_initializer='zeros',
                                           bias_initializer='zeros')

        def call(self, features, training=False):
            return ops.squeeze(self.role_score(self.role_hidden(features)), axis=-1)

    with device_scope(args.device):
        heads = {'ordered': CachedResidualHead(), 'pooled': CachedResidualHead()}
        dummy = np.zeros((1, 1, width), np.float32)
        for head in heads.values():
            head(dummy, training=False)
        heads['pooled'].set_weights(heads['ordered'].get_weights())
        optimizers = {arm: keras.optimizers.Adam(args.learning_rate) for arm in heads}
        for arm in heads:
            optimizers[arm].build(heads[arm].trainable_variables)
    parameter_counts = {arm: sum(int(np.prod(v.shape)) for v in head.trainable_variables)
                        for arm, head in heads.items()}
    if len(set(parameter_counts.values())) != 1:
        raise AssertionError('Ordered/pooled residual capacity differs')

    def train_step(head, optimizer):
        @tf.function(input_signature=[tf.TensorSpec((None, None, width), tf.float32),
            tf.TensorSpec((None, None), tf.float32),
            tf.TensorSpec((None, None), tf.bool),
            tf.TensorSpec((None,), tf.int32)], autograph=False)
        def step(features, base, mask, labels):
            with tf.GradientTape() as tape:
                logits = base + head(features, training=True)
                logits = tf.where(mask, logits, tf.fill(tf.shape(logits), -1.e9))
                loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(
                    labels=labels, logits=logits))
            gradients = tape.gradient(loss, head.trainable_variables)
            for gradient in gradients:
                tf.debugging.assert_all_finite(gradient, 'Nonfinite cached role gradient')
            clipped, _ = tf.clip_by_global_norm(gradients, 1.)
            optimizer.apply_gradients(zip(clipped, head.trainable_variables))
            return loss
        return step

    baseline = evaluate(None, validation, 'ordered',
                        batch_size=args.target_batch_size, device=args.device)
    schedule_rng = np.random.default_rng(args.seed)
    schedules = [schedule_rng.permutation(len(train)) for _ in range(args.epochs)]
    args.output.mkdir(parents=True, exist_ok=False)
    result = dict(schema=1, status='running', cache_path=str(Path(args.cache).resolve()),
        cache_manifest_sha256=file_sha256(Path(args.cache) / 'cache.json'),
        fitter_source_sha256=file_sha256(Path(__file__).resolve()),
        encoder_fingerprint=cache['encoder_fingerprint'],
        checkpoint=cache['checkpoint'],
        selected_games=cache['stages'],
        config=dict(seed=args.seed, target_batch_size=args.target_batch_size,
                    epochs=args.epochs, learning_rate=args.learning_rate,
                    device=args.device, loss='target_only_cross_entropy', clip_norm=1.),
        train_targets=len(train), validation_targets=len(validation),
        ambiguity={f"stage-{shard['stage']}|{shard['partition']}":
                   {key: shard['stats'][key] for key in
                    ('ambiguous_decisions', 'ambiguous_candidates', 'ambiguous_chosen')}
                   for shard in cache['shards']},
        trainable_parameters=parameter_counts['ordered'], baseline_cp200=baseline,
        initial_head_weights_equal=all(np.array_equal(a, b) for a, b in zip(
            heads['ordered'].get_weights(), heads['pooled'].get_weights())), arms={})
    write_atomic_json(args.output / 'experiment.partial.json', result)
    for arm, head in heads.items():
        step = train_step(head, optimizers[arm])
        started = time.monotonic()
        losses = []
        for epoch, order in enumerate(schedules, 1):
            for start in range(0, len(order), args.target_batch_size):
                selected = [train[int(index)] for index in order[start:start + args.target_batch_size]]
                features, base, mask, labels = collate_targets(selected, arm)
                with device_scope(args.device):
                    loss = float(step(features, base, mask, labels))
                if not math.isfinite(loss):
                    raise FloatingPointError('Nonfinite cached target training loss')
                losses.append(loss)
            print(json.dumps(dict(event='head_epoch', arm=arm, epoch=epoch,
                steps=int(optimizers[arm].iterations), mean_batch_loss=float(np.mean(losses)))), flush=True)
        fit_seconds = time.monotonic() - started
        metrics = evaluate(head, validation, arm,
                           batch_size=args.target_batch_size, device=args.device)
        parity = verify_trained_online(head, arm, validation, cache, device=args.device)
        head_path = args.output / f'{arm}-head.npz'
        weights = save_head(head_path, head)
        result['arms'][arm] = dict(optimizer_steps=int(optimizers[arm].iterations),
            fit_seconds=fit_seconds, train_target_labels=len(train) * args.epochs,
            mean_batch_loss=float(np.mean(losses)), validation=metrics,
            online_parity=parity, weights=weights)
        write_atomic_json(args.output / 'experiment.partial.json', result)
        print(json.dumps(dict(event='head_complete', arm=arm,
            optimizer_steps=int(optimizers[arm].iterations), fit_seconds=fit_seconds,
            mono_green=metrics.get('deck:mono-green-landfall'))), flush=True)
    if (result['arms']['ordered']['optimizer_steps'] != result['arms']['pooled']['optimizer_steps']
            or result['arms']['ordered']['train_target_labels']
            != result['arms']['pooled']['train_target_labels']):
        raise AssertionError('Cached A/B training budgets diverged')
    if file_sha256(Path(args.cache) / 'cache.json') != result['cache_manifest_sha256']:
        raise AssertionError('Target cache changed during A/B training')
    result['status'] = 'complete'
    write_atomic_json(args.output / 'experiment.json', result)
    (args.output / 'experiment.partial.json').unlink()
    print(json.dumps(dict(output=str(args.output.resolve()),
        train_targets=len(train), validation_targets=len(validation),
        optimizer_steps=result['arms']['ordered']['optimizer_steps'])), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
