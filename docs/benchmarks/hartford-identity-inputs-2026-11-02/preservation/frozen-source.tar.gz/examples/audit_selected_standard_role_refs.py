"""Count all unresolved target roles in the fixed v5 A/B game selection."""

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

import numpy as np

from examples.diagnose_standard_decisions import checkpoint_files, file_sha256
from examples.run_standard_role_ab import selected_stages
from patchwork_automaton.neural.demonstrations import read_demonstration
from patchwork_automaton.neural.role_pointers import reconstruct_role_refs


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--checkpoint-sha256', required=True)
    p.add_argument('--datasets', nargs=2, type=Path, required=True)
    p.add_argument('--train-games-per-stage', type=int, default=600)
    p.add_argument('--validation-games-per-stage', type=int, default=240)
    p.add_argument('--sample-seed', type=int, default=73)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(argv)
    if args.output.exists():
        raise FileExistsError(args.output)
    policy, sidecar = checkpoint_files(args.checkpoint)
    if file_sha256(policy) != args.checkpoint_sha256:
        raise ValueError('cp200 checkpoint hash mismatch')
    manifest = json.loads(sidecar.read_text())
    stages = selected_stages(args.datasets, manifest,
        train_games_per_stage=args.train_games_per_stage,
        validation_games_per_stage=args.validation_games_per_stage,
        sample_seed=args.sample_seed)
    totals = Counter()
    groups = defaultdict(Counter)
    failures = []
    for stage in stages:
        for partition in ('training', 'validation'):
            for game_number, game in enumerate(stage[partition], 1):
                for trajectory in game['trajectories']:
                    for ordinal, sample in enumerate(read_demonstration(trajectory)):
                        if sample.decision_kind != 'targets':
                            continue
                        _, statuses = reconstruct_role_refs(sample.arrays, manifest)
                        legal = np.flatnonzero(sample.arrays['candidate_mask'])
                        bad = [(int(index), status) for index, status in zip(legal, statuses)
                               if status != 'resolved']
                        chosen_status = statuses[int(np.where(legal == sample.action)[0][0])]
                        row = groups[f"{stage['stage']}|{partition}|{trajectory['deck']}"]
                        for counts in (totals, row):
                            counts['target_decisions'] += 1
                            counts['candidate_rows'] += len(statuses)
                            counts['unresolved_decisions'] += int(bool(bad))
                            counts['unresolved_candidates'] += len(bad)
                            counts['unresolved_chosen'] += int(chosen_status != 'resolved')
                            for _, status in bad:
                                counts[status] += 1
                        if bad:
                            failures.append(dict(stage=stage['stage'], partition=partition,
                                game=game['index'], seed=game['seed'], deck=trajectory['deck'],
                                player=trajectory['player'], path=str(trajectory['path']),
                                samples=trajectory['samples'], decision=ordinal,
                                expert_index=sample.action, expert_status=chosen_status,
                                candidates=bad))
                if game_number % 100 == 0:
                    print(json.dumps(dict(event='role_audit_progress', stage=stage['stage'],
                        partition=partition, games=game_number,
                        selected_games=len(stage[partition]),
                        target_decisions=totals['target_decisions'],
                        unresolved_decisions=totals['unresolved_decisions'])), flush=True)
    result = dict(schema=1, checkpoint_sha256=args.checkpoint_sha256,
        encoder_fingerprint=manifest['fingerprint'], sample_seed=args.sample_seed,
        selected_games={f"{stage['stage']}|{partition}": len(stage[partition])
                        for stage in stages for partition in ('training', 'validation')},
        datasets={str((Path(path).resolve() / 'dataset.json')):
                  file_sha256(Path(path) / 'dataset.json') for path in args.datasets},
        totals=dict(totals), by_stage_partition_deck={key: dict(value)
            for key, value in sorted(groups.items())}, failures=failures)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(output=str(args.output.resolve()), totals=result['totals'],
        failures=len(failures))), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
