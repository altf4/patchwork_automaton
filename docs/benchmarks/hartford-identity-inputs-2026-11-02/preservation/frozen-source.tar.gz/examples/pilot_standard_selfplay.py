"""Isolated 240-game, two-neural-seat Standard PPO collection smoke."""
import argparse
import asyncio
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from examples.train_standard_ppo import Resources, checkpoint_hashes, sha, source_hashes
from patchwork_automaton.rl.standard_ppo import schedule, validate_collection
from patchwork_automaton.rl.standard_selfplay_processes import StandardSelfplayCollector


async def run(args):
    from patchwork_automaton.neural.devices import configure_runtime, device_scope, assert_model_device
    from patchwork_automaton.neural.experiment import atomic_json
    from patchwork_automaton.neural.inference_processes import weights_digest
    from patchwork_automaton.neural.standard_policy import StandardPolicy

    if args.games != 240 or args.round != 201:
        raise ValueError('Collection smoke is fixed at 240 games in fork round 201')
    if args.runners < 1 or args.workers % args.runners or args.learner_inference_processes % args.runners \
            or args.opponent_inference_processes % args.runners:
        raise ValueError('Workers and inference replicas must divide among runners')
    checkpoint = args.checkpoint.resolve(strict=True)
    if checkpoint.name != 'round-0200':
        raise ValueError('Pilot must use parent round-0200')
    args.output.mkdir(parents=True)
    trajectories = args.output/'trajectories'
    trajectories.mkdir()
    results = args.output/'results'
    results.mkdir()
    configure_runtime('cpu')
    with device_scope('cpu'):
        model = StandardPolicy.load(checkpoint/'policy.keras').model
        opponent_model = StandardPolicy.load(checkpoint/'policy.keras').model
    assert_model_device(model, 'cpu')
    assert_model_device(opponent_model, 'cpu')
    actor_digest = weights_digest(model.get_weights())
    if actor_digest != weights_digest(opponent_model.get_weights()):
        raise AssertionError('Pilot self-play seats loaded different checkpoint weights')
    policy_sha = sha(checkpoint/'policy.keras')
    planned = schedule(args.games,seed=args.seed,round_id=args.round)
    for game in planned:
        game.update(opponent_kind='frozen_neural', opponent_version=200,
                    opponent_checkpoint_sha256=policy_sha)
    manifest = dict(status='running',checkpoint=str(checkpoint),
        checkpoint_sha256=checkpoint_hashes(checkpoint),source_sha256=source_hashes(),
        opponent_weights_sha256=actor_digest,seed=args.seed,round=args.round,
        games=args.games,workers=args.workers,runners=args.runners,
        learner_inference_processes=args.learner_inference_processes,
        opponent_inference_processes=args.opponent_inference_processes,
        started_at=datetime.now(timezone.utc).isoformat())
    atomic_json(args.output/'manifest.json',manifest)
    collectors = [StandardSelfplayCollector(model,opponent_model,
        workers=args.workers//args.runners,
        inference_processes=args.learner_inference_processes//args.runners,
        opponent_inference_processes=args.opponent_inference_processes//args.runners)
        for _ in range(args.runners)]
    rows = []
    def progress(row):
        atomic_json(results/f"game-{row['index']:06d}.json",row)
        rows.append(row)
        if len(rows) % 20 == 0:
            atomic_json(args.output/'progress.json',dict(completed=len(rows),total=args.games,
                timestamp=datetime.now(timezone.utc).isoformat()))
    try:
        await asyncio.gather(*(c.start(version=200,opponent_version=200) for c in collectors))
        if any(c.policy_digest != actor_digest or c.opponent_digest != actor_digest for c in collectors):
            raise AssertionError('Inference replica checkpoint digest mismatch')
        jobs = [dict(seed=g['seed'],index=g['index'],game=g) for g in planned]
        with Resources(args.output) as resources:
            await asyncio.gather(*(c.run_schedule(jobs[i::len(collectors)],progress=progress,
                game_runner='standard_ppo',output=trajectories,
                diagnostics=args.output/'adjudications',game_timeout=60,max_turns=50,
                opponent_version=200,opponent_sha256=policy_sha,greedy=False)
                for i,c in enumerate(collectors)))
        ordered = sorted(rows,key=lambda g:g['index'])
        validate_collection(ordered,planned,200)
        if checkpoint_hashes(checkpoint) != manifest['checkpoint_sha256'] or source_hashes() != manifest['source_sha256']:
            raise AssertionError('Pilot changed the checkpoint or source')
        manifest.update(status='complete',completed_games=len(ordered),
            outcomes=dict(Counter(g['status'] for g in ordered)),
            draw_reasons=dict(Counter(g.get('reason') for g in ordered if g['status']=='draw')),
            learner_wins=sum(g.get('learner_won',False) for g in ordered),
            inference=[c.stats() for c in collectors],resources=resources.result(),
            finished_at=datetime.now(timezone.utc).isoformat())
        atomic_json(args.output/'manifest.json',manifest)
        atomic_json(args.output/'progress.json',dict(completed=len(ordered),total=args.games,phase='complete'))
    except BaseException as error:
        manifest.update(status='failed',error=f'{type(error).__name__}: {error}')
        atomic_json(args.output/'manifest.json',manifest)
        raise
    finally:
        await asyncio.gather(*(c.close() for c in collectors))


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seed',type=int,default=912610300000)
    p.add_argument('--round',type=int,default=201)
    p.add_argument('--games',type=int,default=240)
    p.add_argument('--workers',type=int,default=48)
    p.add_argument('--runners',type=int,default=2)
    p.add_argument('--learner-inference-processes',type=int,default=2)
    p.add_argument('--opponent-inference-processes',type=int,default=2)
    return p


if __name__ == '__main__':
    asyncio.run(run(parser().parse_args()))
