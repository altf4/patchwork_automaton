"""Run seeded Standard baseline pairings using only seat-private RustMage views.

Defaults to the three cross-pairings, four games each. Every four attempts rotate
both deck seats and the starting player independently. Cutoffs and errors remain
separate from natural results. No TensorFlow, checkpoints, or sideboarding.
"""
import argparse
import asyncio
from collections import Counter
import hashlib
from importlib.resources import files
from itertools import combinations
import json
import math
from pathlib import Path
import sys
import time

from patchwork_automaton.backends.rustmage import OBSERVATION_SCHEMA, RUSTMAGE_REVISION, RustMageMatch
from patchwork_automaton.baselines.standard_decks import STANDARD_DECKS, standard_deck


def schedule(deck_ids, games, seed):
    """One deck selects a mirror; multiple decks select all distinct pairings."""
    pairs = list(combinations(deck_ids, 2)) if len(deck_ids) > 1 else [(deck_ids[0], deck_ids[0])]
    for pair_index, pair in enumerate(pairs):
        for attempt in range(games):
            index = pair_index * games + attempt
            yield dict(index=index, pairing=list(pair), decks=list(pair if attempt % 2 == 0 else pair[::-1]),
                       seed=seed + index, starting_player=f'P{(attempt // 2) % 2}')


def summary(rows):
    counts = Counter(row['status'] for row in rows)
    return dict(attempted=len(rows), completed=counts['completed'], cutoffs=counts['cutoff'], errors=counts['error'],
                draws=sum(row.get('draw', False) for row in rows),
                wins=dict(Counter(row['winner_deck'] for row in rows if row.get('winner_deck') is not None)))


async def play_game(game, args):
    from patchwork_automaton.baselines.standard import StandardAggro

    started = time.monotonic()
    row = dict(game, status='error', decisions=0)
    actions = Counter()
    recent = []
    try:
        policies = [StandardAggro(deck_id) for deck_id in game['decks']]
        with RustMageMatch(*(standard_deck(deck_id) for deck_id in game['decks']), seed=game['seed'],
                          starting_player=game['starting_player'], checkout=args.rustmage) as match:
            handles = [match.games[f'player_{p}'] for p in range(2)]
            while True:
                views = [await handle.snapshot() for handle in handles]
                row['turn'] = views[0].turn
                row['final_life'] = [p.life for p in views[0].players]
                if views[0].terminal:
                    outcomes = [view.outcome for view in views]
                    if not views[1].terminal or any(outcome is None for outcome in outcomes):
                        raise RuntimeError('Missing terminal seat outcome')
                    winners = [p for p, outcome in enumerate(outcomes) if outcome.won is True]
                    draw = all(outcome.draw is True for outcome in outcomes)
                    if not draw and (len(winners) != 1 or outcomes[1 - winners[0]].won is not False):
                        raise RuntimeError('Inconsistent terminal outcomes')
                    winner = None if draw else winners[0]
                    row.update(status='completed', draw=draw, winner_seat=winner,
                               winner_deck=None if winner is None else game['decks'][winner])
                    break
                if row['decisions'] >= args.limit:
                    row.update(status='cutoff', reason='decision_limit')
                    break
                if views[0].turn is not None and views[0].turn > args.max_turns:
                    row.update(status='cutoff', reason='turn_limit')
                    break
                if time.monotonic() - started >= args.game_timeout:
                    row.update(status='cutoff', reason='wall_clock_limit')
                    break
                actors = [p for p, view in enumerate(views) if view.decision is not None]
                if len(actors) != 1:
                    raise RuntimeError('Expected exactly one prompted RustMage seat')
                player = actors[0]
                view = views[player]
                response = policies[player].choose(view)
                option = next((o for o in view.decision.options if o.id == response.option), None)
                if option is None:
                    raise RuntimeError('Baseline selected an unoffered option')
                recent.append(dict(turn=view.turn, player=player, decision=view.decision.kind,
                                   action=option.label, option=response.option))
                recent = recent[-12:]
                await handles[player].submit(view.decision.token, response)
                row['decisions'] += 1
                actions[f'player_{player}:{option.label}'] += 1
    except Exception as error:
        row.update(status='error', reason=f'{type(error).__name__}: {error}')
    if row['status'] != 'completed':
        row['recent'] = recent
    row.update(seconds=round(time.monotonic() - started, 6), actions=dict(actions))
    return row


async def run(args):
    if args.output is not None and args.output.exists():
        raise FileExistsError(args.output)
    deck_bytes = files('patchwork_automaton').joinpath('data/standard-baselines.json').read_bytes()
    report = dict(schema=1, rustmage_revision=RUSTMAGE_REVISION, observation_schema=OBSERVATION_SCHEMA,
                  deck_data_sha256=hashlib.sha256(deck_bytes).hexdigest(),
                  config={key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
                  games=[], summary=summary([]))

    def persist():
        report['summary'] = summary(report['games'])
        if args.output is not None:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            temporary = args.output.with_suffix(args.output.suffix + '.tmp')
            temporary.write_text(json.dumps(report, indent=2) + '\n')
            temporary.replace(args.output)

    persist()
    for game in schedule(args.decks, args.games, args.seed):
        row = await play_game(game, args)
        report['games'].append(row)
        persist()
        print(json.dumps(dict(index=row['index'], decks=row['decks'], status=row['status'],
                              winner=row.get('winner_deck'), decisions=row['decisions'], reason=row.get('reason'))),
              file=sys.stderr, flush=True)
    return report


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument('--decks', nargs='+', choices=tuple(STANDARD_DECKS), default=list(STANDARD_DECKS),
                        help='One deck runs a mirror; two or three run all distinct pairings')
    result.add_argument('--games', type=int, default=4, help='Attempts per pairing; multiples of four balance seats and starting player')
    result.add_argument('--seed', type=int, default=801)
    result.add_argument('--limit', type=int, default=6000, help='Maximum submitted decisions per game')
    result.add_argument('--max-turns', type=int, default=80, help='Maximum global turn number, counting both players')
    result.add_argument('--game-timeout', type=float, default=60, help='Cooperative wall-clock limit checked between native actions')
    result.add_argument('--rustmage', type=Path, help='RustMage checkout; otherwise RUSTMAGE_ROOT or .local/rustmage')
    result.add_argument('--output', type=Path, help='Save the JSON report incrementally to a new file')
    return result


def main(argv=None):
    command = parser()
    args = command.parse_args(argv)
    if min(args.games, args.limit, args.max_turns, args.game_timeout) <= 0 or not math.isfinite(args.game_timeout):
        command.error('Game counts and limits must be positive')
    if len(set(args.decks)) != len(args.decks):
        command.error('Deck IDs must be unique; select one ID for a mirror')
    attempts = args.games * (len(args.decks) * (len(args.decks) - 1) // 2 if len(args.decks) > 1 else 1)
    if not 0 <= args.seed < 2**64 or args.seed + attempts > 2**64:
        command.error('Every generated seed must fit an unsigned 64-bit integer')
    report = asyncio.run(run(args))
    print(json.dumps(report, indent=2))
    return 1 if report['summary']['errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
