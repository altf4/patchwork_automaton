"""The host-memory policy has explicit ABI, ordering and no neural imports."""
import ctypes
import unittest
from unittest.mock import Mock, patch

from patchwork_automaton.neural.host_memory import HostMemoryReclaimer, _Mallinfo2


class HostMemoryReleaseTests(unittest.TestCase):
    def test_linux_abi_and_snapshot_are_passive(self):
        policy = HostMemoryReclaimer()
        self.assertEqual(ctypes.sizeof(_Mallinfo2), 10*ctypes.sizeof(ctypes.c_size_t))
        self.assertEqual(policy._trim.argtypes, [ctypes.c_size_t])
        self.assertIs(policy._trim.restype, ctypes.c_int)
        self.assertIs(policy._info.restype, _Mallinfo2)
        with patch('patchwork_automaton.neural.host_memory.gc.collect', side_effect=AssertionError), \
             patch.object(policy, '_trim', side_effect=AssertionError):
            sample = policy.snapshot()
        self.assertGreater(sample['process_bytes']['VmRSS'], 0)
        self.assertGreaterEqual(sample['glibc_bytes']['arena'], sample['glibc_bytes']['uordblks'])

    def test_release_collects_then_trims_and_records_signed_rss_change(self):
        policy = HostMemoryReclaimer()
        events = []
        samples = [dict(process_bytes=dict(VmRSS=n),glibc_bytes={}) for n in (100,120,25)]
        with patch.object(policy, 'snapshot', side_effect=samples), \
             patch('patchwork_automaton.neural.host_memory.gc.collect',
                   side_effect=lambda: events.append('gc') or 7), \
             patch.object(policy, '_trim', side_effect=lambda pad: events.append(('trim', pad)) or 1):
            result = policy.release('after_update')
        self.assertEqual(events, ['gc', ('trim', 0)])
        self.assertEqual(result['rss_released_bytes'], 75)
        self.assertEqual(result['gc_collected'], 7)
        self.assertEqual(result['after_gc']['process_bytes']['VmRSS'], 120)

    def test_unsupported_allocator_fails_before_release(self):
        with patch('patchwork_automaton.neural.host_memory.ctypes.CDLL', side_effect=OSError), \
             self.assertRaisesRegex(RuntimeError, 'Linux/glibc'):
            HostMemoryReclaimer()

    def test_invalid_boundary_never_collects_or_trims(self):
        policy = HostMemoryReclaimer()
        for stage in ('', None, 3):
            with self.subTest(stage=stage), self.assertRaises(ValueError), \
                 patch('patchwork_automaton.neural.host_memory.gc.collect', side_effect=AssertionError):
                policy.release(stage)
