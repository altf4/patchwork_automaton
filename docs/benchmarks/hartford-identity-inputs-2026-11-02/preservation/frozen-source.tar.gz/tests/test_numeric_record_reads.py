"""Exact ordered batch reads, bounded extents, and reader cleanup without TensorFlow."""
import os
import threading
import unittest
from unittest.mock import patch
import numpy as np
from patchwork_automaton.neural.packed_rollouts import NumericRollout
from patchwork_automaton.neural.rollout_records import Sample

@unittest.skipUnless(hasattr(os,'pread'),'Requires positional file I/O')
class NumericRecordReadTests(unittest.TestCase):
    def records(self):
        rng=np.random.default_rng(812)
        for n,a,h in ((2,3,0),(4,1,3),(1,2,1),(3,4,2),(2,2,0)):
            yield Sample(dict(entities=rng.normal(size=(n,7)).astype(np.float32),
                relations=rng.normal(size=(n,n,2)).astype(np.float32),
                history=rng.normal(size=(h,3)).astype(np.float32),
                semantics=np.zeros((n,0,3),np.float32),
                candidates=rng.normal(size=(a,5)).astype(np.float32),
                candidate_mask=np.ones(a,bool),card_ids=np.arange(n,dtype=np.int32),
                signed_zero=np.asarray([-0.,0.],np.float32)),
                rng.normal(size=4).astype(np.float32),True,a-1,.25,
                np.log(np.full(a,1/a)).astype(np.float32))

    def store(self,**options):
        store=NumericRollout(**options)
        self.addCleanup(store.close)
        for sample in self.records():store.append(sample)
        store.finish()
        return store

    def equal(self,left,right):
        self.assertEqual(list(left),list(right))
        for k in left:
            self.assertEqual(left[k].dtype,right[k].dtype,k)
            self.assertEqual(left[k].shape,right[k].shape,k)
            self.assertEqual(left[k].tobytes(),right[k].tobytes(),k)

    def test_shuffled_repeated_and_empty_axes_match_mapped_reader_bit_for_bit(self):
        direct=self.store(read_workers=4,read_buffer_bytes=4096)
        mapped=self.store(read_mode='mmap')
        for ids in ([4,0,2,1,4,3],[2],[0,1,2,3,4],[3,0,3]):
            original=np.asarray(ids,np.int64)
            self.equal(direct.gather(original),mapped.gather(original))
            np.testing.assert_array_equal(original,ids)
        self.assertGreater(direct.stats()['calls'],0)

    def test_contiguous_records_coalesce_and_duplicate_ids_read_once(self):
        store=self.store(read_workers=1)
        store.gather([4,3,2,1,0,4])
        self.assertEqual(store.read_spans,1)
        self.assertEqual(store.read_calls,1)
        self.assertEqual(store.read_bytes,store.disk_bytes)

    def test_short_reads_are_completed_without_changing_results(self):
        store=self.store(read_workers=1)
        reference=self.store(read_mode='mmap')
        preadv=os.preadv
        def short(fd,buffers,offset):
            return preadv(fd,[buffers[0][:13]],offset)
        with patch('os.preadv',side_effect=short):
            actual=store.gather([4,1,0,3])
        self.equal(actual,reference.gather([4,1,0,3]))
        self.assertGreater(store.read_calls,store.read_spans)

    def test_reader_error_joins_parallel_work_and_closes_threads(self):
        store=self.store(read_workers=3,read_buffer_bytes=4096)
        with patch.object(store,'_read_exact',side_effect=EOFError('truncated')):
            with self.assertRaisesRegex(EOFError,'truncated'):store.gather([4,0,2])
        store.close()
        self.assertFalse(any(t.name.startswith('ppo-record-read') for t in threading.enumerate()))
        with self.assertRaises(ValueError):store.gather([0])

    def test_buffer_limit_is_enforced_before_io(self):
        store=self.store(read_buffer_bytes=2)
        with patch.object(store,'_read_exact') as reader:
            with self.assertRaisesRegex(ValueError,'reader-buffer budget'):store.gather([0])
        reader.assert_not_called()

    def test_read_spans_respect_parallel_scratch_budget(self):
        store=self.store(read_workers=4,read_buffer_bytes=4096)
        store.gather([0,1,2,3,4])
        self.assertLessEqual(store.maximum_span_bytes*store.read_workers*2,4096)

    def test_invalid_requests_and_configuration(self):
        store=self.store()
        for indices in ([],[-1],[5],[[0,1]]):
            with self.assertRaises(ValueError):store.gather(indices)
        for options in (dict(read_mode='unknown'),dict(read_workers=0),
                        dict(read_workers=True),dict(read_buffer_bytes=1)):
            with self.assertRaises(ValueError):NumericRollout(**options)

if __name__=='__main__':unittest.main()

