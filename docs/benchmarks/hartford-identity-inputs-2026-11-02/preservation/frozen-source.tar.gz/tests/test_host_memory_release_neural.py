"""Releasing free host pages must preserve complete continued PPO behavior."""
from pathlib import Path
import copy
import tempfile
import unittest
import numpy as np
from test_neural import AVAILABLE


@unittest.skipUnless(AVAILABLE, 'Requires neural dependencies')
class HostMemoryReleaseNeuralTests(unittest.TestCase):
    def test_continued_update_and_both_adams_rng_remain_exact(self):
        from test_critic_warmup import CriticWarmupTests
        from patchwork_automaton.neural.host_memory import HostMemoryReclaimer
        release = HostMemoryReclaimer()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            m,a,paths = CriticWarmupTests().fixture(root/'a',value_max_steps=2)
            n,b,_ = CriticWarmupTests().fixture(root/'b',value_max_steps=2)
            for trainer in (a,b):
                trainer.guard_audit=True;trainer.numerical_prepacking=True
                trainer.cache_policy_batches=True;trainer.measurement_workers=2
                trainer.policy_cache_device=trainer.actor_epoch_cache_device='/CPU:0'
                trainer.policy_cache_device_bytes=trainer.actor_epoch_cache_bytes=10**8
                trainer.compact_device_cache=True
            a.compile();b.compile()
            for _ in range(2):
                expected=a.update_files(paths);actual=b.update_files(paths)
                before=[np.asarray(v).copy() for values in
                        (n.variables,b.optimizer.variables,b.critic_optimizer.variables) for v in values]
                rng=copy.deepcopy(b.rng.bit_generator.state)
                result=release.release('after_update')
                after=[np.asarray(v) for values in
                       (n.variables,b.optimizer.variables,b.critic_optimizer.variables) for v in values]
                for u,v in zip(before,after):np.testing.assert_array_equal(u,v)
                self.assertEqual(rng,b.rng.bit_generator.state)
                for key in ('loss','value_loss','exact_kl','max_state_kl','accepted_steps',
                            'rejected_epochs','critic_steps','optimizer_steps','critic_optimizer_steps','guard_proposals'):
                    self.assertEqual(expected[key],actual[key],key)
                self.assertEqual(a.rng.bit_generator.state,b.rng.bit_generator.state)
                for left,right in [(m.variables,n.variables),(a.optimizer.variables,b.optimizer.variables),
                                   (a.critic_optimizer.variables,b.critic_optimizer.variables)]:
                    for u,v in zip(left,right):np.testing.assert_array_equal(np.asarray(u),np.asarray(v))
                self.assertGreaterEqual(result['seconds'],0.)
