"""The opt-in residual starts at exactly the frozen policy's behavior."""

import os
import unittest

os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')

import numpy as np

from patchwork_automaton.neural.batching import example_batch
from patchwork_automaton.neural.model import PolicyNetwork
from patchwork_automaton.neural.role_residual import RoleResidualPolicy


class RoleResidualTests(unittest.TestCase):
    def test_zero_initialized_residual_matches_logits_and_memory(self):
        spec = dict(entities=3, semantics=2, context=2, candidates=16, history=2)
        actor = PolicyNetwork(card_count=1, width=8, memory_size=8, blocks=1,
                              candidate_interactions=True, stable_heads=True,
                              feature_spec=spec)
        batch = example_batch(actor.memory_size, spec)
        batch['candidate_role_refs'] = np.zeros((1, 1, 3, 2), np.float32)
        expected = actor(batch, training=False)
        residual = RoleResidualPolicy(actor, action_width=1, hidden_width=8)
        actual = residual(batch, training=False)
        np.testing.assert_array_equal(actual['logits'], expected['logits'])
        np.testing.assert_array_equal(actual['memory_out'], expected['memory_out'])
        self.assertFalse(actor.trainable_variables)
        self.assertEqual(len(residual.trainable_variables), 4)

    def test_non_target_gate_preserves_frozen_logits_after_training(self):
        spec = dict(entities=3, semantics=2, context=2, candidates=16, history=2)
        actor = PolicyNetwork(card_count=1, width=8, memory_size=8, blocks=1,
                              feature_spec=spec)
        batch = example_batch(actor.memory_size, spec)
        batch['candidate_role_refs'] = np.zeros((1, 1, 3, 2), np.float32)
        residual = RoleResidualPolicy(actor, action_width=1, hidden_width=8,
                                      target_context_index=0)
        residual(batch, training=False)
        weights = residual.role_score.get_weights()
        weights[1][0] = 1.
        residual.role_score.set_weights(weights)
        frozen = actor(batch, training=False)
        np.testing.assert_array_equal(residual(batch, training=False)['logits'], frozen['logits'])
        batch['context'][0, 0] = 1.
        gated = residual(batch, training=False)['logits']
        base = actor(batch, training=False)['logits']
        np.testing.assert_allclose(gated, np.asarray(base) + 1., atol=1e-6)


if __name__ == '__main__':
    unittest.main()
