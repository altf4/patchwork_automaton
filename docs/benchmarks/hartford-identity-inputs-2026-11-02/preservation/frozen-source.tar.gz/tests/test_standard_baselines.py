"""The Standard baselines race with legal actions and deliberately never block."""
from collections import Counter, deque
from itertools import combinations_with_replacement
import os
from pathlib import Path
import unittest
from unittest.mock import patch

from patchwork_automaton.backends.rustmage import RustMageMatch, action_options, domain_action
from patchwork_automaton.baselines.standard import StandardAggro
from patchwork_automaton.baselines.standard_decks import standard_deck
from patchwork_automaton.core import Decision, DecisionToken, Handle, ObjectView, Observation, PlayerView


DECKS = ('mono-green-landfall', 'izzet-prowess', 'bw-lifegain')
ME = Handle('rustmage', 'player', 'P0')
OTHER = Handle('rustmage', 'player', 'P1')
GAME = Handle('rustmage', 'game', 'standard-baseline-test')
ROOT = Path(os.environ.get('RUSTMAGE_ROOT', '.local/rustmage'))
NATIVE = (ROOT / 'target/release/librustmage.so').is_file()


def card(identity, name, *, zone='battlefield', controller=ME, kinds=1, **properties):
    handle = Handle('rustmage', 'object', str(identity))
    raw = dict(id=identity, name=name, card=name, zone=zone.title(), controller=controller.value,
               kinds=kinds, tapped=False, summoning_sick=False, power=1, toughness=1)
    raw.update(properties)
    return ObjectView(handle, name, zone, controller, raw)


def observation(actions, *, objects=(), kind='priority', phase='precombat_main',
                active=ME, mana=(0, 0, 0, 0, 0, 0), **native):
    raw = dict(actions=actions, announcing=None, resolving=None, stack=[], waiting_triggers=[],
               turn=3, active=active.value, viewer=ME.value, actor=ME.value)
    raw.update(native)
    hand_count = sum(obj.zone == 'hand' and obj.controller == ME for obj in objects)
    players = (PlayerView(ME, 'P0', 20, hand_count, 45, native={'mana': list(mana), 'hand_count': hand_count}),
               PlayerView(OTHER, 'P1', 20, 3, 45, native={'mana': [0] * 6}))
    decision = Decision(DecisionToken('rustmage', 'session', GAME, ME, 1), kind, '', action_options(raw))
    return Observation('rustmage', GAME, ME, 1, players, {obj.id: obj for obj in objects},
                       decision, native=raw, turn=3, phase=phase, active_player=active)


def chosen_action(policy, obs):
    response = policy.choose(obs)
    option = next(option for option in obs.decision.options if option.id == response.option)
    return (option.constraints['action'] if option.kind == 'finite'
            else domain_action(option, response.value))


class StandardBaselineIntentTests(unittest.TestCase):
    def test_mulligan_poor_sevens_and_sixes_but_stop_at_five(self):
        for deck in DECKS:
            policy = StandardAggro(deck)
            for size in (7, 6, 5):
                for lands in range(size + 1):
                    with self.subTest(deck=deck, size=size, lands=lands):
                        hand = [card(i, 'Forest' if i < lands else 'Llanowar Elves', zone='hand',
                                     kinds=2 if i < lands else 1) for i in range(size)]
                        # Opposing cards cannot affect this seat's land count.
                        hand += [card(100 + i, 'Forest', zone='hand', controller=OTHER, kinds=2)
                                 for i in range(7)]
                        state = observation([dict(kind='Keep'), dict(kind='Mulligan'), dict(kind='Concede')],
                                            objects=hand, kind='mulligan', phase='untap')
                        expected = 'Keep' if size == 5 or 2 <= lands <= 5 else 'Mulligan'
                        self.assertEqual(chosen_action(policy, state), dict(kind=expected))

    def test_bottom_excess_land_then_expensive_spell(self):
        for deck in DECKS:
            with self.subTest(deck=deck):
                policy = StandardAggro(deck)
                hand = [card(i, 'Forest', zone='hand', kinds=2) for i in range(4)]
                hand += [card(4, 'Llanowar Elves', zone='hand'),
                         card(5, 'Mightform Harmonizer', zone='hand'),
                         card(6, 'Mossborn Hydra', zone='hand')]
                state = observation([dict(kind='Bottom', card=i) for i in (4, 5, 6, 0, 1, 2, 3)],
                                    objects=hand, kind='bottom', phase='untap')
                first = chosen_action(policy, state)
                self.assertEqual(first['kind'], 'Bottom')
                self.assertIn(first['card'], range(4))
                hand = [obj for obj in hand if int(obj.id.value) != first['card']]
                state = observation([dict(kind='Bottom', card=int(obj.id.value)) for obj in hand],
                                    objects=hand, kind='bottom', phase='untap')
                self.assertEqual(chosen_action(policy, state), dict(kind='Bottom', card=5))

    def test_bottom_preserves_two_lands_and_cheap_creatures(self):
        hand = [card(i, 'Forest', zone='hand', kinds=2) for i in range(2)]
        hand += [card(2, 'Llanowar Elves', zone='hand'), card(3, 'Mossborn Hydra', zone='hand'),
                 card(4, 'Mightform Harmonizer', zone='hand'), card(5, 'Keen-Eyed Curator', zone='hand'),
                 card(6, 'Icetill Explorer', zone='hand')]
        for deck in DECKS:
            with self.subTest(deck=deck):
                state = observation([dict(kind='Bottom', card=int(obj.id.value)) for obj in hand],
                                    objects=hand, kind='bottom', phase='untap')
                self.assertEqual(chosen_action(StandardAggro(deck), state), dict(kind='Bottom', card=4))

    def test_attack_every_offered_creature_even_into_larger_blockers(self):
        for deck in DECKS:
            with self.subTest(deck=deck):
                policy = StandardAggro(deck)
                creatures = [card(1, 'Llanowar Elves'), card(2, 'Hinterland Sanctifier'),
                             card(3, 'Mossborn Hydra', controller=OTHER, power=100, toughness=100)]
                remaining = {1, 2}
                while remaining:
                    state = observation([dict(kind='FinishAttackers'),
                        *[dict(kind='Attack', card=identity) for identity in sorted(remaining)]],
                        objects=creatures, kind='attackers', phase='declare_attackers')
                    selected = chosen_action(policy, state)
                    self.assertEqual(selected['kind'], 'Attack')
                    self.assertIn(selected['card'], remaining)
                    remaining.remove(selected['card'])
                self.assertEqual(chosen_action(policy, observation([dict(kind='FinishAttackers')],
                    kind='attackers', phase='declare_attackers'))['kind'], 'FinishAttackers')

    def test_never_block_even_with_a_favorable_block(self):
        for deck in DECKS:
            with self.subTest(deck=deck):
                state = observation([dict(kind='Block', blocker=1, attacker=2),
                    dict(kind='FinishBlockers'), dict(kind='Concede')],
                    objects=[card(1, 'Mossborn Hydra', power=100, toughness=100),
                             card(2, 'Llanowar Elves', controller=OTHER)],
                    kind='blockers', phase='declare_blockers', active=OTHER)
                self.assertEqual(chosen_action(StandardAggro(deck), state), dict(kind='FinishBlockers'))

    def test_land_precedes_an_offered_spell(self):
        for deck, land, creature in zip(DECKS, ('Forest', 'Island', 'Plains'),
                                      ('Llanowar Elves', 'Drake Hatcher', 'Hinterland Sanctifier')):
            with self.subTest(deck=deck):
                state = observation([dict(kind='AnnounceCast', card=2), dict(kind='Pass'),
                    dict(kind='PlayLand', card=1)], mana=(1, 1, 1, 1, 1, 0),
                    objects=[card(1, land, zone='hand', kinds=2), card(2, creature, zone='hand')])
                self.assertEqual(chosen_action(StandardAggro(deck), state), dict(kind='PlayLand', card=1))

    def test_fetch_land_is_activated_as_soon_as_it_is_offered(self):
        for name in ('Fabled Passage', 'Elven Passage', 'Escape Tunnel'):
            for active, phase in ((ME, 'precombat_main'), (OTHER, 'upkeep')):
                with self.subTest(name=name, active=active.value):
                    fetch = dict(kind='AnnounceActivate', card=1, ability=0, counter_payment={})
                    state = observation([dict(kind='AnnounceCast', card=2), dict(kind='Pass'), fetch],
                        objects=[card(1, name, kinds=2), card(2, 'Llanowar Elves', zone='hand')],
                        active=active, phase=phase)
                    self.assertEqual(chosen_action(StandardAggro('mono-green-landfall'), state), fetch)

    def test_burn_prefers_enemy_player_over_own_player_or_creatures(self):
        state = observation([dict(kind='ChooseTarget', target={'Card': 1}),
            dict(kind='ChooseTarget', target={'Player': 'P0'}),
            dict(kind='ChooseTarget', target={'Card': 2}),
            dict(kind='ChooseTarget', target={'Player': 'P1'})],
            objects=[card(1, 'Drake Hatcher'), card(2, 'Mossborn Hydra', controller=OTHER)],
            kind='targets', announcing={'source_card': 'Burn Together'}, targeting_group=1)
        self.assertEqual(chosen_action(StandardAggro('izzet-prowess'), state),
                         dict(kind='ChooseTarget', target={'Player': 'P1'}))

    def test_burn_together_first_selects_its_own_creature_source(self):
        state = observation([dict(kind='ChooseTarget', target={'Card': 1})],
            objects=[card(1, 'Drake Hatcher')], kind='targets',
            announcing={'source_card': 'Burn Together'}, targeting_group=0)
        self.assertEqual(chosen_action(StandardAggro('izzet-prowess'), state),
                         dict(kind='ChooseTarget', target={'Card': 1}))

    def test_multiversal_passage_chooses_a_missing_deck_color(self):
        for deck, existing, missing in (('izzet-prowess', 'Mountain', 'Island'),
                                         ('bw-lifegain', 'Plains', 'Swamp')):
            with self.subTest(deck=deck):
                state = observation([dict(kind='ChooseEntryValue', value={'BasicLandType': existing}),
                    dict(kind='ChooseEntryValue', value={'BasicLandType': missing})],
                    objects=[card(1, existing, kinds=2), card(2, 'Multiversal Passage', kinds=2)],
                    kind='entry_value')
                self.assertEqual(chosen_action(StandardAggro(deck), state),
                                 dict(kind='ChooseEntryValue', value={'BasicLandType': missing}))

    def test_fetch_search_selects_forest_before_finishing_search(self):
        state = observation([dict(kind='FinishSearch'), dict(kind='ChooseSearch', card=1)],
                            objects=[card(1, 'Forest', zone='library', kinds=2)], kind='search')
        self.assertEqual(chosen_action(StandardAggro('mono-green-landfall'), state),
                         dict(kind='ChooseSearch', card=1))

    def test_buffs_target_friendly_creatures_and_removal_targets_enemies(self):
        creatures = [card(1, 'Drake Hatcher'), card(2, 'Mossborn Hydra', controller=OTHER)]
        actions = [dict(kind='ChooseTarget', target={'Card': 2}),
                   dict(kind='ChooseTarget', target={'Card': 1})]
        for deck, source, expected in (('izzet-prowess', 'Ancestral Anger', 1),
                                        ('bw-lifegain', 'Bitter Triumph', 2)):
            with self.subTest(source=source):
                state = observation(actions, objects=creatures, kind='targets',
                                    announcing={'source_card': source})
                self.assertEqual(chosen_action(StandardAggro(deck), state),
                                 dict(kind='ChooseTarget', target={'Card': expected}))

    def test_exact_multicolor_payment_uses_the_offered_domain(self):
        domain = dict(required=[0, 1, 0, 1, 0, 0], available=[0, 1, 0, 2, 0, 0], generic=1)
        state = observation([dict(kind='Concede')], kind='pay_costs',
            mana=(0, 1, 0, 2, 0, 0), mana_payment=domain,
            announcing={'source_card': 'Balmor, Battlemage Captain'})
        self.assertEqual(chosen_action(StandardAggro('izzet-prowess'), state),
                         dict(kind='PayCosts', payment=[0, 1, 0, 2, 0, 0]))


@unittest.skipUnless(NATIVE, 'Build pinned RustMage first')
class StandardBaselineGameTests(unittest.IsolatedAsyncioTestCase):
    async def test_three_mirrors_and_three_cross_pairings_finish_naturally(self):
        # Exercise the real sequential land, mana, target and trigger prompts.
        # Neither a rules exception nor a cutoff counts as a completed game.
        with patch.dict(os.environ, PATCHWORK_OBSERVATION_PIPELINE='python'):
            for index, (first, second) in enumerate(combinations_with_replacement(DECKS, 2)):
                with self.subTest(first=first, second=second):
                    policies = [StandardAggro(first), StandardAggro(second)]
                    counts, recent = Counter(), deque(maxlen=12)
                    opening = [[], []]
                    # Seed 1 gives P0 a one-land seven for each registered list.
                    seed = 1 if first == second else 20261024 + index
                    with RustMageMatch(standard_deck(first), standard_deck(second), seed=seed,
                                       starting_player=f'P{index % 2}') as match:
                        for step in range(4000):
                            raw = match._raw('P0')
                            if raw['outcome'] is not None:
                                break
                            self.assertLessEqual(raw['turn'], 80,
                                f'No natural result by turn 80: {first} / {second}; recent={list(recent)}')
                            actor = int(raw['actor'][1])
                            game = match.games[f'player_{actor}']
                            obs = await game.snapshot()
                            response = policies[actor].choose(obs)
                            option = next(o for o in obs.decision.options if o.id == response.option)
                            action = (option.constraints['action'] if option.kind == 'finite'
                                      else domain_action(option, response.value))
                            self.assertNotIn(action['kind'], ('Block', 'Concede'))
                            counts[action['kind']] += 1
                            if obs.decision.kind in ('mulligan', 'bottom', 'opening_hand'):
                                opening[actor].append(action['kind'])
                            if action['kind'] == 'Keep':
                                mulligans = opening[actor].count('Mulligan')
                                self.assertLessEqual(mulligans, 2)
                                self.assertEqual(next(p.hand_count for p in obs.players if p.id == obs.actor),
                                                 7 - mulligans)
                            recent.append((actor, obs.decision.kind, dict(action)))
                            await game.submit(obs.decision.token, response)
                        else:
                            self.fail(f'Action cutoff: {first} / {second}; recent={list(recent)}')
                        end = [await match.games[f'player_{seat}'].snapshot() for seat in range(2)]
                        self.assertTrue(all(obs.terminal for obs in end))
                        self.assertGreater(counts['Attack'], 0)
                        self.assertGreater(counts['AnnounceCast'], 0)
                        self.assertGreater(counts['PlayLand'], 0)
                        self.assertEqual(counts['Keep'], 2)
                        self.assertEqual(counts['FinishOpeningHand'], 2)
                        if first == second:
                            self.assertIn('Mulligan', opening[0])
                            self.assertIn('Bottom', opening[0])
                            self.assertLess(opening[0].index('Mulligan'), opening[0].index('Bottom'))
                            self.assertLess(opening[0].index('Bottom'), opening[0].index('Keep'))
                        self.assertGreater(step, 10)
                        if end[0].outcome.draw:
                            self.assertTrue(end[1].outcome.draw)
                        else:
                            self.assertNotEqual(end[0].outcome.won, end[1].outcome.won)
