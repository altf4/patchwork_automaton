"""Card traits survive history without exposing card identity to the model."""
from dataclasses import replace
import importlib.util
import unittest

from patchwork_automaton.core import Handle, ObjectView, Observation, PlayerView
from patchwork_automaton.semantics import CardSemantics, INITIAL_CARDS

AVAILABLE = importlib.util.find_spec('numpy') is not None
if AVAILABLE:
    import numpy as np
    from patchwork_automaton.neural.history import EVENTS, HISTORY_WIDTH, History


class TraitRegistry(dict):
    trait_rows = ((1., 0., 0.), (0., 1., 2.), (0., 3., 4.))
    trait_width = 3
    identity_embeddings = False

    def __init__(self):
        super().__init__({'Goblin': CardSemantics(1), 'Dragon': CardSemantics(2),
                          'token:goblin': CardSemantics(1)})
        self.lookups = []

    def get(self, name, default=None):
        self.lookups.append(name)
        return super().get(name, default)


def observation(revision=1, *, objects=None):
    actor = Handle('rustmage', 'player', 'P0')
    other = Handle('rustmage', 'player', 'P1')
    game = Handle('rustmage', 'game', 'history-test')
    players = (PlayerView(actor, 'Alice', 20, 7, 53), PlayerView(other, 'Bob', 20, 7, 53))
    return Observation('rustmage', game, actor, revision, players, objects or {}, None, turn=1)


@unittest.skipUnless(AVAILABLE, 'Requires numpy')
class TraitHistoryTests(unittest.TestCase):
    def test_transient_reveals_retain_traits_with_zero_neural_ids(self):
        registry = TraitRegistry()
        history = History(registry)
        obs = observation()
        history.observe(obs)
        initial = history.take(obs)
        self.assertEqual(initial['history'].shape[1], HISTORY_WIDTH + registry.trait_width)
        self.assertFalse(initial['history'][:, HISTORY_WIDTH:].any())
        handle = Handle('rustmage', 'object', 'revealed')
        card = ObjectView(handle, 'Goblin', 'revealed')
        history.observe(replace(obs, revision=2, objects={handle: card}))
        history.observe(replace(obs, revision=3))
        events = history.take(obs)
        self.assertEqual(events['history_cards'].tolist(), [0, 0])
        np.testing.assert_array_equal(events['history'][:, HISTORY_WIDTH:],
                                      [registry.trait_rows[1], registry.trait_rows[1]])
        self.assertEqual(events['history'][:, :len(EVENTS)].argmax(axis=1).tolist(), [0, 1])
        self.assertFalse(history.take(replace(obs, actor=obs.players[1].id))['history_mask'].any())
        empty = history.take(obs)
        self.assertEqual(empty['history'].shape, (1, HISTORY_WIDTH + registry.trait_width))
        self.assertFalse(empty['history_mask'].any())

    def test_hidden_changes_never_read_effective_or_display_identity(self):
        for flag in ('hideInfo', 'faceDown', 'face_down'):
            with self.subTest(flag=flag):
                registry = TraitRegistry()
                history = History(registry)
                handle = Handle('rustmage', 'object', 'hidden')
                hidden = ObjectView(handle, 'Goblin', 'battlefield',
                                    properties={flag: True, 'card': 'token:goblin'})
                obs = observation(objects={handle: hidden})
                history.observe(obs)
                first = history.take(obs)
                np.testing.assert_array_equal(first['history'][0, HISTORY_WIDTH:], registry.trait_rows[0])
                history.observe(replace(obs, revision=2, objects={handle: replace(
                    hidden, name='Dragon', properties={flag: True, 'card': 'Dragon'})}))
                self.assertFalse(history.take(obs)['history_mask'].any())
                self.assertEqual(registry.lookups, [])
                history.observe(replace(obs, revision=3, objects={handle: replace(
                    hidden, name='Dragon', properties={})}))
                shown = history.take(obs)
                np.testing.assert_array_equal(shown['history'][:, HISTORY_WIDTH:], [registry.trait_rows[2]])

    def test_effective_keys_override_names_and_unknown_forms_stay_distinct(self):
        registry = TraitRegistry()
        history = History(registry)
        obs = observation()
        history.observe(obs)
        history.take(obs)
        handle = Handle('rustmage', 'object', 'token')
        token = ObjectView(handle, 'Dragon', 'battlefield', properties={'card': 'token:goblin'})
        history.observe(replace(obs, revision=2, objects={handle: token}))
        known = history.take(obs)
        np.testing.assert_array_equal(known['history'][:, HISTORY_WIDTH:], [registry.trait_rows[1]])
        for revision, unknown in ((3, 'token:new-recipe'), (4, 'token:another-recipe')):
            history.observe(replace(obs, revision=revision, objects={handle: replace(
                token, properties={'card': unknown})}))
        events = history.take(obs)
        self.assertEqual(events['history_cards'].tolist(), [0, 0])
        np.testing.assert_array_equal(events['history'][:, HISTORY_WIDTH:],
                                      [registry.trait_rows[0], registry.trait_rows[0]])
        self.assertNotIn('Dragon', registry.lookups)

    def test_default_registry_preserves_width_and_card_ids(self):
        history = History(INITIAL_CARDS)
        obs = observation()
        history.observe(obs)
        history.take(obs)
        handle = Handle('rustmage', 'object', 'revealed')
        history.observe(replace(obs, revision=2, objects={handle: ObjectView(handle, 'Raging Goblin', 'revealed')}))
        history.observe(replace(obs, revision=3))
        events = history.take(obs)
        self.assertEqual(events['history_cards'].tolist(), [4, 4])
        self.assertEqual(events['history'].shape, (2, HISTORY_WIDTH))
        history.reset()
        self.assertFalse(history.take(obs)['history_mask'].any())
