"""Semantic examples and catalogue invariants for the typed trait projection."""
import json
import math
from pathlib import Path
import unittest

from patchwork_automaton.neural.card_traits import (ALIASES, CARDS, FACTS, FEATURE_NAMES,
    MANIFEST, REGISTRY, TRAITS, TRAIT_WIDTH, UNKNOWN_TRAITS, _validate_content, _validate_manifest, index_for, traits_for)

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'src/patchwork_automaton/data/rustmage-card-traits.json').read_text())
ROWS = {c['identity']: c for c in DATA['cards']}


def row(name):
    return ROWS[ALIASES.get(name, name)]


def feature(name, key):
    return traits_for(name)[FEATURE_NAMES.index(key)]


class CardTraitsTests(unittest.TestCase):
    def test_all_catalogue_identities_have_finite_fixed_width_features(self):
        self.assertEqual(len(CARDS), MANIFEST['card_count'])
        self.assertGreater(len(CARDS), 5000)
        self.assertLessEqual(TRAIT_WIDTH, 300)
        self.assertGreaterEqual(TRAIT_WIDTH, 150)
        self.assertEqual(len(set(FEATURE_NAMES)), TRAIT_WIDTH)
        self.assertEqual(len(set(CARDS)), len(CARDS))
        for name in CARDS:
            with self.subTest(name=name):
                self.assertEqual(len(TRAITS[name]), TRAIT_WIDTH)
                self.assertTrue(all(math.isfinite(v) for v in TRAITS[name]))
                self.assertEqual(feature(name, 'metadata_known'), 1)
                self.assertEqual(feature(name, 'projection_partial'), 1)
                self.assertIn('mana_value', FACTS[name])

    def test_aliases_faces_and_tokens_use_engine_identity(self):
        for alias, canonical in ALIASES.items():
            self.assertIn(canonical, TRAITS)
            self.assertEqual(index_for(alias), index_for(canonical))
            self.assertEqual(REGISTRY[alias].id, index_for(canonical))
        self.assertEqual(index_for('Elusive Otter'), index_for("Elusive Otter // Grove's Bounty"))
        self.assertNotEqual(index_for('Elusive Otter'), index_for("Grove's Bounty"))
        tokens = [c for c in DATA['cards'] if c['provenance']['category'] == 'token']
        self.assertGreater(len(tokens), 100)
        for token in tokens:
            self.assertGreater(index_for(token['identity']), 0)

    def test_unknown_is_masked_and_unsupported_keeps_printed_metadata(self):
        self.assertEqual(index_for('not a known card identity'), 0)
        self.assertEqual(traits_for('not a known card identity'), UNKNOWN_TRAITS)
        self.assertEqual(len(UNKNOWN_TRAITS), TRAIT_WIDTH)
        self.assertEqual(sum(UNKNOWN_TRAITS), 0)
        unsupported = next(c for c in DATA['cards'] if not c['rules_known'] and c['mana_value'] > 0)
        self.assertEqual(feature(unsupported['identity'], 'rules_known'), 0)
        self.assertEqual(feature(unsupported['identity'], 'unknown_rules'), 1)
        self.assertEqual(feature(unsupported['identity'], 'mana_value.known'), 1)

    def test_burst_branches_are_alternatives_never_six_damage(self):
        burst = row('Burst Lightning')
        self.assertEqual(burst['numbers']['damage_min'], 2)
        self.assertEqual(burst['numbers']['damage_max'], 4)
        spell = next(a for a in burst['abilities'] if a['kind'] == 'spell')
        controls = [s['control'] for s in spell['steps'] if s['control']]
        self.assertIn({'kind': 'if_kicked', 'skip': 2}, controls)
        self.assertIn({'kind': 'skip', 'skip': 1}, controls)
        damage = [s['summary']['amounts']['damage']['max'] for s in spell['steps']
                  if 'damage' in s['summary']['amounts']]
        self.assertEqual(damage, [4, 2])
        self.assertEqual(feature('Burst Lightning', 'alternative.kicker'), 1)
        self.assertEqual(feature('Burst Lightning', 'conditional'), 1)

    def test_resolution_and_triggered_damage_are_separate(self):
        self.assertEqual(row('Viashino Pyromancer')['numbers']['triggered_damage_max'], 2)
        self.assertIsNone(row('Viashino Pyromancer')['numbers']['spell_damage_max'])
        self.assertEqual(feature('Viashino Pyromancer', 'trigger.entry'), 1)
        self.assertEqual(row('Opt')['numbers']['spell_draw_max'], 1)
        self.assertEqual(feature('Opt', 'effect.draw'), 1)
        self.assertEqual(feature('Opt', 'effect.scry'), 1)

    def test_activation_costs_and_prowess_are_derived(self):
        for flag in ('cost.tap', 'cost.sacrifice', 'effect.damage', 'recipient.player'):
            self.assertEqual(feature('Fanatical Firebrand', flag), 1)
        self.assertEqual(row('Fanatical Firebrand')['numbers']['activated_damage_max'], 1)
        self.assertEqual(feature('Heartfire Immolator', 'trigger.noncreature_cast'), 1)
        self.assertEqual(feature('Heartfire Immolator', 'cost.sacrifice'), 1)
        self.assertEqual(feature('Heartfire Immolator', 'dynamic_amount'), 1)

    def test_casting_cost_stats_and_alternate_costs(self):
        charm = row('Boros Charm')
        self.assertEqual(charm['cost'], {'colored': [1, 0, 0, 1, 0, 0], 'generic': 0})
        self.assertEqual(FACTS[ALIASES['Boros Charm']]['mana_value'], 2)
        slickshot = row('Slickshot Show-Off')
        self.assertEqual((slickshot['power'], slickshot['toughness']), (1, 2))
        plot = next(c for c in slickshot['alternative_costs'] if c['kind'] == 'plot')
        self.assertEqual(plot['mana_value'], 2)
        self.assertEqual(feature('Slickshot Show-Off', 'alternative.plot'), 1)
        self.assertEqual(feature('Slickshot Show-Off', 'keyword.flying'), 1)
        self.assertEqual(feature('Slickshot Show-Off', 'keyword.haste'), 1)
        self.assertEqual(feature('Elusive Otter', 'alternative_color.green'), 1)
        self.assertEqual(feature('Elusive Otter', 'color.blue'), 1)
        self.assertEqual(feature('Elusive Otter', 'color.green'), 0)
        self.assertEqual(feature('Slickshot Show-Off', 'alt_generic_min.known'), 1)

    def test_formal_hybrid_symbols_and_provenance(self):
        hybrid = next(c for c in DATA['cards'] if any('/' in s and not s.endswith('/P') for s in c['mana_symbols']))
        self.assertEqual(feature(hybrid['identity'], 'hybrid_cost'), 1)
        self.assertTrue(any(feature(hybrid['identity'], 'hybrid_option.' + c) for c in ('white', 'blue', 'black', 'red', 'green', 'colorless')))
        for card in DATA['cards']:
            self.assertEqual(len(card['provenance']['definition_sha256']), 64)
        self.assertEqual(len(MANIFEST['extractor_sha256']), 64)
        self.assertEqual(len(MANIFEST['rustmage_revision']), 40)

    def test_mana_production_distinguishes_basic_lands_and_choices(self):
        colors = ('white', 'blue', 'black', 'red', 'green', 'colorless')
        basics = ('Plains', 'Island', 'Swamp', 'Mountain', 'Forest')
        self.assertEqual(len({traits_for(name) for name in basics}), 5)
        for index, name in enumerate(basics):
            with self.subTest(name=name):
                self.assertEqual([feature(name, 'produces.' + c) for c in colors],
                    [float(i == index) for i in range(6)])
                self.assertEqual(feature(name, 'cost.tap'), 1)
                self.assertEqual(feature(name, 'effect.mana'), 1)
                self.assertEqual(row(name)['numbers']['activated_abilities'], 1)
                self.assertEqual(row(name)['numbers']['mana_max'], 1)
        self.assertEqual([feature('Llanowar Elves', 'produces.' + c) for c in colors], [0, 0, 0, 0, 1, 0])
        self.assertEqual([feature('Sacred Foundry', 'produces.' + c) for c in colors], [1, 0, 0, 1, 0, 0])
        self.assertEqual([feature('Ancient Cornucopia', 'produces.' + c) for c in colors], [1, 1, 1, 1, 1, 0])

    def test_stale_engine_descriptors_fail_with_regeneration_instruction(self):
        for field, stale in [('rustmage_revision', '0' * 40), ('observation_schema', -1)]:
            with self.subTest(field=field):
                with self.assertRaisesRegex(ValueError, 'regenerate with python3 scripts/export-rustmage-card-traits.py'):
                    _validate_manifest(dict(MANIFEST, **{field: stale}))

    def test_altered_alias_or_feature_cannot_retain_a_valid_manifest(self):
        changed_alias = dict(DATA, aliases=dict(DATA['aliases'], **{'Mountain': ALIASES['Island']}))
        changed_row = dict(DATA['cards'][0], features=[0.0] * TRAIT_WIDTH)
        changed_feature = dict(DATA, cards=[changed_row, *DATA['cards'][1:]])
        for damaged in (changed_alias, changed_feature):
            with self.assertRaisesRegex(ValueError, 'contents do not match their manifest'):
                _validate_content(damaged)


if __name__ == '__main__':
    unittest.main()
