import copy
import unittest
from patchwork_automaton.replay.tapps import convert


def obj(id, name, zone='Hand', owner='P0', **kw):
    return dict(id=id, name=name, zone=zone, owner=owner, controller=owner,
                kinds=2, tapped=False, counters={}, **kw)


def state(revision, objects, life=20, turn=1, step='Pregame', outcome=None):
    return dict(viewer='P0', revision=revision, turn=turn, step=step, active='P0',
                players=[dict(life=life, hand_count=1, library_count=59),
                         dict(life=20, hand_count=7, library_count=53)],
                objects=objects, outcome=outcome)


def recording():
    first=state(0,[obj(1,'Mountain')])
    second=state(1,[obj(1,'Mountain','Battlefield')],life=18,step='Main1')
    second['players'][0]['hand_count'] = 0
    return dict(version=1,backend='rustmage',seed=1,started_at='2026-01-01T00:00:00Z',
                ended_at=None,truncated=False,frames=[dict(state=first,action=None),
                dict(state=second,action=dict(actor='player_0',kind='PlayLand'))])


class ReplayTests(unittest.TestCase):
    def test_opening_land_and_life_are_preserved(self):
        stream=convert(recording())
        self.assertEqual(stream['events'][0]['kind'],'game_start')
        moves=[e for e in stream['events'] if e['kind']=='move']
        self.assertEqual([(e['from'],e['to']) for e in moves],[('library','hand'),('hand','battlefield')])
        self.assertEqual(moves[1]['reason'],'play_land')
        self.assertEqual(next(e['life'] for e in stream['events'] if e['kind']=='life'),18)
        self.assertEqual(stream['fidelity'],'reconstructed')
        self.assertEqual([e['seq'] for e in stream['events']],list(range(len(stream['events']))))

    def test_rejects_out_of_order_or_wrong_viewer(self):
        value=recording(); value['frames'][1]['state']['revision']=-1
        with self.assertRaises(ValueError): convert(value)
        value=recording(); value['frames'][0]['state']['viewer']='P1'
        with self.assertRaises(ValueError): convert(value)

    def test_terminal_and_incomplete_game(self):
        value=recording(); value['frames'][-1]['state']['outcome']={'Winner':'P1'}
        stream=convert(value)
        self.assertEqual(stream['game']['outcome'],'loss')
        self.assertEqual(stream['events'][-1]['kind'],'game_end')
        value=copy.deepcopy(value); value['frames'][-1]['state']['outcome']=None
        value.update(truncated=True,reason='decision_limit')
        stream=convert(value)
        self.assertEqual(stream['game']['outcome'],'unknown')
        self.assertTrue(any('truncated' in x for x in stream['limitations']))

    def test_player_one_perspective_and_result(self):
        value = recording()
        for frame in value['frames']:
            frame['state']['viewer'] = 'P1'
        value['frames'][-1]['action']['actor'] = 'player_1'
        value['frames'][-1]['state']['outcome'] = {'Winner': 'P1'}
        stream = convert(value)
        self.assertEqual(stream['player_seat'], 2)
        self.assertEqual(stream['seats']['2']['role'], 'player')
        self.assertEqual(stream['game']['outcome'], 'win')
        self.assertTrue(any(e.get('log') and e['log']['text'].startswith('Agent:') for e in stream['events']))


class XMageTraceTests(unittest.TestCase):
    def test_alternating_private_observations_do_not_leak_opponent_hand(self):
        from patchwork_automaton.replay.xmage_trace import normalize
        players=[dict(id='a',life=20,hand_count=1,library_count=59),
                 dict(id='b',life=20,hand_count=1,library_count=59)]
        def row(step, actor, identity, name):
            return dict(step=step, actor=actor, kind='GAME_SELECT',
                response=dict(option='yes'), choices=[dict(id='yes',label='Keep')],
                state=dict(revision=step,turn=1,phase='precombat_main',active='a',actor=identity,
                    players=copy.deepcopy(players),objects=[dict(id=identity+'-card',name=name,
                    zone='hand',controller=identity,properties={})]))
        rows=[row(0,'player_0','a','Mountain'),row(1,'player_1','b','Secret card'),
              row(2,'player_0','a','Mountain')]
        rows.append(dict(terminal=True,rewards={'player_0':1.,'player_1':-1.},
                         states={'player_0':rows[-1]['state']}))
        recording=normalize(rows)
        self.assertTrue(all(not any(o['name']=='Secret card' for o in f['state']['objects'])
                            for f in recording['frames']))
        self.assertEqual(recording['frames'][1]['state']['objects'][0]['name'],'Mountain')
        stream=convert(recording)
        self.assertEqual(stream['game']['format'],'XMage')
        self.assertEqual(stream['game']['outcome'],'win')
        self.assertNotIn('n:Secret card',stream['cards'])
        self.assertTrue(any('stale' in x for x in stream['limitations']))

    def test_trace_with_missing_terminal_is_not_reported_as_complete(self):
        from patchwork_automaton.replay.xmage_trace import normalize
        players=[dict(id='a',life=20,hand_count=0,library_count=60),
                 dict(id='b',life=20,hand_count=0,library_count=60)]
        rows=[dict(actor=seat, kind='GAME_ASK', choices=[], response={},
              state=dict(actor=pid,revision=i,players=players,objects=[],turn=1,phase=None,active=None))
              for i,(seat,pid) in enumerate((('player_0','a'),('player_1','b')))]
        stream=convert(normalize(rows))
        self.assertEqual(stream['game']['outcome'],'unknown')
        self.assertNotIn('game_end',[e['kind'] for e in stream['events']])
        self.assertNotIn('turn',[e['kind'] for e in stream['events']])


class CardMetadataTests(unittest.TestCase):
    def test_enriches_type_and_double_faced_art_without_touching_unknowns(self):
        from patchwork_automaton.replay.card_metadata import enrich
        def card(name): return dict(name=name, primary_type=None, type_line=None, image_url=None)
        stream=dict(cards={'land':card('Arid Mesa'), 'back':card('Back Face'), 'unknown':card('Unknown')})
        def fetch(batch):
            self.assertEqual(batch,['Arid Mesa','Back Face','Unknown'])
            return {'data':[dict(name='Arid Mesa',type_line='Land',image_uris={'normal':'land.png'}),
                dict(name='Front Face // Back Face', card_faces=[
                    dict(name='Front Face',type_line='Creature',image_uris={'normal':'front.png'}),
                    dict(name='Back Face',type_line='Land',image_uris={'normal':'back.png'})])]}
        self.assertEqual(enrich(stream, fetch=fetch),['Unknown'])
        self.assertEqual(stream['cards']['land']['primary_type'],'Land')
        self.assertEqual(stream['cards']['back']['image_url'],'back.png')
        self.assertTrue(stream['cards']['back']['back_face'])
        self.assertIsNone(stream['cards']['unknown']['primary_type'])


class StackTraceTests(unittest.TestCase):
    def test_unowned_stack_card_requires_matching_prior_selection(self):
        from patchwork_automaton.replay.xmage_trace import normalize
        players=[dict(id='a',life=20,hand_count=1,library_count=59),
                 dict(id='b',life=20,hand_count=1,library_count=59)]
        def row(i, actor, pid, objects, response):
            return dict(actor=actor,kind='GAME_SELECT',response={'option':response},choices=[],
                state=dict(actor=pid,revision=i,turn=1,phase='precombat_main',active='a',
                           players=players,objects=objects))
        hand=dict(id='hand-id',name='Mountain',zone='hand',controller='a',properties={})
        card=dict(id='stack-id',name='Mountain',zone='stack',controller=None,properties={})
        ability=dict(id='ability-id',name='Ability',zone='stack',controller=None,properties={})
        rows=[row(0,'player_0','a',[hand],'object:hand-id'),
              row(1,'player_1','b',[card,ability],'yes'),
              row(2,'player_0','a',[card,ability],'yes')]
        frames=normalize(rows)['frames']
        self.assertEqual([o['name'] for o in frames[1]['state']['objects'] if o['zone']=='Stack'],['Mountain'])
        self.assertEqual([o['controller'] for o in frames[2]['state']['objects'] if o['zone']=='Stack'],['P0'])
        rows[0]['response']={'option':'object:other'}
        frames=normalize(rows)['frames']
        self.assertFalse(any(o['zone']=='Stack' for o in frames[1]['state']['objects']))
