"""Cached target rows pad legally and retain finite expert losses."""

from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import numpy as np

from examples.cache_standard_target_roles import TargetRecord, save_shard
from examples.bootstrap_cached_role_ab import paired_bootstrap
from examples.train_cached_standard_role_ab import CachedShard, collate_targets, evaluate


def record(logits, label, game):
    count = len(logits)
    features = np.full((count, 4), float(game), np.float32)
    return TargetRecord(np.asarray(logits, np.float32), features, features.copy(),
                        np.zeros(2, np.float32), np.ones(2, np.float32),
                        label, 'mono-green-landfall', game, 0, 3,
                        f'/fixture/game-{game}.pkl.gz', 7, 0,
                        np.full((count, 3), -1, np.int32))


class CachedStandardRoleABTests(unittest.TestCase):
    def test_game_bootstrap_preserves_stage_pairing(self):
        records = [(SimpleNamespace(stage=stage,
                    arrays={'decks': np.asarray(['mono-green-landfall']),
                            'games': np.asarray([stage])}), 0)
                   for stage in (1, 2)]
        result = paired_bootstrap(records, np.asarray([1., 2.]),
            np.asarray([2., 3.]), np.asarray([1, 1]), np.asarray([0, 0]),
            seed=11, replicates=200)
        self.assertEqual(result['ordered_minus_pooled_nll'], -1.)
        self.assertEqual(result['nll_bootstrap_95'], [-1., -1.])
        self.assertEqual(result['ordered_minus_pooled_top1'], 1.)
        self.assertEqual(result['targets'], 2)

    def test_variable_legal_counts_and_extreme_nll(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / 'targets.npz'
            metadata = save_shard(path, [record([0, -1000], 1, 1),
                                         record([0, 1, 2], 2, 2)])
            shard = CachedShard(dict(metadata, stage=1, partition='validation'))
            entries = [(shard, 0), (shard, 1)]
            features, base, mask, labels = collate_targets(entries, 'ordered')
            self.assertEqual(features.shape, (2, 3, 4))
            np.testing.assert_array_equal(mask, [[1, 1, 0], [1, 1, 1]])
            np.testing.assert_array_equal(labels, [1, 2])
            self.assertLess(base[0, 2], -1e8)
            metrics = evaluate(None, entries, 'ordered', batch_size=2, device='cpu')
            self.assertTrue(np.isfinite(metrics['all']['mean_negative_log_likelihood']))
            self.assertGreater(metrics['all']['mean_negative_log_likelihood'], 500)
            self.assertEqual(metrics['all']['samples'], 2)


if __name__ == '__main__':
    unittest.main()
