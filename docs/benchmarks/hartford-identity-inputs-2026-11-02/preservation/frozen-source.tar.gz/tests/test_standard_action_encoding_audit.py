"""Saved numerical action choices can be audited without a model or game run."""
import gzip
import json
from pathlib import Path
import pickle
from tempfile import TemporaryDirectory
import unittest

import numpy as np

from examples.audit_standard_action_encoding import (audit_dataset, candidate_bucket,
    inspect_decision, select_games, write_new_json)
from patchwork_automaton.neural.demonstrations import Demonstration


def arrays(candidates, refs):
    return dict(candidates=np.asarray(candidates, np.float32),
                candidate_refs=np.asarray(refs, np.float32),
                candidate_mask=np.ones(len(candidates), bool))


class ActionEncodingAuditTests(unittest.TestCase):
    def test_full_tie_requires_both_candidate_and_reference_equality(self):
        tied = inspect_decision(arrays([[1, 0], [1, 0], [0, 1]],
                                        [[1, 0], [1, 0], [0, 1]]), 0)
        self.assertEqual(tied['full_tie_groups'], [[0, 1]])
        self.assertEqual(tied['expert_tie_size'], 2)
        separated = inspect_decision(arrays([[1, 0], [1, 0], [0, 1]],
                                             [[1, 0], [0, 1], [0, 1]]), 0)
        self.assertEqual(separated['full_tie_groups'], [])
        self.assertEqual(separated['candidate_feature_tie_groups'], [[0, 1]])
        self.assertEqual(separated['expert_tie_size'], 1)
        with self.assertRaises(ValueError):
            inspect_decision(arrays([[1, 0]], [[1, 0]]), 0)

    def test_bounded_selection_round_robins_pairings(self):
        games = [dict(index=i, pairing=[deck], partition='validation', status='win')
                 for deck, indices in (('a', (0, 1, 2)), ('b', (3, 4, 5))) for i in indices]
        self.assertEqual([game['index'] for game in select_games(
            games, partition='validation', max_games=4)], [0, 3, 1, 4])
        self.assertEqual(candidate_bucket(2), '2')
        self.assertEqual(candidate_bucket(33), '33+')

    def test_dataset_audit_resolves_moved_trajectory_and_writes_new_file(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / 'trajectories').mkdir()
            trajectory_path = root / 'trajectories' / 'example.pkl.gz'
            sample = Demonstration(arrays([[1, 0], [1, 0]], [[1, 0], [1, 0]]),
                                   0, 'ChooseSearch', 'library_search')
            with gzip.open(trajectory_path, 'wb') as stream:
                pickle.dump(sample, stream)
            manifest = dict(encoder=dict(fingerprint='old-schema', feature_spec={'candidates': 2}),
                            games=[dict(index=7, seed=71, pairing=['test-deck'],
                                partition='validation', status='win',
                                trajectories=[dict(path='/old/root/example.pkl.gz', samples=1,
                                    player=0, deck='test-deck')])])
            dataset = root / 'dataset.json'
            dataset.write_text(json.dumps(manifest))
            report = audit_dataset(dataset, max_games=1)
            self.assertEqual(report['dataset_encoder_fingerprint'], 'old-schema')
            self.assertEqual(report['counts']['decisions'], 1)
            self.assertEqual(report['counts']['exact_full_input_tie_decisions'], 1)
            self.assertEqual(report['by']['decision_kind']['library_search']['expert_exactly_tied_decisions'], 1)
            output = root / 'report.json'
            write_new_json(output, report)
            self.assertEqual(json.loads(output.read_text())['counts']['decisions'], 1)
            with self.assertRaises(FileExistsError):
                write_new_json(output, report)


if __name__ == '__main__':
    unittest.main()
