"""Raw replay distinguishes likely duplicate copies from different cards."""
import unittest

from examples.classify_standard_action_ties import classify_group


class ActionTieClassificationTests(unittest.TestCase):
    def test_same_name_library_copies_are_marked_likely_interchangeable(self):
        raw = dict(search_choice=dict(cards=[
            dict(id=10, card='Plains', zone='Library', controller='P0'),
            dict(id=11, card='Plains', zone='Library', controller='P0')]))
        group = classify_group([dict(kind='ChooseSearch', card=10),
                                dict(kind='ChooseSearch', card=11)], raw)
        self.assertEqual(group['category'], 'likely_same_name_library_copies')

    def test_different_visible_cards_are_confirmed_distinct(self):
        raw = dict(search_choice=dict(cards=[
            dict(id=10, card='Plains', zone='Library', controller='P0'),
            dict(id=11, card='Swamp', zone='Library', controller='P0')]))
        group = classify_group([dict(kind='ChooseSearch', card=10),
                                dict(kind='ChooseSearch', card=11)], raw)
        self.assertEqual(group['category'], 'different_visible_actions')

    def test_unresolved_card_id_remains_unclassified(self):
        group = classify_group([dict(kind='ChooseSearch', card=10),
                                dict(kind='ChooseSearch', card=11)], {})
        self.assertEqual(group['category'], 'unresolved_visible_identity')

    def test_hidden_card_names_are_not_used(self):
        raw = dict(search_choice=dict(cards=[
            dict(id=10, card='Plains', zone='Library', hideInfo=True),
            dict(id=11, card='Swamp', zone='Library', faceDown=True)]))
        group = classify_group([dict(kind='ChooseSearch', card=10),
                                dict(kind='ChooseSearch', card=11)], raw)
        self.assertEqual(group['category'], 'unresolved_visible_identity')


if __name__ == '__main__':
    unittest.main()
