"""Ordered role recovery must match the saved pooled reference exactly."""

import unittest

import numpy as np

from patchwork_automaton.neural.role_pointers import (exact_role_refs_from_indices,
    reconstruct_role_refs)


MANIFEST = dict(feature_version=5, actions={'ChooseTarget': ('target',)},
                feature_spec=dict(candidates=16, semantics=2, entities=2))


def role(present, traits=(0, 0), live=(0, 0)):
    return [present, *traits, *live]


def arrays(entities, semantics, candidate, refs):
    return dict(entities=np.asarray(entities, np.float32),
                semantics=np.asarray(semantics, np.float32)[:, None, :],
                candidates=np.asarray([candidate], np.float32),
                candidate_refs=np.asarray([refs], np.float32),
                candidate_mask=np.ones(1, bool))


class RolePointerTests(unittest.TestCase):
    def test_ordered_roles_are_recovered_from_unordered_average(self):
        candidate = [1] + role(1, (1, 0), (1, 0)) + role(1, (0, 1), (0, 1)) + role(0)
        restored, statuses = reconstruct_role_refs(arrays(
            [[1, 0], [0, 1]], [[1, 0], [0, 1]], candidate, [.5, .5]), MANIFEST)
        self.assertEqual(statuses, ['resolved'])
        np.testing.assert_array_equal(restored[0], [[1, 0], [0, 1], [0, 0]])

    def test_identical_entities_are_reported_as_ambiguous(self):
        candidate = [1] + role(1, (1, 0), (1, 0)) * 2 + role(0)
        restored, statuses = reconstruct_role_refs(arrays(
            [[1, 0], [1, 0]], [[1, 0], [1, 0]], candidate, [.5, .5]), MANIFEST)
        self.assertEqual(statuses, ['ambiguous'])
        self.assertFalse(restored.any())
        marginalized, statuses = reconstruct_role_refs(arrays(
            [[1, 0], [1, 0]], [[1, 0], [1, 0]], candidate, [.5, .5]),
            MANIFEST, marginalize=True)
        self.assertEqual(statuses, ['ambiguous'])
        np.testing.assert_array_equal(marginalized[0],
                                      [[.5, .5], [.5, .5], [0, 0]])
        saved = arrays([[1, 0], [1, 0]], [[1, 0], [1, 0]], candidate, [.5, .5])
        np.testing.assert_array_equal(exact_role_refs_from_indices(
            saved, MANIFEST, 0, [0, 1, None]), [[1, 0], [0, 1], [0, 0]])
        np.testing.assert_array_equal(exact_role_refs_from_indices(
            saved, MANIFEST, 0, [1, 0, None]), [[0, 1], [1, 0], [0, 0]])
        with self.assertRaisesRegex(ValueError, 'pooled reference'):
            exact_role_refs_from_indices(saved, MANIFEST, 0, [0, 0, None])

    def test_static_only_source_has_no_entity_pointer(self):
        candidate = [1] + role(1, (1, 0)) + role(0) + role(0)
        restored, statuses = reconstruct_role_refs(arrays(
            [[1, 0]], [[1, 0]], candidate, [0]), MANIFEST)
        self.assertEqual(statuses, ['resolved'])
        self.assertFalse(restored.any())


if __name__ == '__main__':
    unittest.main()
