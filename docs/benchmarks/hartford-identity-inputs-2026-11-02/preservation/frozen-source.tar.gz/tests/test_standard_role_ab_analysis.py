"""Paired role-head uncertainty uses whole games and matching cached targets."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

import numpy as np

from examples.analyze_standard_role_ab import (
    paired_game_summary, paired_target_losses, write_new_json)
from examples.diagnose_standard_decisions import file_sha256
from examples.train_cached_standard_role_ab import CachedShard


class _FirstFeatureHead:
    def __call__(self, features, training=False):
        return features[:, :, 0]


def _shard(root, stage, games):
    path = root / f'stage-{stage}-validation.npz'
    np.savez_compressed(path,
        offsets=np.asarray([0, 2, 4], np.int64),
        base_logits=np.zeros(4, np.float32),
        ordered_features=np.asarray([[0], [2], [0], [1]], np.float32),
        pooled_features=np.zeros((4, 1), np.float32),
        labels=np.ones(2, np.int32),
        decks=np.asarray(['mono-green-landfall'] * 2, dtype='<U48'),
        games=np.asarray(games, np.int64),
        players=np.zeros(2, np.int8),
        decisions=np.asarray([3, 8], np.int32),
        ambiguous_candidate_count=np.zeros(2, np.int32),
        role_indices=np.full((4, 3), -1, np.int32))
    return CachedShard(dict(path=str(path), sha256=file_sha256(path), stage=stage,
                            partition='validation', records=2,
                            candidate_rows=4, feature_width=1))


class StandardRoleABAnalysisTests(unittest.TestCase):
    def test_synthetic_shards_pair_targets_and_resample_games_by_stage(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            shards = [_shard(root, 1, (10, 11)), _shard(root, 2, (20, 21))]
            validation = [(shard, index) for shard in shards for index in range(2)]
            heads = {'ordered': _FirstFeatureHead(), 'pooled': _FirstFeatureHead()}
            losses = paired_target_losses(validation, heads, batch_size=3)
            self.assertEqual(len(losses), 4)
            cache = dict(stages=[dict(stage=stage,
                selected_validation_games=[[game, 100 + game] for game in games])
                for stage, games in ((1, (10, 11, 12)), (2, (20, 21, 22)))])
            first = paired_game_summary(cache, losses, bootstrap_samples=200, seed=7)
            second = paired_game_summary(cache, losses, bootstrap_samples=200, seed=7)
            self.assertEqual(first, second)
            self.assertEqual(first['pooled']['targets'], 4)
            self.assertEqual(first['stages']['1']['targets'], 2)
            self.assertEqual(first['stages']['2']['targets'], 2)
            self.assertEqual(first['stages']['1']['games'], 3)
            self.assertEqual(first['stages']['1']['games_with_targets'], 2)
            self.assertLess(first['pooled']['ordered_minus_pooled_mean_nll'], 0)
            self.assertLess(first['bootstrap']['ordered_minus_pooled_interval'][1], 0)
            self.assertEqual(len(first['games']), 6)

    def test_output_refuses_to_replace_existing_analysis(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'paired.json'
            write_new_json(path, {'value': 1})
            with self.assertRaises(FileExistsError):
                write_new_json(path, {'value': 2})


if __name__ == '__main__':
    unittest.main()
