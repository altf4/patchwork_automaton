"""Read-only dashboard contracts: streaming, projection, and sealed data boundaries."""
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

SPEC = importlib.util.spec_from_file_location('run_dashboard', Path(__file__).parents[1]/'tools/run_dashboard/server.py')
m = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)

class DashboardTests(unittest.TestCase):
    def test_report_streams_compact_rows_and_ignores_other_rounds_keys(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'report.json'
            p.write_text(json.dumps({'config':{'rounds':3},'rounds':[{'round':1,'games':[{'secret':'raw'}]*20000,'update':{'entropy':.2}},{'round':2,'update':{}}]},indent=2))
            rows=list(m.report_rows(p))
            self.assertEqual([r['games'] for r in rows],[1000,2000])
            self.assertNotIn('secret',json.dumps(rows))
            self.assertEqual(rows[0]['entropy'],.2)
    def test_truncated_report_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'r';p.write_text('  "rounds": [\n {"round":')
            with self.assertRaises(ValueError):list(m.report_rows(p))
    def test_cache_preserves_good_snapshot_on_partial_write(self):
        with tempfile.TemporaryDirectory() as td:
            d=m.Dashboard({'state_dir':td});p=Path(td)/'input.json'
            p.write_text('{"x":1}');self.assertEqual(d.cached(p,m.read_json),{'x':1})
            p.write_text('{')
            with self.assertRaises(ValueError):d.cached(p,m.read_json)
            self.assertEqual(d.cache[str(p)][1],{'x':1})
    def test_final_files_are_not_opened_before_target(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'training/checkpoints').mkdir(parents=True)
            (root/'study.json').write_text('{"status":"running"}')
            (root/'training/report.json').write_text(json.dumps({'rounds':[{'round':100}]},indent=2))
            cp=root/'training/checkpoints/latest.json';cp.write_text('{"checkpoint":"round-0100"}')
            (root/'confirmation-round-140.json').write_text('DO NOT OPEN')
            (root/'head-to-head-round-100.json').write_text('DO NOT OPEN')
            d=m.Dashboard({'state_dir':str(root/'cache')});cfg={'id':'a','name':'a','output':td,'target_round':140}
            self.assertEqual(d.run_snapshot(cfg)['evaluations'],[])
            cp.write_text('{"checkpoint":"round-0140"}')
            with self.assertRaises(ValueError):d.run_snapshot(cfg)
    def test_endpoint_allowlist_and_live_stream(self):
        with tempfile.TemporaryDirectory() as td:
            d=m.Dashboard({'state_dir':td});d.payload=b'{"time":1}';d.revision=1
            server=m.Server(('127.0.0.1',0),m.Handler);server.dashboard=d
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            url=f'http://127.0.0.1:{server.server_port}'
            try:
                with urllib.request.urlopen(url+'/api/snapshot') as r:self.assertEqual(json.load(r),{'time':1})
                for path in ['/etc/passwd','/../server.py','/api/start','/config.json']:
                    with self.assertRaises(urllib.error.HTTPError) as exc:urllib.request.urlopen(url+path)
                    self.assertEqual(exc.exception.code,404)
                with urllib.request.urlopen(url+'/events',timeout=2) as stream:
                    self.assertEqual(stream.readline(),b'data: {"time":1}\n');stream.readline()
                    with d.condition:d.payload=b'{"time":2}';d.revision+=1;d.condition.notify_all()
                    self.assertEqual(stream.readline(),b'data: {"time":2}\n')
                request=urllib.request.Request(url+'/api/snapshot',method='POST',data=b'{}')
                with self.assertRaises(urllib.error.HTTPError) as exc:urllib.request.urlopen(request)
                self.assertEqual(exc.exception.code,501)
            finally:
                d.stop.set()
                with d.condition:d.condition.notify_all()
                server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main()
