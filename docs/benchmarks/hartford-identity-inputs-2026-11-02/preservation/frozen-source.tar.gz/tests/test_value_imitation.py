"""Seat-relative outcomes, heldout isolation and critic-only optimization."""
from collections import Counter
from copy import deepcopy
import os
from pathlib import Path
import tempfile
import unittest
import numpy as np

from examples.collect_standard_demonstrations import schedule
from patchwork_automaton.neural.value_demonstrations import outcome_target, select_games, select_next_games


class ValueDataTests(unittest.TestCase):
    def games(self):
        games = list(schedule(2000, 200000))
        for game in games:
            winner = game['seed'] % 2
            game.update(status='win' if winner == 0 else 'loss', winner_seat=winner,
                trajectories=[dict(player=p, deck=deck, samples=2, path=f'example-{game["seed"]}-{p}')
                              for p, deck in enumerate(game['decks'])])
        return games

    def test_labels_use_physical_seat_and_draws(self):
        game = dict(status='loss', winner_seat=1)
        self.assertEqual([outcome_target(game, p) for p in (0,1)], [-1.,1.])
        game.update(status='draw', winner_seat=None)
        self.assertEqual([outcome_target(game, p) for p in (0,1)], [0.,0.])
        game['reason'] = 'wall_clock_timeout'
        with self.assertRaises(ValueError): outcome_target(game, 0)
        with self.assertRaises(ValueError): outcome_target(dict(status='error'), 0)
        with self.assertRaises(ValueError): outcome_target(dict(status='win', winner_seat=1), 0)

    def test_selection_balances_pair_seat_start_and_preserves_whole_game_split(self):
        games = self.games(); original = deepcopy(games)
        chosen = select_games(games)
        self.assertEqual(Counter(g['partition'] for g in chosen), dict(training=960, validation=240))
        strata = Counter((tuple(g['pairing']), g['index'] % 4, g['partition']) for g in chosen)
        self.assertEqual(len(strata), 48)
        self.assertTrue(all(n == (40 if k[-1] == 'training' else 10) for k,n in strata.items()))
        self.assertEqual(len({g['seed'] for g in chosen}),1200)
        self.assertTrue(all(sum(t['target'] for t in g['trajectories']) == 0 for g in chosen))
        self.assertEqual(games,original)

    def test_timeout_and_partial_records_cannot_get_value_targets(self):
        games = self.games()
        games[0].update(status='draw', winner_seat=None, reason='wall_clock_timeout')
        games[1]['trajectories'][0]['partial'] = True
        chosen = select_games(games)
        self.assertFalse({games[0]['seed'],games[1]['seed']} & {g['seed'] for g in chosen})

    def test_duplicate_games_and_bad_budget_rejected(self):
        games = self.games()
        with self.assertRaises(ValueError): select_games(games + games[:1])
        with self.assertRaises(ValueError): select_games(games,121)

    def test_next_round_has_fresh_training_and_identical_validation(self):
        games = self.games()
        previous = select_games(games)
        following = select_next_games(games, previous)
        seeds = lambda cohort, part: {g['seed'] for g in cohort if g['partition']==part}
        self.assertEqual(seeds(previous,'validation'),seeds(following,'validation'))
        self.assertFalse(seeds(previous,'training') & seeds(following,'training'))
        used = seeds(previous,'training') | seeds(following,'training')
        third = select_next_games(games, following, excluded_training_seeds=used)
        self.assertFalse(used & seeds(third,'training'))
        self.assertEqual(seeds(previous,'validation'),seeds(third,'validation'))


@unittest.skipUnless(os.environ.get('PATCHWORK_GPU_TEST') == '1', 'Explicit GPU verification')
class ValueGPUTests(unittest.TestCase):
    def test_critic_updates_actor_stays_frozen_validation_is_read_only(self):
        import keras
        from patchwork_automaton.neural.devices import configure_runtime, device_scope
        from patchwork_automaton.neural.batching import example_batch
        from patchwork_automaton.neural.model import SeparateActorCritic
        from patchwork_automaton.neural.standard_features import StandardEncoder
        from patchwork_automaton.neural.demonstrations import Demonstration, DemonstrationWriter
        from patchwork_automaton.neural.inference_processes import weights_digest
        from patchwork_automaton.neural.value_imitation import ValueImitationTrainer, value_chunks
        from patchwork_automaton.neural.recurrent import configure_gru_backend
        configure_runtime('gpu')
        keras.utils.set_random_seed(9102)
        with device_scope('gpu'):
            model = SeparateActorCritic(1,StandardEncoder.feature_spec)
            example = example_batch(model.memory_size,model.feature_spec)
            model(example)
            configure_gru_backend(model,'cudnn-memory')
            trainer = ValueImitationTrainer(model,batch_size=2,unroll=2)
        actor = weights_digest(model.actor.get_weights()); critic = weights_digest(model.critic.get_weights())
        arrays = {k:v[0] for k,v in example.items() if k not in ('memory_in','advance_memory')}
        arrays.update(candidates=np.zeros((2,model.feature_spec['candidates']),np.float32),
                      candidate_refs=np.zeros((2,2),np.float32),candidate_mask=np.ones(2,bool))
        with tempfile.TemporaryDirectory() as directory:
            entries = []
            for seat in (0,1):
                path = Path(directory)/f'{seat}.pkl.gz'
                writer = DemonstrationWriter(path)
                for i in range(seat+1): writer.write(Demonstration(arrays,0,'Keep','mulligan'))
                writer.close()
                entries.append(dict(path=str(path),samples=seat+1,target=1. if seat else -1.,deck='test'))
            games=[dict(partition='training',pairing=['test','test'],trajectories=entries)]
            trainer.run(games,training=True)
            self.assertEqual(actor,weights_digest(model.actor.get_weights()))
            self.assertNotEqual(critic,weights_digest(model.critic.get_weights()))
            snapshot=(weights_digest(model.get_weights()),weights_digest([np.asarray(v) for v in trainer.optimizer.variables]),deepcopy(trainer.rng.bit_generator.state))
            valid=[dict(games[0],partition='validation')]
            result=trainer.run(valid)
            self.assertEqual(result['samples'],3)
            self.assertEqual(snapshot,(weights_digest(model.get_weights()),weights_digest([np.asarray(v) for v in trainer.optimizer.variables]),deepcopy(trainer.rng.bit_generator.state)))
            with self.assertRaises(ValueError):trainer.run(valid,training=True)
            # Padding a finished seat must neither reset nor advance its memory.
            records=[[Demonstration(arrays,0,'Keep','mulligan')]]
            packed,active=next(value_chunks(records,2))
            initial=np.ones((1,model.critic.memory_size),np.float32)
            with device_scope('gpu'):
                state,_=trainer.evaluate_chunk(initial,packed,np.array([0.],np.float32),np.zeros_like(active))
            np.testing.assert_array_equal(state,initial)
            from patchwork_automaton.neural.experiment import save_checkpoint, load_checkpoint
            from patchwork_automaton.neural.standard_policy import StandardPolicy
            config=dict(algorithm='value-imitation',learning_rate=.0003,train_batch=2,
                        unroll=2,seed=30261029,learner_device='gpu')
            checkpoint=Path(directory)/'checkpoints'
            save_checkpoint(checkpoint,model,trainer,dict(round=1,config=config),policy_type=StandardPolicy)
            with device_scope('gpu'):
                loaded,restored,_=load_checkpoint(checkpoint,policy_type=StandardPolicy,gru_backend='cudnn-memory')
            self.assertEqual(weights_digest(model.get_weights()),weights_digest(loaded.get_weights()))
            self.assertEqual(weights_digest([np.asarray(v) for v in trainer.optimizer.variables]),
                             weights_digest([np.asarray(v) for v in restored.optimizer.variables]))
            self.assertEqual(trainer.rng.bit_generator.state,restored.rng.bit_generator.state)


if __name__ == '__main__': unittest.main()
