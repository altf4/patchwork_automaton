"""Raw-action sidecar keeps role order where saved v5 facts are ambiguous."""
from types import SimpleNamespace
import unittest

import numpy as np

from examples.replay_standard_target_role_sidecar import (
    raw_role_indices, verify_role_blocks)
from patchwork_automaton.core import Handle
from patchwork_automaton.neural.role_pointers import role_layout
from patchwork_automaton.neural.standard_features import StandardEncoder


class StandardTargetRoleSidecarTests(unittest.TestCase):
    def test_raw_ids_order_identical_visible_source_and_target(self):
        actor = Handle('rustmage', 'player', 'P0')
        other = Handle('rustmage', 'player', 'P1')
        objects = {}
        for identifier in (80, 81):
            handle = Handle('rustmage', 'object', str(identifier))
            objects[handle] = SimpleNamespace(id=handle)
        obs = SimpleNamespace(actor=actor,
            players=[SimpleNamespace(id=actor), SimpleNamespace(id=other)],
            objects=objects,
            native=dict(stack=[], waiting_triggers=[],
                        announcing=dict(card=80, source_card='Mightform Harmonizer')))
        action = dict(kind='ChooseTarget', target=dict(Card=81))
        roles, identity = raw_role_indices(obs, action, StandardEncoder())
        self.assertEqual(roles, (2, 3, None))
        self.assertEqual(identity['source_lookup_key'], 80)
        self.assertEqual(identity['target_key'], {'Card': 81})

    def test_role_blocks_and_pooled_ref_reject_wrong_assignment(self):
        manifest = StandardEncoder().manifest()
        action_width, semantic_width, entity_width, role_width = role_layout(manifest)
        row = np.zeros(manifest['feature_spec']['candidates'], np.float32)
        facts = np.zeros(entity_width, np.float32)
        facts[0] = 1
        traits = np.zeros(semantic_width, np.float32)
        traits[0] = 1
        block = np.concatenate((np.ones(1, np.float32), traits, facts))
        for role in (0, 1):
            start = action_width + role * role_width
            row[start:start + role_width] = block
        arrays = dict(candidates=row[None],
            candidate_refs=np.asarray([[0.5, 0.5]], np.float32),
            entities=np.stack((facts, facts)),
            semantics=np.stack((traits, traits))[:, None, :])
        verify_role_blocks(arrays, manifest, 0, (0, 1, None), None)
        # Both assignments match the saved facts; only the raw action fixes order.
        verify_role_blocks(arrays, manifest, 0, (1, 0, None), None)
        with self.assertRaisesRegex(ValueError, 'pooled candidate reference'):
            verify_role_blocks(arrays, manifest, 0, (0, 0, None), None)


if __name__ == '__main__':
    unittest.main()
