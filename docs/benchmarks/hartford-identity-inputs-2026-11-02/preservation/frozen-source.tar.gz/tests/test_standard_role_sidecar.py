"""Raw-replay overrides must cover exactly the audited ambiguous candidates."""

import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from examples.cache_standard_target_roles import load_exact_role_sidecar
from examples.diagnose_standard_decisions import file_sha256


class StandardRoleSidecarTests(unittest.TestCase):
    def test_exact_key_set_and_trajectory_hash_are_required(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            directories = [root / f'stage-{stage}' for stage in (1, 2)]
            for directory in directories:
                directory.mkdir()
                (directory / 'dataset.json').write_text('{}')
            trajectory = root / 'seat.pkl.gz'
            trajectory.write_bytes(b'saved expert stream')
            manifest = dict(fingerprint='v5')
            stages = [dict(stage=stage, directory=str(directory),
                           training=[dict(index=1)] if stage == 1 else [], validation=[])
                      for stage, directory in enumerate(directories, 1)]
            audit = dict(encoder_fingerprint='v5', checkpoint_sha256='cp200',
                sample_seed=73, totals=dict(unresolved_candidates=1),
                selected_games={'1|training': 1, '1|validation': 0,
                                '2|training': 0, '2|validation': 0},
                datasets={str(directory / 'dataset.json'): file_sha256(directory / 'dataset.json')
                          for directory in directories},
                failures=[dict(stage=1, game=1, player=0, decision=2,
                               partition='training', path=str(trajectory),
                               candidates=[[3, 'ambiguous']])])
            audit_path = root / 'audit.json'
            audit_path.write_text(json.dumps(audit))
            row = dict(stage=1, game=1, player=0, decision_ordinal=2,
                       candidate_index=3, partition='training', roles=[2, 3, None],
                       raw_action='ChooseTarget', role_identity={})
            sidecar = dict(schema=1, status='complete',
                role_order=['source', 'target', 'other'], failure_report=str(audit_path),
                encoder_fingerprint='v5', failure_report_sha256=file_sha256(audit_path),
                expected_rows=1, recovered_rows=1, expected_games=1,
                expected_decisions=1, errors={}, rows=[row],
                verified_games=[dict(stage=1, game=1, decisions_verified=1)],
                trajectory_sha256={str(trajectory): file_sha256(trajectory)},
                datasets={str(stage): dict(path=str(directory / 'dataset.json'),
                                           sha256=file_sha256(directory / 'dataset.json'))
                          for stage, directory in enumerate(directories, 1)})
            sidecar_path = root / 'roles.json'
            sidecar_path.write_text(json.dumps(sidecar))
            rows, provenance = load_exact_role_sidecar(sidecar_path, audit_path,
                manifest, stages, 'cp200', 73)
            self.assertEqual(rows[(1, 1, 0, 2, 3)]['roles'], [2, 3, None])
            self.assertEqual(provenance['expected_rows'], 1)
            sidecar['rows'].append(dict(row, candidate_index=4))
            sidecar_path.write_text(json.dumps(sidecar))
            with self.assertRaisesRegex(ValueError, 'Extra or duplicate'):
                load_exact_role_sidecar(sidecar_path, audit_path, manifest,
                                        stages, 'cp200', 73)


if __name__ == '__main__':
    unittest.main()
