"""Visible choice distinctions remain available on the current Standard schema."""
import os
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from examples.audit_standard_action_encoding import inspect_decision
from examples.compare_standard_choice_encoding import compare_group
from patchwork_automaton.backends.rustmage import RustMageMatch, domain_action
from patchwork_automaton.baselines.standard import StandardAggro
from patchwork_automaton.baselines.standard_decks import standard_deck
from patchwork_automaton.neural.demonstrations import expert_index
from patchwork_automaton.neural.rustmage_observation import learning_observation
from patchwork_automaton.neural.features import numeric
from patchwork_automaton.neural.standard_choice_features import (
    StandardChoiceEncoder, _choice_objects, _visible_trigger_ability)
from patchwork_automaton.neural.standard_features import StandardEncoder


def replay_targets(seed, decks, starting_player, targets):
    old = StandardEncoder()
    new = StandardChoiceEncoder()
    policies = [StandardAggro(deck) for deck in decks]
    ordinals = [0, 0]
    found = {}
    with patch.dict(os.environ, {'PATCHWORK_OBSERVATION_PIPELINE': 'python'}):
        with RustMageMatch(*(standard_deck(deck) for deck in decks),
                seed=seed, starting_player=starting_player) as match:
            for _ in range(2000):
                views = [learning_observation(match, f'P{index}') for index in range(2)]
                if views[0].terminal:
                    break
                players = [index for index, view in enumerate(views)
                           if view.decision is not None]
                if len(players) != 1:
                    raise AssertionError('Expected exactly one acting player')
                player = players[0]
                view = views[player]
                response = policies[player].choose(view)
                choices = old.expand_options(view.decision)
                if len(choices) > 1:
                    ordinal = ordinals[player]
                    ordinals[player] += 1
                    if (player, ordinal) in targets:
                        action = expert_index(view.decision, response, choices)
                        before = old.encode(view, choices=choices).arrays
                        after = new.encode(view, choices=choices).arrays
                        found[player, ordinal] = dict(
                            decision_kind=view.decision.kind,
                            before=inspect_decision(before, action),
                            after=inspect_decision(after, action),
                            old_arrays=before, new_arrays=after, choices=choices,
                            raw=view.native)
                        if len(found) == len(targets):
                            return found
                option = next(option for option in view.decision.options
                              if option.id == response.option)
                action = (option.constraints['action'] if option.kind == 'finite'
                          else domain_action(option, response.value))
                raw = match._raw(view.actor.value)
                updated = (match.native_game.step(raw, int(option.id.split(':')[1]))
                           if option.kind == 'finite' else match.native_game.act(raw, action))
                match._after_action(updated, view.actor.value, raw['revision'])
    raise AssertionError(f'Replay reached {set(found)}, expected {targets}')


class StandardChoiceEncodingTests(unittest.TestCase):
    def test_current_schema_has_a_new_explicit_checkpoint_identity(self):
        v5 = StandardEncoder().manifest()
        v6 = StandardChoiceEncoder().manifest()
        self.assertEqual(v5['fingerprint'],
                         'bddb155245929c0dd3a3d59ab48c85f724739dd5767ae86a67146faf2abc9ac6')
        self.assertEqual(v5['feature_version'], 6)
        self.assertEqual(v5['observation_schema'], 198)
        self.assertEqual(len(v5['actions']), 200)
        self.assertEqual(v6['feature_version'], 6)
        self.assertNotEqual(v5['fingerprint'], v6['fingerprint'])
        self.assertEqual(v5['feature_spec'], v6['feature_spec'])

    def test_only_legal_unconcealed_choice_cards_become_entities(self):
        raw = dict(search_choice=dict(cards=[
            dict(id=10, card='Forest', zone='Library', controller='P0'),
            dict(id=11, card='Swamp', zone='Library', controller='P0', hideInfo=True),
            dict(id=12, card='Mountain', zone='Library', controller='P0')]))
        obs = SimpleNamespace(objects={}, native=raw)
        choices = [(None, dict(kind='ChooseSearch', card=10)),
                   (None, dict(kind='ChooseSearch', card=11))]
        objects = _choice_objects(obs, choices)
        self.assertEqual(set(objects), {10})
        self.assertEqual(objects[10].name, 'Forest')
        self.assertEqual(objects[10].zone, 'library')

    def test_current_schema_distinguishes_visible_library_choices(self):
        with RustMageMatch(standard_deck('mono-green-landfall'),
                          standard_deck('mono-green-landfall'), seed=81) as match:
            observation = learning_observation(match, 'P0')
        encoder = StandardEncoder()
        for pool, field, kind in (('search_choice', 'cards', 'ChooseSearch'),
                                  ('library_choice', 'remaining', 'ArrangeLibrary'),
                                  ('library_selection', 'remaining', 'SelectLibrary')):
            with self.subTest(pool=pool):
                raw = dict(observation.native)
                raw[pool] = {field: [dict(id=1000 + i, card=card, zone='Library', controller='P0')
                                    for i, card in enumerate(('Forest', 'Mountain'))]}
                choices = tuple((None, dict(kind=kind, card=1000+i,
                                **({'destination': 'Top'} if kind == 'ArrangeLibrary' else {})))
                                for i in range(2))
                encoded = encoder.encode(observation._replace(native=raw), choices=choices).arrays
                self.assertEqual(inspect_decision(encoded, 0)['full_tie_groups'], [])
                self.assertEqual(len(encoded['entities']), len(observation.objects) + 4)
                self.assertTrue(np.all(encoded['card_ids'] == 0))
                self.assertEqual(len(observation.objects), len(observation.native['objects']))

    def test_visible_trigger_abilities_split_under_both_source_shapes(self):
        with RustMageMatch(standard_deck('mono-green-landfall'),
                          standard_deck('mono-green-landfall'), seed=81) as match:
            observation = learning_observation(match, 'P0')
        source = next(iter(observation.objects.values())).properties
        choices = ((None, dict(kind='PutTrigger', id=900)),
                   (None, dict(kind='PutTrigger', id=901)))
        for nested in (False, True):
            with self.subTest(nested_source=nested):
                identity = (dict(source=dict(object=source['reference'], card=source['card']))
                            if nested else dict(card=source['id'], source_card=source['card']))
                raw = dict(observation.native, waiting_triggers=[
                    dict(id=900+i, kind=dict(TriggeredAbility=dict(ability=i)), **identity)
                    for i in range(2)])
                obs = observation._replace(native=raw)
                before = StandardEncoder().encode(obs, choices=choices).arrays
                encoder = StandardChoiceEncoder()
                after = encoder.encode(obs, choices=choices).arrays
                self.assertEqual(inspect_decision(before, 0)['full_tie_groups'], [[0, 1]])
                self.assertEqual(inspect_decision(after, 0)['full_tie_groups'], [])
                self.assertEqual(len(before['entities']), len(after['entities']))
                offset = len(encoder.actions) + 3 * (1 + encoder.feature_spec['semantics']
                                                    + encoder.feature_spec['entities'])
                np.testing.assert_allclose(after['candidates'][0, offset:offset+2], numeric(0))
                np.testing.assert_allclose(after['candidates'][1, offset:offset+2], numeric(1))
                np.testing.assert_array_equal(after['candidates'][:, :offset],
                                              before['candidates'][:, :offset])

    def test_hidden_trigger_does_not_expose_ability(self):
        action = dict(kind='PutTrigger', id=9)
        raw = dict(waiting_triggers=[dict(id=9, card=10,
            source_card='Secret Card', kind=dict(TriggeredAbility=dict(ability=2)))],
            objects=[dict(id=10, card='Secret Card', hideInfo=True)])
        self.assertIsNone(_visible_trigger_ability(raw, action))

    def test_comparison_separates_distinct_names_from_equivalent_copies(self):
        actions = [dict(kind='ChooseSearch', card=index) for index in range(4)]
        raw = dict(search_choice=dict(cards=[
            dict(id=index, card='Forest' if index < 2 else 'Swamp',
                 zone='Library', controller='P0') for index in range(4)]))
        arrays = dict(candidates=np.asarray([[1], [1], [2], [2]], np.float32),
                      candidate_refs=np.zeros((4, 1), np.float32))
        compared = compare_group([0, 1, 2, 3], actions, arrays, raw)
        self.assertEqual(compared['old_category'], 'different_visible_actions')
        self.assertEqual(compared['status'], 'partly_split')
        self.assertEqual(compared['remaining_tie_groups'], [[0, 1], [2, 3]])
        self.assertEqual(compared['remaining_categories'],
                         ['likely_same_name_library_copies'] * 2)


if __name__ == '__main__':
    unittest.main()
