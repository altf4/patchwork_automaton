"""Paired arena accounting and schedule integrity."""

import json
from pathlib import Path
import tempfile
import unittest

from examples.compare_standard_arena import write_new_json
from patchwork_automaton.rl.standard_arena_compare import compare_runs, read_run


DECK = 'mono-green-landfall'
CELL = f'{DECK}--{DECK}--tactical'


def make_run(root, label, outcomes, *, seed_base=100):
    root.mkdir()
    manifest = dict(schema=1, learner_label=label,
                    learner_checkpoint=f'/models/{label}/policy.keras',
                    learner_files_sha256={f'/models/{label}/policy.keras': label * 4},
                    opponent_label=None, opponent_checkpoint=None,
                    opponent_files_sha256={}, source_files_sha256={'arena.py': 'same'},
                    panel='mirrors', learner_decks=[DECK], opponent_decks=[DECK],
                    opponents=['tactical'], cells=[CELL], mode='greedy',
                    games_per_cell=4, seed_base=seed_base,
                    game_timeout=60., max_turns=50, max_decisions=6000,
                    workers=1, inference_processes=1, opponent_inference_processes=1,
                    engine_revision='test', observation_schema=169)
    (root / 'manifest.json').write_text(json.dumps(manifest))
    (root / 'summary.json').write_text(json.dumps({'complete': True}))
    directory = root / 'cells' / CELL
    directory.mkdir(parents=True)
    with (directory / 'games.jsonl').open('w') as stream:
        for offset, outcome in enumerate(outcomes):
            seat = offset % 2
            winner = (seat if outcome == 'win' else 1 - seat if outcome == 'loss' else None)
            status = 'draw' if outcome == 'draw' else 'error' if outcome == 'error' \
                else 'win' if winner == 0 else 'loss'
            row = dict(index=offset, seed=seed_base + offset, cell_id=CELL,
                       learner_deck=DECK, opponent_deck=DECK, opponent_style='tactical',
                       learner_seat=seat, starting_player=f'P{(offset // 2) % 2}',
                       decks=[DECK, DECK], pairing=[DECK, DECK], partition='evaluation',
                       opponent_kind='scripted', behavior_version=0,
                       learner_label=label, opponent_label='StandardTactical',
                       trajectories=[], status=status, winner_seat=winner,
                       draw=outcome == 'draw', learner_won=outcome == 'win')
            stream.write(json.dumps(row) + '\n')
    return root


class StandardArenaCompareTests(unittest.TestCase):
    def test_paired_score_uses_learner_seat_and_keeps_draws(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            first = make_run(root / 'first', 'old', ['loss', 'draw', 'win', 'loss'])
            second = make_run(root / 'second', 'new', ['win', 'draw', 'win', 'win'])
            result = compare_runs(first, second, bootstrap_samples=200, bootstrap_seed=12)
            self.assertTrue(result['clean'])
            self.assertEqual(result['aggregate']['paired_completed'], 4)
            self.assertEqual(result['aggregate']['baseline_score'], .375)
            self.assertEqual(result['aggregate']['candidate_score'], .875)
            self.assertEqual(result['aggregate']['score_delta'], .5)
            self.assertEqual(result['cells'][CELL]['score_delta'], .5)
            self.assertEqual(result['aggregate']['on_play']['scheduled'], 2)
            self.assertEqual(result['aggregate']['on_draw']['scheduled'], 2)
            self.assertLessEqual(result['aggregate']['paired_bootstrap_95'][0], .5)
            self.assertGreaterEqual(result['aggregate']['paired_bootstrap_95'][1], .5)

    def test_failed_games_are_explicit_and_excluded_from_paired_score(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            first = make_run(root / 'first', 'old', ['loss', 'error', 'win', 'loss'])
            second = make_run(root / 'second', 'new', ['win', 'draw', 'win', 'win'])
            result = compare_runs(first, second, bootstrap_samples=0)
            self.assertFalse(result['clean'])
            self.assertEqual(result['aggregate']['baseline_failed'], 1)
            self.assertEqual(result['aggregate']['excluded'], 1)
            self.assertEqual(result['aggregate']['paired_completed'], 3)
            self.assertIsNone(result['aggregate']['paired_bootstrap_95'])

    def test_mismatched_schedule_and_tampered_game_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            first = make_run(root / 'first', 'old', ['loss'] * 4)
            second = make_run(root / 'second', 'new', ['win'] * 4, seed_base=101)
            with self.assertRaisesRegex(ValueError, 'schedules or opponents differ'):
                compare_runs(first, second)
            rows = (second / 'cells' / CELL / 'games.jsonl').read_text().splitlines()
            changed = json.loads(rows[0]); changed['seed'] = 999
            rows[0] = json.dumps(changed)
            (second / 'cells' / CELL / 'games.jsonl').write_text('\n'.join(rows) + '\n')
            with self.assertRaisesRegex(ValueError, 'row differs from its schedule'):
                read_run(second)

    def test_cli_output_is_new_file_only(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / 'comparison.json'
            write_new_json(output, {'score_delta': .5})
            with self.assertRaises(FileExistsError):
                write_new_json(output, {'score_delta': 1.})
            self.assertEqual(json.loads(output.read_text()), {'score_delta': .5})


if __name__ == '__main__':
    unittest.main()
