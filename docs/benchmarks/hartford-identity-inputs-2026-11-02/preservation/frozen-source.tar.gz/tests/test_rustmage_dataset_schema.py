"""Saved demonstrations must match the current numerical encoder contract."""
import asyncio
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

AVAILABLE = importlib.util.find_spec('numpy') is not None
NEURAL = all(importlib.util.find_spec(name) is not None for name in ('numpy', 'tensorflow', 'keras'))


@unittest.skipUnless(AVAILABLE, 'Requires numpy')
class DatasetSchemaTests(unittest.TestCase):
    def setUp(self):
        from patchwork_automaton.neural.rustmage_features import RustMageEncoder

        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        games = []
        for index, partition in enumerate(('training', 'validation')):
            trajectories = []
            for seat in range(2):
                path = self.root / f'game-{index}-seat-{seat}.pkl.gz'
                path.write_bytes(b'fixture checked for existence only')
                trajectories.append(dict(path=str(path), samples=1))
            games.append(dict(index=index, partition=partition, status='win', trajectories=trajectories))
        # Round-trip the current manifest to exercise the actual JSON types.
        self.manifest = json.loads(json.dumps(RustMageEncoder().manifest()))
        self.dataset = dict(status='complete', encoder=self.manifest, completed_games=2,
            batches=[dict(games=games, split=dict(training_indices=[0], validation_indices=[1]))])

    def test_current_encoder_dataset_retains_partition_validation(self):
        from examples.train_rustmage_imitation import validate_dataset

        self.assertEqual(validate_dataset(self.dataset),
                         dict(training_games=1, validation_games=1, trajectories=4))
        self.dataset['batches'][0]['split']['validation_indices'] = [0, 1]
        with self.assertRaisesRegex(ValueError, 'whole-game partition'):
            validate_dataset(self.dataset)

    def test_missing_changed_and_reordered_schemas_require_recollection(self):
        from examples.train_rustmage_imitation import validate_dataset

        missing = deepcopy(self.dataset)
        del missing['encoder']
        changed = deepcopy(self.dataset)
        changed['encoder']['fingerprint'] = 'incompatible encoder fingerprint'
        reordered = deepcopy(self.dataset)
        reordered['encoder']['actions'] = dict(reversed(list(reordered['encoder']['actions'].items())))
        for data in (missing, changed, reordered):
            with self.subTest(encoder=data.get('encoder', {}).get('fingerprint')):
                with self.assertRaisesRegex(ValueError, 'Regenerate demonstrations.*collect_rustmage_demonstrations'):
                    validate_dataset(data)

    def test_collection_pins_encoder_before_starting_workers(self):
        from examples.collect_rustmage_demonstrations import collect

        output = self.root / 'collection'
        args = SimpleNamespace(output=output, games=2, games_per_batch=2, workers=1,
                               validation_fraction=.5, seed=17)
        with patch('examples.collect_rustmage_demonstrations.ProcessPoolExecutor',
                   side_effect=RuntimeError('stop before workers')):
            with self.assertRaisesRegex(RuntimeError, 'stop before workers'):
                collect(args)
        saved = json.loads((output / 'dataset.json').read_text())
        self.assertEqual(saved['encoder'], self.manifest)
        self.assertEqual(saved['status'], 'collecting')

    @unittest.skipUnless(NEURAL, 'Requires neural dependencies')
    def test_rejection_precedes_training_output_creation(self):
        from examples.train_rustmage_imitation import run

        dataset_directory = self.root / 'dataset'
        dataset_directory.mkdir()
        del self.dataset['encoder']
        (dataset_directory / 'dataset.json').write_text(json.dumps(self.dataset))
        output = self.root / 'training'
        args = SimpleNamespace(dataset=dataset_directory, output=output, epochs=1,
            train_batch=1, unroll=1, workers=1, eval_games=1, eval_horizon=1)
        with self.assertRaisesRegex(ValueError, 'Regenerate demonstrations'):
            asyncio.run(run(args))
        self.assertFalse(output.exists())
