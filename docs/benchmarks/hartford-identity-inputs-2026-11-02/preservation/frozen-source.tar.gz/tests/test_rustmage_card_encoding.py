"""Shared traits reach the model without a deck vocabulary or identity table."""
import asyncio
from copy import deepcopy
from dataclasses import replace
import os
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from patchwork_automaton.backends.rustmage import RustMageMatch, action_options, _plain
from patchwork_automaton.baselines.foundations import foundations_deck
from patchwork_automaton.core import CardSpec, DeckSpec
from patchwork_automaton.neural import card_traits
from patchwork_automaton.neural.rustmage_features import (
    RustMageEncoder, static_traits, SEMANTIC_WIDTH, ACTIONS)

NATIVE = Path('.local/rustmage/target/release/librustmage.so').is_file()


@unittest.skipUnless(NATIVE, 'Build RustMage first')
class GeneralCardEncodingTests(unittest.TestCase):
    def setUp(self):
        # Mutation fixtures below exercise Python fields; native parity has its
        # own raw-observation fixture so neither fast path hides a mutation.
        environment = patch.dict(os.environ, PATCHWORK_OBSERVATION_PIPELINE='python')
        environment.start()
        self.addCleanup(environment.stop)

    def initial(self):
        match = RustMageMatch(foundations_deck('red'), seed=19)
        self.addCleanup(match.close)
        return asyncio.run(match.games['player_0'].snapshot())

    def test_cards_outside_original_deck_and_tokens_have_static_traits(self):
        encoder = RustMageEncoder()
        for name in ('Llanowar Elves', 'Amalia Benavides Aguirre', 'Opt',
                     "Elusive Otter // Grove's Bounty", 'Lunar Convocation'):
            with self.subTest(card=name), RustMageMatch(
                    DeckSpec((CardSpec(name, 4), CardSpec('Plains', 56))), seed=19) as match:
                obs = asyncio.run(match.games['player_0'].snapshot())
                encoded = encoder.encode(obs)
                self.assertEqual(encoded.arrays['semantics'].shape[-1], SEMANTIC_WIDTH)
                self.assertFalse(encoded.arrays['card_ids'].any())
                self.assertTrue(all(np.isfinite(a).all() for a in encoded.arrays.values()))
                self.assertNotEqual(card_traits.traits_for(name), card_traits.UNKNOWN_TRAITS)
        self.assertEqual(encoder.card_count, 1)

    def test_unknown_identity_uses_live_characteristics_without_changing_shape(self):
        obs = self.initial()
        handle, obj = next(iter(obs.objects.items()))
        properties = dict(obj.properties, name='Unseen future card', card='Unseen future card',
                          kinds=1, colors=16, keywords=1 << 30, power=7, toughness=9)
        unknown = replace(obj, name='Unseen future card', properties=properties)
        altered = replace(obs, objects={**obs.objects, handle: unknown})
        encoder = RustMageEncoder()
        encoded = encoder.encode(altered).arrays
        original = encoder.encode(obs).arrays
        self.assertEqual({k: a.shape for k, a in encoded.items()}, {k: a.shape for k, a in original.items()})
        np.testing.assert_array_equal(encoded['semantics'][2, 0], card_traits.UNKNOWN_TRAITS)
        self.assertFalse(np.array_equal(encoded['entities'][2], original['entities'][2]))
        changed = replace(unknown, properties=dict(properties, power=8))
        other = encoder.encode(replace(altered, objects={**altered.objects, handle: changed})).arrays
        self.assertFalse(np.array_equal(encoded['entities'][2], other['entities'][2]))

    def test_hidden_flags_never_enrich_from_accidentally_retained_identity(self):
        obs = self.initial()
        handle, obj = next(iter(obs.objects.items()))
        def encoded(name):
            props = dict(obj.properties, name=name, card=name, face_down=True)
            hidden = replace(obj, name=name, properties=props)
            return RustMageEncoder().encode(replace(obs, objects={**obs.objects, handle: hidden})).arrays
        left, right = encoded('Mountain'), encoded('Amalia Benavides Aguirre')
        for key in left:
            np.testing.assert_array_equal(left[key], right[key], err_msg=key)

    def test_effective_identity_is_authoritative_and_missing_source_keeps_traits(self):
        self.assertEqual(static_traits(dict(card='Unknown token recipe', name='Mountain')),
                         card_traits.UNKNOWN_TRAITS)
        obs = self.initial()
        raw = dict(obs.native, announcing=dict(card=99999, source_card='Amalia Benavides Aguirre'))
        decision = replace(obs.decision, options=action_options(dict(actions=[dict(kind='Pass')])))
        encoded = RustMageEncoder().encode(replace(obs, native=raw, decision=decision)).arrays
        # The unavailable source still contributes its shared traits to the role.
        start = len(ACTIONS) + 1
        np.testing.assert_array_equal(encoded['candidates'][0, start:start + SEMANTIC_WIDTH],
                                      np.asarray(card_traits.traits_for('Amalia Benavides Aguirre'), np.float32))
        self.assertFalse(encoded['card_ids'].any())

    @unittest.skipUnless(Path('.local/observation-target/release/libpatchwork_observation_pipeline.so').is_file(),
                         'Build native observation pipeline first')
    def test_native_matches_traits_for_new_unknown_hidden_and_copied_cards(self):
        from patchwork_automaton.neural.native_pipeline import NativeObservation
        from patchwork_automaton.neural.rustmage_observation import learning_observation
        obs = self.initial()
        base = _plain(obs.native)
        encoder = RustMageEncoder()
        for fields in (
                dict(card='Amalia Benavides Aguirre', name='Amalia Benavides Aguirre'),
                dict(card='Future unregistered card', name='Future unregistered card', power=11),
                dict(card='Mountain', name='Different printed name'),
                dict(card='Amalia Benavides Aguirre', name='Amalia Benavides Aguirre', face_down=True)):
            with self.subTest(fields=fields):
                raw = deepcopy(base)
                raw['objects'][0].update(fields)
                native = NativeObservation.from_raw(raw)
                def view(value):
                    fake = SimpleNamespace(_raw=lambda _: value, session='traits', handle=obs.game)
                    return learning_observation(fake, 'P0')
                expected = encoder.encode(view(raw)).arrays
                actual = encoder.encode(view(native)).arrays
                for key in expected:
                    np.testing.assert_array_equal(expected[key], actual[key], err_msg=key)
