"""Registered deck integrity and the baseline evaluator's scheduling/accounting."""
import asyncio
from collections import Counter
from contextlib import redirect_stderr
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from examples import evaluate_standard_baselines as cli
from patchwork_automaton.baselines.standard_decks import STANDARD_DECKS, standard_deck
from patchwork_automaton.core import Option, Response

ROOT = Path(__file__).resolve().parents[1]
IDS = ('mono-green-landfall', 'izzet-prowess', 'bw-lifegain')


class FakeMatch:
    """Two sequential seat-private decisions followed by a player-one win."""
    instances = []

    def __init__(self, *decks, **options):
        self.step = 0
        self.closed = False
        self.instances.append(self)
        self.games = {f'player_{p}': FakeGame(self, p) for p in range(2)}

    def __enter__(self):
        return self

    def __exit__(self, *error):
        self.closed = True


class FakeGame:
    def __init__(self, match, player):
        self.match, self.player = match, player

    async def snapshot(self):
        terminal = self.match.step == 2
        decision = (SimpleNamespace(token=(self.match.step, self.player), kind='priority',
                    options=(Option('action:0', 'finite', 'Pass'),))
                    if not terminal and self.match.step == self.player else None)
        return SimpleNamespace(actor=self.player, turn=1, terminal=terminal, decision=decision,
                               players=(SimpleNamespace(life=20), SimpleNamespace(life=20)),
                               outcome=SimpleNamespace(draw=False, won=self.player == 1) if terminal else None)

    async def submit(self, token, response):
        assert token == (self.match.step, self.player)
        self.match.step += 1


class StandardDeckTests(unittest.TestCase):
    def test_exact_registered_lists_and_provenance(self):
        source = ROOT / 'docs/decks/hartford-selected-decks-2026-10-26.json'
        original = json.loads(source.read_text())
        packaged = json.loads((ROOT / 'src/patchwork_automaton/data/standard-baselines.json').read_text())
        self.assertEqual(tuple(STANDARD_DECKS), IDS)
        self.assertEqual(packaged['provenance']['source_sha256'], hashlib.sha256(source.read_bytes()).hexdigest())
        for deck_id, registration in zip(IDS, original['decks'], strict=True):
            with self.subTest(deck=deck_id):
                main = standard_deck(deck_id)
                full = standard_deck(deck_id, include_sideboard=True)
                self.assertEqual(sum(c.quantity for c in main.cards), 60)
                self.assertTrue(all(not c.sideboard for c in main.cards))
                self.assertEqual(sum(c.quantity for c in full.cards if c.sideboard), 15)
                for side, section in ((False, 'mainboard'), (True, 'sideboard')):
                    actual = Counter({c.name: c.quantity for c in full.cards if c.sideboard == side})
                    expected = Counter({c['name']: c['quantity'] for c in registration[section]})
                    self.assertEqual(actual, expected)
                for key in ('pilot', 'place', 'record', 'primary_source_url', 'deck_url'):
                    self.assertEqual(STANDARD_DECKS[deck_id][key], registration[key])

    def test_unknown_deck_fails_and_split_names_are_preserved(self):
        with self.assertRaisesRegex(ValueError, 'Unknown Standard'):
            standard_deck('red')
        names = {c.name for c in standard_deck('mono-green-landfall').cards}
        self.assertIn('Carnivorous Cultivator // Enroot', names)
        self.assertIn('Esper Origins // Summon: Esper Maduin', names)
        with self.assertRaises(TypeError):
            STANDARD_DECKS['mono-green-landfall']['mainboard'][0]['quantity'] = 99

    def test_schedule_rotates_seat_and_start_independently(self):
        games = list(cli.schedule(IDS, 4, 801))
        self.assertEqual(len(games), 12)
        self.assertEqual([g['seed'] for g in games], list(range(801, 813)))
        for offset in range(0, 12, 4):
            block = games[offset:offset + 4]
            self.assertEqual(len({(tuple(g['decks']), g['starting_player']) for g in block}), 4)
        mirror = list(cli.schedule(IDS[:1], 4, 0))
        self.assertTrue(all(g['decks'] == [IDS[0], IDS[0]] for g in mirror))
        self.assertEqual(Counter(g['starting_player'] for g in mirror), {'P0': 2, 'P1': 2})

    def test_accounting_does_not_turn_cutoffs_or_errors_into_draws(self):
        rows = [dict(status='completed', draw=False, winner_deck=IDS[0]),
                dict(status='completed', draw=True, winner_deck=None),
                dict(status='cutoff'), dict(status='error')]
        self.assertEqual(cli.summary(rows), dict(attempted=4, completed=2, cutoffs=1, errors=1,
                                                draws=1, wins={IDS[0]: 1}))

    def test_public_seat_submission_cleanup_and_cutoff(self):
        seen = []

        class Policy:
            def __init__(self, deck_id):
                self.deck_id = deck_id

            def choose(self, observation):
                seen.append((self.deck_id, observation.actor))
                return Response('action:0')

        game = next(cli.schedule(IDS[:2], 1, 801))
        args = cli.parser().parse_args([])
        with patch.object(cli, 'RustMageMatch', FakeMatch), patch.dict(sys.modules,
                {'patchwork_automaton.baselines.standard': SimpleNamespace(StandardAggro=Policy)}):
            row = asyncio.run(cli.play_game(game, args))
            self.assertEqual((row['status'], row['winner_seat'], row['decisions']), ('completed', 1, 2))
            self.assertEqual(seen, [(IDS[0], 0), (IDS[1], 1)])
            self.assertTrue(FakeMatch.instances[-1].closed)
            args.limit = 1
            row = asyncio.run(cli.play_game(game, args))
            self.assertEqual((row['status'], row['reason']), ('cutoff', 'decision_limit'))
            self.assertNotIn('draw', row)
            self.assertTrue(FakeMatch.instances[-1].closed)
            with tempfile.TemporaryDirectory() as directory, redirect_stderr(io.StringIO()):
                args.output = Path(directory) / 'report.json'
                args.decks, args.games = list(IDS[:2]), 1
                report = asyncio.run(cli.run(args))
                self.assertEqual(report['summary']['cutoffs'], 1)
                self.assertEqual(json.loads(args.output.read_text()), report)
                with self.assertRaises(FileExistsError):
                    asyncio.run(cli.run(args))

    def test_cli_import_needs_no_tensorflow_and_help_is_runnable(self):
        result = subprocess.run([sys.executable, '-c',
            'from examples.evaluate_standard_baselines import parser; import sys; '
            'assert "tensorflow" not in sys.modules; parser().parse_args(["--help"])'],
            cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('mono-green-landfall', result.stdout)

    def test_invalid_cli_limits_and_seed_fail_before_starting(self):
        for args in (['--limit', '0'], ['--games', '0'], ['--seed', '-1'],
                     ['--seed', str(2**64 - 1)], ['--game-timeout', 'nan'],
                     ['--decks', IDS[0], IDS[0]]):
            with self.subTest(args=args), redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
                cli.main(args)
            self.assertEqual(error.exception.code, 2)


if __name__ == '__main__':
    unittest.main()
