import { readFileSync } from 'node:fs';
import { expect, test } from 'vitest';
import { buildTimeline, stateAt } from './reducer';
import type { ReplayStream } from './types';
test('replay reflects each observed state', () => {
  const source = JSON.parse(readFileSync(process.env.PATCHWORK_TEST_SOURCE!, 'utf8'));
  const stream = JSON.parse(readFileSync(process.env.PATCHWORK_TEST_REPLAY!, 'utf8')) as ReplayStream & {patchwork_frame_ends: number[]};
  const timeline = buildTimeline(stream);
  for (const [i, frame] of source.frames.entries()) {
    const board = stateAt(timeline, stream.patchwork_frame_ends[i]);
    const expectedStack = frame.state.objects.filter((o: {zone:string}) => o.zone === 'Stack').map((o:{id:string}) => String(o.id)).sort();
    expect(board.stack.map(item => item.obj).filter(Boolean).sort(), `frame ${i}, stack`).toEqual(expectedStack);
    for (let seat=1;seat<=2;seat++) {
      const p=frame.state.players[seat-1];
      expect(board.life[seat], `frame ${i}, seat ${seat} life`).toEqual(p.life);
      expect(board.seats[seat].handSize, `frame ${i}, seat ${seat} hand`).toEqual(p.hand_count);
      expect(board.seats[seat].librarySize, `frame ${i}, seat ${seat} library`).toEqual(p.library_count);
      const expected=frame.state.objects.filter((o: {zone:string, controller:string}) => o.zone === 'Battlefield' && o.controller===`P${seat-1}`).map((o:{id:string})=>String(o.id)).sort();
      expect(board.seats[seat].zones.battlefield.slice().sort(), `frame ${i}, seat ${seat} battlefield`).toEqual(expected);
      for (const item of frame.state.objects.filter((o: {zone:string, controller:string}) => o.zone === 'Battlefield' && o.controller===`P${seat-1}`)) {
        const obj = board.objects.get(String(item.id))!;
        expect(obj.tapped, `frame ${i}, ${item.name} tap`).toEqual(!!item.tapped);
        if (item.name) expect(stream.cards[obj.card!]?.name, `frame ${i}, identity`).toEqual(item.name);
        if (item.kinds & 1) {
          expect(String(obj.power), `frame ${i}, ${item.name} power`).toEqual(String(item.power));
          expect(String(obj.toughness), `frame ${i}, ${item.name} toughness`).toEqual(String(item.toughness));
        }
      }
    }
  }
  expect(timeline.final.ended).toBe(stream.events.some(e => e.kind === 'game_end'));
  if (timeline.final.ended) expect(timeline.final.winnerSeat).toBe(stream.game.winner_seat);
});
