"""A/B selection never converts missing expert streams into training labels."""

import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import numpy as np

from examples.run_standard_role_ab import (load_stage_games, pooled_control_refs, save_arm_weights,
    write_atomic_json)


class StandardRoleABTests(unittest.TestCase):
    def test_pooled_control_keeps_presence_but_erases_entity_order(self):
        arrays = dict(candidate_refs=np.asarray([[.5, .5]], np.float32),
                      candidate_role_refs=np.asarray([[[1, 0], [0, 1], [0, 0]]], np.float32))
        np.testing.assert_array_equal(pooled_control_refs(arrays),
                                      [[[.5, .5], [.5, .5], [0, 0]]])

    def test_completed_arm_artifacts_are_atomic_and_hashed(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            partial = root / 'experiment.partial.json'
            write_atomic_json(partial, {'status': 'running', 'arms': {}})
            write_atomic_json(partial, {'status': 'running', 'arms': {'ordered': 1}})
            self.assertEqual(json.loads(partial.read_text())['arms'], {'ordered': 1})
            self.assertFalse((root / 'experiment.partial.json.tmp').exists())
            layer = lambda value: SimpleNamespace(get_weights=lambda: [np.asarray([value])])
            policy = SimpleNamespace(role_hidden=layer(1.), role_score=layer(2.))
            saved = save_arm_weights(root, 'ordered', policy)
            self.assertEqual(saved['path'], str(root / 'ordered-residual.npz'))
            self.assertEqual(len(saved['sha256']), 64)
            self.assertFalse((root / 'ordered-residual.tmp.npz').exists())

    def test_only_explicitly_adjudicated_empty_games_are_excluded(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            files = [root / f'seat-{seat}.pkl.gz' for seat in (0, 1)]
            for path in files:
                path.write_bytes(b'fixture')
            manifest = {'feature_version': 5}
            empty = dict(index=1, seed=101, partition='training', status='draw',
                         decks=['a', 'b'], adjudicated=True, trajectories=[])
            recorded = dict(index=2, seed=102, partition='training', status='win',
                            decks=['a', 'b'], trajectories=[
                                dict(player=seat, deck=deck, path=str(files[seat]), samples=1)
                                for seat, deck in enumerate(('a', 'b'))])
            path = root / 'dataset.json'
            path.write_text(json.dumps(dict(status='complete', encoder=manifest,
                                            completed_games=2, games=[empty, recorded])))
            partitions, excluded = load_stage_games(root, manifest)
            self.assertEqual(partitions['training'], [recorded])
            self.assertEqual(excluded, dict(training=1, validation=0))
            empty['adjudicated'] = False
            path.write_text(json.dumps(dict(status='complete', encoder=manifest,
                                            completed_games=2, games=[empty, recorded])))
            with self.assertRaisesRegex(ValueError, 'Non-adjudicated'):
                load_stage_games(root, manifest)


if __name__ == '__main__':
    unittest.main()
