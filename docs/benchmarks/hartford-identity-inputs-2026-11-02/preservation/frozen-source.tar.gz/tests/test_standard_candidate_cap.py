"""Large action domains stop at a deterministic legal prefix, not an error."""
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from patchwork_automaton.neural.standard_features import expand_standard_options,STANDARD_CANDIDATE_LIMIT
from patchwork_automaton.backends.rustmage import domain_action


def option(name, **constraints):
    return SimpleNamespace(id='domain:'+name,kind='domain',constraints=constraints)


def decision(*options):
    return SimpleNamespace(options=options)


class StandardCandidateCapTests(unittest.TestCase):
    def test_huge_numeric_domain_stops_generation_at_cap(self):
        spec=option('x_choice',intervals=[dict(minimum=0,maximum=2**32-1)])
        with patch('patchwork_automaton.neural.standard_features.domain_action',wraps=domain_action) as convert:
            rows=expand_standard_options(decision(spec))
        self.assertEqual(convert.call_count,STANDARD_CANDIDATE_LIMIT)
        self.assertEqual([a['value'] for _,a in rows],list(range(STANDARD_CANDIDATE_LIMIT)))

    def test_large_payment_domain_returns_only_valid_deterministic_payments(self):
        spec=option('mana_payment',required=[0]*6,available=[10**9]*6,generic=10**9)
        rows=expand_standard_options(decision(spec))
        self.assertEqual(len(rows),STANDARD_CANDIDATE_LIMIT)
        for index,(response,action) in enumerate(rows):
            self.assertEqual(action['payment'],[0,0,0,0,index,10**9-index])
            self.assertEqual(domain_action(spec,response.value),action)
        self.assertEqual(rows,expand_standard_options(decision(spec)))

    def test_finite_indices_and_first_duplicate_remain_unchanged(self):
        options=[SimpleNamespace(id='finite:'+str(i),kind='finite',constraints=dict(action=dict(kind='ChooseX',value=i))) for i in range(1000)]
        rows=expand_standard_options(decision(options[0],*options))
        self.assertEqual(len(rows),STANDARD_CANDIDATE_LIMIT)
        self.assertEqual([r.option for r,_ in rows],['finite:'+str(i) for i in range(STANDARD_CANDIDATE_LIMIT)])

    def test_small_domains_are_complete_and_unsupported_domains_still_fail(self):
        rows=expand_standard_options(decision(option('source_counter_choice',maximum=5)))
        self.assertEqual([a['amount'] for _,a in rows],list(range(6)))
        with self.assertRaisesRegex(Exception,'Unsupported Standard domain'):
            expand_standard_options(decision(option('not_supported')))

    def test_nonpositive_or_noninteger_limits_fail(self):
        for limit in (0,-1,True,1.5):
            with self.subTest(limit=limit),self.assertRaises(ValueError):
                expand_standard_options(decision(),limit=limit)

if __name__=='__main__':unittest.main()
