"""Progress throttling and update budgets do not depend on model state."""
import unittest
from unittest.mock import patch
from patchwork_automaton.neural.update_progress import UpdateProgress

class UpdateProgressTests(unittest.TestCase):
    def test_stage_changes_force_events_and_same_stage_is_throttled(self):
        events=[]
        with patch('patchwork_automaton.neural.update_progress.time.monotonic') as clock:
            clock.return_value=100
            progress=UpdateProgress(events.append,interval_seconds=10)
            progress.emit('packing',samples=0)
            clock.return_value=101;progress.emit('packing',samples=1)
            clock.return_value=110;progress.emit('packing',samples=10)
            clock.return_value=111;progress.emit('actor_epoch',epoch=1,attempt=1)
            progress.emit('guard_result',force=True,accepted=False)
        self.assertEqual([e['phase'] for e in events],['packing','packing','actor_epoch','guard_result'])
        self.assertEqual(events[1]['samples'],10)

    def test_expired_budget_reports_timeout_and_raises(self):
        events=[]
        with patch('patchwork_automaton.neural.update_progress.time.monotonic') as clock:
            clock.return_value=0;progress=UpdateProgress(events.append,timeout_seconds=5)
            clock.return_value=5
            with self.assertRaisesRegex(TimeoutError,'wall-clock budget during actor_epoch'):
                progress.emit('actor_epoch')
        self.assertEqual(events[-1]['phase'],'timeout')

    def test_budget_is_enforced_without_callback(self):
        with patch('patchwork_automaton.neural.update_progress.time.monotonic',side_effect=[0,3]):
            progress=UpdateProgress(timeout_seconds=2)
            with self.assertRaises(TimeoutError):progress.emit('packing')

    def test_invalid_options(self):
        for value in (0,-1,float('inf'),float('nan'),True):
            with self.assertRaises(ValueError):UpdateProgress(timeout_seconds=value)
        with self.assertRaises(ValueError):UpdateProgress(callback=42)

if __name__=='__main__':unittest.main()

