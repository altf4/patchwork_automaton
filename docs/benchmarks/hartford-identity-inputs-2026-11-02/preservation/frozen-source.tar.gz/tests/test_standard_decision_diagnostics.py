"""Read-only expert decision diagnostics keep seat memory and deck identity."""

import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import numpy as np

from examples.diagnose_standard_decisions import (evaluate_trajectories,
    load_games, select_games, write_new_json)


def sample(action, kind, *, duplicate=False):
    candidates = np.array([[1., 0.], [1., 0.] if duplicate else [0., 1.]], np.float32)
    refs = np.array([[1., 0.], [1., 0.] if duplicate else [0., 1.]], np.float32)
    return SimpleNamespace(action=action, decision_kind=kind,
                           arrays=dict(candidates=candidates, candidate_refs=refs))


class FakeTrainer:
    def __init__(self):
        self.policy = SimpleNamespace(memory_size=2)
        self.memory_seen = []
        self.calls = 0

    def _chunks(self, streams):
        yield ({}, np.array([[0, 1]], np.int32),
               np.array([[1., 1.]], np.float32),
               [streams[0][0], streams[1][0]])
        yield ({}, np.array([[1, 1]], np.int32),
               np.array([[1., 0.]], np.float32),
               [streams[0][1], streams[1][0]])

    def evaluate_chunk(self, memory, packed, labels, active):
        self.memory_seen.append(memory.copy())
        if self.calls == 0:
            losses, predicted = [[.2, .3]], [[0, 0]]
        else:
            losses, predicted = [[.1, .3]], [[1, 0]]
        self.calls += 1
        return (memory + active.sum(axis=0)[:, None],
                np.array(losses, np.float32), np.array(predicted, np.int32))


class StandardDecisionDiagnosticsTests(unittest.TestCase):
    def test_selected_games_are_bounded_and_reproducible(self):
        games = [dict(index=index, seed=100 + index) for index in range(12)]
        first = select_games(games, maximum=5, seed=29)
        self.assertEqual(first, select_games(list(reversed(games)), maximum=5, seed=29))
        self.assertEqual(len(first), 5)
        self.assertEqual(len({game['seed'] for game in first}), 5)
        self.assertEqual(len(select_games(games, maximum=0, seed=0)), 12)

    def test_recurrent_memory_stays_with_each_seat_and_ties_are_explicit(self):
        streams = [dict(deck='izzet-prowess', samples=[sample(0, 'targets'),
                                                       sample(1, 'blockers')]),
                   dict(deck='bw-lifegain', samples=[sample(1, 'library_search', duplicate=True)])]
        trainer = FakeTrainer()
        report = evaluate_trajectories(trainer, streams, batch_size=2,
                                       reader=lambda trajectory: trajectory['samples'])
        self.assertEqual(len(trainer.memory_seen), 2)
        np.testing.assert_array_equal(trainer.memory_seen[0], np.zeros((2, 2)))
        np.testing.assert_array_equal(trainer.memory_seen[1], np.ones((2, 2)))
        self.assertEqual(report['aggregate']['samples'], 3)
        self.assertAlmostEqual(report['aggregate']['top1_accuracy'], 2 / 3)
        self.assertEqual(report['aggregate']['encoded_tie_top1_accuracy'], 1.)
        self.assertEqual(report['decks']['izzet-prowess']['samples'], 2)
        self.assertEqual(report['decisions']['library_search']['samples'], 1)
        self.assertIn('blockers', report['focus'])

    def test_dataset_manifest_and_new_output_are_strict(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            trajectories = [root / f'seat-{seat}.pkl.gz' for seat in (0, 1)]
            for trajectory in trajectories:
                trajectory.write_bytes(b'fixture')
            manifest = {'fingerprint': 'schema'}
            game = dict(index=1, seed=12, partition='validation', status='win',
                        decks=['izzet-prowess', 'bw-lifegain'],
                        trajectories=[dict(player=0, deck='izzet-prowess',
                                           path=str(trajectories[0]), samples=1),
                                      dict(player=1, deck='bw-lifegain',
                                           path=str(trajectories[1]), samples=1)])
            (root / 'dataset.json').write_text(json.dumps(dict(status='complete',
                encoder=manifest, completed_games=1, games=[game])))
            games, sources = load_games([root], manifest, partition='validation')
            self.assertEqual(games, [game])
            self.assertEqual(len(sources), 1)
            with self.assertRaises(ValueError):
                load_games([root], {'fingerprint': 'other'}, partition='validation')
            output = root / 'report.json'
            write_new_json(output, {'games': 1})
            with self.assertRaises(FileExistsError):
                write_new_json(output, {'games': 2})
            self.assertEqual(json.loads(output.read_text()), {'games': 1})


if __name__ == '__main__':
    unittest.main()
