"""The self-play fork changes opponents, never the durable game schedule."""
from collections import Counter, defaultdict
import unittest

from patchwork_automaton.rl.standard_ppo import schedule
from patchwork_automaton.rl.standard_selfplay_schedule import (
    assign_opponents, snapshot_round_for_round)


class SelfplayScheduleTests(unittest.TestCase):
    def test_declared_snapshots_and_exact_opponent_quotas(self):
        self.assertEqual([snapshot_round_for_round(n) for n in (201, 202, 210, 211, 221, 241)],
                         [200, 150, 150, 210, 200, 240])
        seen_ids = set()
        seen_seeds = set()
        strata = defaultdict(Counter)
        digest = 'a' * 64
        for number in range(201, 251):
            original = schedule(1000, round_id=number)
            assigned = assign_opponents(original, round_id=number, mode='frozen_pool',
                checkpoint_round=snapshot_round_for_round(number), checkpoint_sha256=digest)
            self.assertEqual(Counter((g['partition'], g['opponent_kind']) for g in assigned), Counter({
                ('training', 'scripted'): 160, ('training', 'frozen_neural'): 640,
                ('validation', 'scripted'): 40, ('validation', 'frozen_neural'): 160}))
            self.assertEqual([(g['index'], g['seed'], g['decks'], g['learner_seat'], g['starting_player'])
                              for g in assigned], [
                (g['index'], g['seed'], g['decks'], g['learner_seat'], g['starting_player'])
                              for g in original])
            for g in assigned:
                self.assertNotIn(g['index'], seen_ids)
                self.assertNotIn(g['seed'], seen_seeds)
                seen_ids.add(g['index']); seen_seeds.add(g['seed'])
                key = (g['partition'], tuple(g['pairing']), g['learner_deck'],
                       g['learner_seat'], g['starting_player'])
                strata[key]['total'] += 1
                strata[key][g['opponent_kind']] += 1
        self.assertEqual(len(seen_ids), 50_000)
        self.assertEqual(len(seen_seeds), 50_000)
        # Every pairing/role/start/partition is within three games of 20%.
        self.assertLessEqual(max(abs(c['scripted'] - c['total'] / 5) for c in strata.values()), 3)

    def test_script_only_arm_and_invalid_snapshot(self):
        games = schedule(1000, round_id=201)
        scripted = assign_opponents(games, round_id=201, mode='scripted')
        self.assertTrue(all(g['opponent_kind'] == 'scripted' for g in scripted))
        with self.assertRaisesRegex(ValueError, 'predeclared rotation'):
            assign_opponents(games, round_id=201, mode='frozen_pool',
                checkpoint_round=150, checkpoint_sha256='a' * 64)


if __name__ == '__main__':
    unittest.main()
