"""Serve one converted replay with a locally installed Tapps UI."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ENTRY = '''import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ReplayViewer } from './replay/components/ReplayViewer';
import type { ReplayStream } from './replay/types';
import './styles.css';
import './replay/replay.css';
import './replay/replay-controls.css';
function App() {
  const [stream, setStream] = useState<ReplayStream | null>(null);
  const [error, setError] = useState('');
  useEffect(() => { fetch('/patchwork-replay.json').then(r => { if (!r.ok) throw Error(r.statusText); return r.json(); }).then(setStream).catch(e => setError(String(e))); }, []);
  return <main className="dashboard-main replay-page-main">{stream ? <ReplayViewer stream={stream} gameId={stream.game.id} at={null} returnHash={null} /> : <p>{error || 'Loading replay…'}</p>}</main>;
}
createRoot(document.getElementById('root')!).render(<App />);
'''
HTML = '<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><div id="root"></div><script type="module" src="/src/patchwork-replay.tsx"></script></body></html>\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('replay', type=Path)
    parser.add_argument('--tapps', type=Path, default=Path('.local/tapps-replay'))
    parser.add_argument('--port', type=int, default=5173)
    args = parser.parse_args()
    ui = args.tapps.resolve() / 'ui'
    if not (ui/'src/replay/components/ReplayViewer.tsx').is_file() or not (ui/'node_modules/.bin/vite').exists():
        parser.error('Tapps checkout or UI dependencies missing; see docs/tapps-replay.md')
    stream = json.loads(args.replay.read_text())
    if stream.get('version') != 1 or not stream.get('events'):
        parser.error('Expected a nonempty Tapps replay stream version 1')
    # Reserved Patchwork-only filenames in the external checkout; no Tapps files modified.
    (ui/'src/patchwork-replay.tsx').write_text(ENTRY)
    (ui/'patchwork-replay.html').write_text(HTML)
    (ui/'public').mkdir(exist_ok=True)
    (ui/'public/patchwork-replay.json').write_text(json.dumps(stream))
    print(f'Open http://127.0.0.1:{args.port}/patchwork-replay.html', flush=True)
    return subprocess.call([str(ui/'node_modules/.bin/vite'), '--host', '127.0.0.1', '--port', str(args.port), '--strictPort'], cwd=ui)


if __name__ == '__main__': sys.exit(main())
