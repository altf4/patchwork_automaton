"""Play and record a Standard policy game for the reconstructed Tapps viewer."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault('PATCHWORK_OBSERVATION_PIPELINE', 'python')
os.environ.setdefault('KERAS_BACKEND', 'tensorflow')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS', '0')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('output', type=Path)
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--learner-deck', required=True)
    p.add_argument('--opponent-deck', required=True)
    p.add_argument('--learner-seat', type=int, choices=(0, 1), default=0)
    p.add_argument('--starting-player', choices=('P0', 'P1'), default='P0')
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--greedy', action='store_true')
    p.add_argument('--opponent', choices=('tactical', 'aggro'), default='tactical')
    p.add_argument('--opponent-checkpoint', type=Path)
    p.add_argument('--max-decisions', type=int, default=6000)
    p.add_argument('--max-turns', type=int, default=50)
    args = p.parse_args()

    import numpy as np
    import tensorflow as tf
    from patchwork_automaton.backends.rustmage import RustMageMatch, domain_action, _plain
    from patchwork_automaton.baselines.standard import StandardAggro
    from patchwork_automaton.baselines.standard_tactical import StandardTactical
    from patchwork_automaton.baselines.standard_decks import standard_deck
    from patchwork_automaton.neural.batching import example_batch, input_signature, pack_requests
    from patchwork_automaton.neural.devices import configure_runtime, device_scope
    from patchwork_automaton.neural.rustmage_observation import learning_observation
    from patchwork_automaton.neural.standard_inference import StandardInferencePolicy
    from patchwork_automaton.neural.standard_policy import StandardPolicy
    from patchwork_automaton.replay.record import visible_snapshot

    configure_runtime('cpu', hide_gpu=True)
    class Batcher:
        def __init__(self, model):
            with device_scope('cpu'):
                example = example_batch(model.memory_size, model.feature_spec)
                model(example, training=False)
                self.compiled = tf.function(model.call, input_signature=[input_signature(example)], autograph=False)

        def predict(self, batch, *, version, identity, unbatched=False):
            request = SimpleNamespace(batch=batch, unbatched=unbatched)
            items, packed = pack_requests([request])
            outputs = self.compiled(packed)
            return {k: np.asarray(v)[:, :len(items[0]['candidates'])] if k == 'logits' else np.asarray(v)
                    for k, v in outputs.items()}

    decks = [args.opponent_deck, args.opponent_deck]
    decks[args.learner_seat] = args.learner_deck
    policies = [None, None]
    with device_scope('cpu'):
        model = StandardPolicy.load(args.checkpoint).model
    policies[args.learner_seat] = StandardInferencePolicy(model, batcher=Batcher(model),
        seed=args.seed * 2 + args.learner_seat, greedy=args.greedy, version=0)
    opponent_seat = 1 - args.learner_seat
    if args.opponent_checkpoint:
        with device_scope('cpu'):
            opponent_model = StandardPolicy.load(args.opponent_checkpoint).model
        policies[opponent_seat] = StandardInferencePolicy(opponent_model, batcher=Batcher(opponent_model),
            seed=args.seed * 2 + opponent_seat, greedy=args.greedy, version=0)
    else:
        policies[opponent_seat] = (StandardTactical if args.opponent == 'tactical' else StandardAggro)(args.opponent_deck)
    viewer = f'P{args.learner_seat}'
    frames = []
    started = now()
    reason = None
    with RustMageMatch(*(standard_deck(d) for d in decks), seed=args.seed,
                       starting_player=args.starting_player) as match:
        frames.append(dict(state=visible_snapshot(match._raw(viewer)), action=None))
        while True:
            views = [learning_observation(match, f'P{i}') for i in range(2)]
            for player, view in enumerate(views):
                observe = getattr(policies[player], 'observe', None)
                if observe:
                    observe(view)
            if views[0].terminal:
                break
            if views[0].turn > args.max_turns:
                reason = 'turn_limit'
                break
            if len(frames) - 1 >= args.max_decisions:
                reason = 'decision_limit'
                break
            actors = [i for i, v in enumerate(views) if v.decision is not None]
            if len(actors) != 1:
                raise RuntimeError('Expected exactly one prompted player')
            player = actors[0]
            view = views[player]
            response = (policies[player].act(view).response if player == args.learner_seat or args.opponent_checkpoint
                        else policies[player].choose(view))
            option = next(o for o in view.decision.options if o.id == response.option)
            action = option.constraints['action'] if option.kind == 'finite' else domain_action(option, response.value)
            raw = match._raw(view.actor.value)
            updated = (match.native_game.step(raw, int(option.id.split(':')[1])) if option.kind == 'finite'
                       else match.native_game.act(raw, action))
            match._after_action(updated, view.actor.value, raw['revision'])
            recorded_action = dict(actor=f'player_{player}', kind=option.label, decision=view.decision.kind)
            if player == args.learner_seat:
                recorded_action.update(option=response.option, value=_plain(response.value), details=_plain(option.constraints))
            frames.append(dict(state=visible_snapshot(match._raw(viewer)), action=recorded_action))
    recording = dict(version=1, backend='rustmage', source='standard-policy-recording', seed=args.seed,
        started_at=started, ended_at=now(), truncated=reason is not None, reason=reason, frames=frames,
        provenance=dict(checkpoint=str(args.checkpoint.resolve()), checkpoint_sha256=hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
            learner_seat=args.learner_seat, decks=decks, starting_player=args.starting_player,
            mode='greedy' if args.greedy else 'sampled', opponent='neural' if args.opponent_checkpoint else args.opponent,
            opponent_checkpoint=str(args.opponent_checkpoint.resolve()) if args.opponent_checkpoint else None,
            opponent_checkpoint_sha256=hashlib.sha256(args.opponent_checkpoint.read_bytes()).hexdigest() if args.opponent_checkpoint else None))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(recording) + '\n')
    print(json.dumps(dict(output=str(args.output), frames=len(frames), outcome=frames[-1]['state']['outcome'], reason=reason)))


if __name__ == '__main__':
    main()
