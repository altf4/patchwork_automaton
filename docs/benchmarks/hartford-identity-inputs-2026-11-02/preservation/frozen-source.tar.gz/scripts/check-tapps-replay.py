"""Check a converted replay against every snapshot using Tapps' actual reducer."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile

from patchwork_automaton.replay.tapps import convert
from patchwork_automaton.replay.xmage_trace import normalize, read_trace


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('recording', type=Path)
    parser.add_argument('--viewer', choices=('player_0', 'player_1'), default='player_0')
    parser.add_argument('--tapps', type=Path, default=Path('.local/tapps-replay'))
    args = parser.parse_args()
    ui = args.tapps.resolve() / 'ui'
    vitest = ui/'node_modules/.bin/vitest'
    if not vitest.exists(): parser.error('Tapps UI dependencies missing; see docs/tapps-replay.md')
    if args.recording.name.endswith(('.jsonl', '.jsonl.gz')):
        source = normalize(read_trace(args.recording), args.viewer)
    else:
        source = json.loads(args.recording.read_text())
    replay = convert(source)
    test = ui/'src/replay/patchwork-contract.test.ts'
    if test.exists(): parser.error(f'Refusing to overwrite {test}')
    template = Path(__file__).resolve().parent.parent/'tests/tapps_reducer.test.ts'
    with tempfile.TemporaryDirectory(prefix='patchwork-tapps-') as directory:
        root = Path(directory)
        (root/'source.json').write_text(json.dumps(source))
        (root/'replay.json').write_text(json.dumps(replay))
        environment = os.environ.copy()
        environment.update(PATCHWORK_TEST_SOURCE=str(root/'source.json'), PATCHWORK_TEST_REPLAY=str(root/'replay.json'))
        test.write_text(template.read_text())
        try:
            return subprocess.call([str(vitest), 'run', 'src/replay/patchwork-contract.test.ts'], cwd=ui, env=environment)
        finally:
            test.unlink()


if __name__ == '__main__': raise SystemExit(main())
